# Z-Name Add-on for Blender

## Description

Z-Name is a Blender add-on designed to display the active object's name as an overlay in the 3D viewport. This tool enhances visibility and accessibility by providing a clear indication of the selected object's name, making it easier to manage complex scenes.

## Features

- Displays the active object's name as an overlay in the 3D viewport.
- Toggle the name overlay on or off with a simple checkbox.
- Automatically updates the overlay when the active object changes.
- Integrates seamlessly into the Blender UI for easy access.

## Installation

1. Download the `.zip` file of the add-on.
2. Open Blender and go to `Edit` > `Preferences`.
3. Select the `Add-ons` tab and click the downward-facing arrow in the top-right corner.
4. Choose `Install from Disk` and select the downloaded `.zip` file.
5. Enable the add-on by checking the box next to "Z-Name".

## Usage

### Displaying Object Names

1. Open the **N** panel in the 3D View and go to the **Z-Anatomy** tab.
2. Locate the **Show Object Name** panel.
3. Toggle the **Show Object Name** checkbox to display or hide the active object's name overlay.

### Panel

The add-on includes a panel in the 3D View UI under the "Z-Anatomy" category, providing easy access to the name overlay tool.

## Author

- **Marcin Zieliński**
- **Z-Anatomy**

## Compatibility

- Blender 3.0 and later versions.

## License

This add-on is distributed under the [CC-BY-SA 4.0](LICENSE) license, which allows sharing and adaptation with attribution and under the same terms.
