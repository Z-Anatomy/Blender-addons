import bpy
import bmesh
from mathutils import Vector

bl_info = {
    "name": "Z-Label1",
    "blender": (2, 80, 0),
    "category": "Object",
    "description": "Convert selected meshes to labels, managing hierarchy and children.",
    "author": "Marcin Zielinski, Gauthier Kervyn",
    "version": (2, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > Z-Anatomy",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
}

_last_active_name = None
_timer = None

def clean_name(name):
    for ending in ('.r', '.l', '.t', '.j', '.o', '.e', ''):
        if ending == '':
            return name, ending
        elif name.endswith(ending):
            clean_name = name[:-len(ending)]
            return clean_name, ending

class OBJECT_OT_place_label_above_vertex(bpy.types.Operator):
    bl_idname = "object.place_label_above_vertex"
    bl_label = "Position label + hook automatically"
    bl_options = {'REGISTER', 'UNDO'}

    offset: bpy.props.FloatProperty(
        name="Z Offset (mm)",
        description="Distance above the selected vertex",
        default=50.0,
        min=0.0,
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and context.mode == 'EDIT_MESH' and len(context.selected_objects) >= 2

    def execute(self, context):
        selected = [obj for obj in context.selected_objects if obj != context.active_object]
        if not selected:
            self.report({'ERROR'}, "Select the label line (.j) first, then the active mesh.")
            return {'CANCELLED'}
        
        # Trouver l'objet ligne (.j)
        line_obj = None
        for obj in selected:
            if obj.name.endswith('.j'):
                line_obj = obj
                break
        
        if not line_obj:
            self.report({'ERROR'}, "Select a label line (.j) first.")
            return {'CANCELLED'}
            
        mesh_obj = context.active_object

        bm = bmesh.from_edit_mesh(mesh_obj.data)
        verts = [v for v in bm.verts if v.select]
        if len(verts) != 1:
            self.report({'ERROR'}, "Select exactly one vertex in Edit Mode.")
            return {'CANCELLED'}
        v_co = mesh_obj.matrix_world @ verts[0].co
        
        # Positionner la ligne (le parent) au niveau du vertex
        line_obj.location = v_co
        
        # Trouver le texte enfant
        text_child = None
        for child in line_obj.children:
            if child.name.endswith('.t'):
                text_child = child
                break
        
        if text_child:
            # Positionner le texte 0.2 unité plus haut que sa position actuelle
            text_world_pos = text_child.matrix_world.to_translation()
            new_text_pos = Vector((text_world_pos.x, text_world_pos.y, text_world_pos.z + 0.2))
            
            # Convertir en espace local de la ligne
            local_text_pos = line_obj.matrix_world.inverted() @ new_text_pos
            text_child.location = local_text_pos

        bpy.ops.object.mode_set(mode='OBJECT')

        # Hooker le VERTEX 0 (le bas de la ligne) au vertex du mesh
        line_obj.select_set(True)
        context.view_layer.objects.active = line_obj

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        
        # Sélectionner le vertex 0 (bas de la ligne) avec ensure_lookup_table()
        bm_line = bmesh.from_edit_mesh(line_obj.data)
        bm_line.verts.ensure_lookup_table()
        bm_line.verts[0].select = True
        bmesh.update_edit_mesh(line_obj.data)

        bpy.ops.object.mode_set(mode='OBJECT')
        
        # Ajouter ou mettre à jour le hook pour le vertex 0 (bas)
        hook_mod_bottom = None
        for mod in line_obj.modifiers:
            if mod.type == 'HOOK' and mod.name == "Hook_Bottom":
                hook_mod_bottom = mod
                break
        
        if not hook_mod_bottom:
            hook_mod_bottom = line_obj.modifiers.new(name="Hook_Bottom", type='HOOK')
        
        hook_mod_bottom.object = mesh_obj
        hook_mod_bottom.vertex_indices_set([0])  # Vertex 0

        # Hooker le VERTEX 1 (le haut de la ligne) au texte - méthode manuelle simulée
        if text_child:
            # Sélectionner la ligne puis le texte (comme la méthode manuelle)
            bpy.ops.object.select_all(action='DESELECT')
            line_obj.select_set(True)
            text_child.select_set(True)
            context.view_layer.objects.active = line_obj
            
            # Passer en mode edit et sélectionner le vertex 1
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='DESELECT')
            
            bm_line = bmesh.from_edit_mesh(line_obj.data)
            bm_line.verts.ensure_lookup_table()
            if len(bm_line.verts) > 1:
                bm_line.verts[1].select = True
            bmesh.update_edit_mesh(line_obj.data)
            
            # Appliquer le hook avec la méthode manuelle
            bpy.ops.object.hook_add_selob()
            
            # Renommer le hook créé
            bpy.ops.object.mode_set(mode='OBJECT')
            for mod in line_obj.modifiers:
                if mod.type == 'HOOK' and mod.object == text_child:
                    mod.name = "Hook_Top"
                    break

        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')

        line_obj.select_set(True)
        context.view_layer.objects.active = line_obj

        self.report({'INFO'}, "Label positioned and hooks added.")
        return {'FINISHED'}

class OBJECT_OT_make_label_from_mesh(bpy.types.Operator):
    bl_idname = "object.make_label_from_mesh"
    bl_label = "Convert Selected to Labels"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and len(context.selected_objects) > 0

    def execute(self, context):
        selected_objects = context.selected_objects[:]
        bpy.ops.object.select_all(action='DESELECT')

        for mesh_object in selected_objects:
            if mesh_object.type != 'MESH':
                continue

            parent = mesh_object.parent
            children = mesh_object.children[:]
            collections = mesh_object.users_collection[:]
            original_mesh_data_name = mesh_object.data.name
            
            mesh_object.select_set(True)
            context.view_layer.objects.active = mesh_object

            base_name, _ = clean_name(mesh_object.name)

            # Calculer la position du texte (2.2 unités au-dessus du point le plus haut)
            text_location = mesh_object.location + Vector((0, 0, 2.2))
            if mesh_object.data and mesh_object.data.vertices:
                try:
                    highest_point = max((mesh_object.matrix_world @ v.co).z for v in mesh_object.data.vertices)
                    text_location = mesh_object.matrix_world @ Vector((0, 0, highest_point)) + Vector((0, 0, 2.2))
                except:
                    pass

            # Créer d'abord la ligne (.j) - qui sera le parent
            line_location = mesh_object.location
            
            # Créer les vertices de la ligne: [0] au mesh, [1] au texte
            verts = [
                Vector((0, 0, 0)),  # Vertex 0 - bas (sera hooké au mesh)
                Vector((0, 0, 2.2))  # Vertex 1 - haut (pointant vers la position du texte)
            ]
            edges = [[0, 1]]
            
            line_mesh_name = f"{original_mesh_data_name}.j"
            mesh_line = bpy.data.meshes.new(line_mesh_name)
            mesh_line.from_pydata(verts, edges, [])
            mesh_line.update()

            line_object = bpy.data.objects.new(f"{base_name}.j", mesh_line)
            line_object.location = line_location

            # Créer le texte (.t) - enfant de la ligne
            bpy.ops.object.text_add(
                radius=0.003 * 100,
                enter_editmode=False,
                align='WORLD',
                location=text_location,
                rotation=(1.5708, 0, 0),  # Rotation initiale
                scale=(1, 1, 1)
            )
            font_object = context.object
            font_object.name = f"{base_name}.t"
            font_object.data.name = original_mesh_data_name
            font_object.data.body = base_name.upper()
            font_object.data.align_x = 'CENTER'

            # Matériau pour le texte
            mat = bpy.data.materials.get("Text")
            if mat is None:
                mat = bpy.data.materials.new(name="Text")
                mat.use_nodes = True
                nodes = mat.node_tree.nodes
                links = mat.node_tree.links
                nodes.clear()
                emission_node = nodes.new(type='ShaderNodeEmission')
                emission_node.inputs['Strength'].default_value = 5.0
                emission_node.location = (0, 0)
                output_node = nodes.new(type='ShaderNodeOutputMaterial')
                output_node.location = (200, 0)
                links.new(emission_node.outputs['Emission'], output_node.inputs['Surface'])
            font_object.data.materials.append(mat)

            # Établir la hiérarchie: ligne -> texte
            font_object.parent = line_object
            font_object.matrix_parent_inverse = line_object.matrix_world.inverted()

            # Gérer les collections
            for collection in list(font_object.users_collection):
                collection.objects.unlink(font_object)
            for collection in list(line_object.users_collection):
                collection.objects.unlink(line_object)
            
            for collection in collections:
                collection.objects.link(line_object)
                collection.objects.link(font_object)

            # Parent de la ligne = ancien parent du mesh
            if parent:
                line_object.parent = parent
                line_object.matrix_parent_inverse = parent.matrix_world.inverted()

            # Les enfants du mesh deviennent enfants de la ligne
            for child in children:
                child.parent = line_object
                child.matrix_parent_inverse = line_object.matrix_world.inverted()

            # Configurer le texte pour la rotation automatique
            font_object.rotation_mode = 'QUATERNION'

            # Supprimer l'objet original
            bpy.ops.object.select_all(action='DESELECT')
            mesh_object.select_set(True)
            context.view_layer.objects.active = mesh_object
            bpy.data.objects.remove(mesh_object, do_unlink=True)
            
            # Sélectionner la ligne
            bpy.ops.object.select_all(action='DESELECT')
            line_object.select_set(True)
            context.view_layer.objects.active = line_object

        return {"FINISHED"}

class OBJECT_OT_convert_location_to_delta(bpy.types.Operator):
    bl_idname = "object.convert_location_to_delta"
    bl_label = "Convert location to delta"
    bl_description = "For all selected labels, convert location to delta_location and reset location to zero."
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return any(obj.name.endswith('.j') for obj in context.selected_objects)

    def execute(self, context):
        count = 0
        for obj in context.selected_objects:
            if obj.name.endswith('.j'):
                obj.delta_location = obj.location.copy()
                obj.location = Vector((0, 0, 0))
                count += 1
        self.report({'INFO'}, f"Converted location to delta_location on {count} label lines.")
        return {'FINISHED'}

class ZLABEL_OT_follow_viewport_operator(bpy.types.Operator):
    bl_idname = "wm.zlabel_follow_viewport_operator"
    bl_label = "Z-Label Follow Viewport"

    _timer = None

    def modal(self, context, event):
        if event.type == 'TIMER':
            # Obtenir l'orientation de la vue 3D
            viewport_orientation = None
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    viewport_orientation = area.spaces[0].region_3d.view_rotation
                    break
            
            if viewport_orientation:
                # Appliquer la rotation à tous les labels (.t)
                for obj in bpy.data.objects:
                    if obj.name.endswith('.t') and obj.type == 'FONT':
                        if obj.rotation_mode != 'QUATERNION':
                            obj.rotation_mode = 'QUATERNION'
                        obj.rotation_quaternion = viewport_orientation

        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        return self.execute(context)

    def execute(self, context):
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.1, window=context.window)
        wm.modal_handler_add(self)
        
        # Activer le suivi de la vue
        context.scene.zlabel_follow_viewport = True
        self.report({'INFO'}, "Label follow viewport activated")
        return {'RUNNING_MODAL'}

    def cancel(self, context):
        wm = context.window_manager
        if self._timer:
            wm.event_timer_remove(self._timer)
        context.scene.zlabel_follow_viewport = False
        self.report({'INFO'}, "Label follow viewport deactivated")

class VIEW3D_PT_z_label_panel(bpy.types.Panel):
    bl_label = "Z-Label1"
    bl_idname = "VIEW3D_PT_z_label_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Z-Anatomy'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout

        layout.operator("object.make_label_from_mesh", text="Convert Selected to Labels")
        layout.operator("object.place_label_above_vertex", text="Position label + hook automatically")
        layout.operator("object.convert_location_to_delta", text="Convert location to delta")

def register():
    # Propriété pour suivre l'état du suivi de la vue
    bpy.types.Scene.zlabel_follow_viewport = bpy.props.BoolProperty(
        name="Follow Viewport",
        description="Whether labels are automatically rotating to follow the viewport",
        default=False
    )

    classes = [
        OBJECT_OT_make_label_from_mesh,
        OBJECT_OT_place_label_above_vertex,
        OBJECT_OT_convert_location_to_delta,
        ZLABEL_OT_follow_viewport_operator,
        VIEW3D_PT_z_label_panel,
    ]

    for cls in classes:
        bpy.utils.register_class(cls)

    # Lancer automatiquement le follow viewport au démarrage
    bpy.ops.wm.zlabel_follow_viewport_operator('INVOKE_DEFAULT')

def unregister():
    # Arrêter l'opérateur modal s'il est en cours d'exécution
    if bpy.context.scene.zlabel_follow_viewport:
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                for region in area.regions:
                    if region.type == 'WINDOW':
                        override = {'window': bpy.context.window, 'screen': bpy.context.screen, 'area': area, 'region': region}
                        bpy.ops.wm.zlabel_follow_viewport_operator(override, 'CANCEL')
                        break
                break

    classes = [
        OBJECT_OT_make_label_from_mesh,
        OBJECT_OT_place_label_above_vertex,
        OBJECT_OT_convert_location_to_delta,
        ZLABEL_OT_follow_viewport_operator,
        VIEW3D_PT_z_label_panel,
    ]
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    
    del bpy.types.Scene.zlabel_follow_viewport

if __name__ == "__main__":
    try:
        unregister()
    except:
        pass
    register()