import bpy
import bmesh
from mathutils import Vector

bl_info = {
    "name": "Z-Label1",
    "blender": (2, 80, 0),
    "category": "Object",
    "description": "Convert selected meshes to labels, managing hierarchy and children.",
    "author": "Marcin Zielinski, Gauthier Kervyn",
    "version": (2, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > Z-Anatomy",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
}

_last_active_name = None
_timer = None

def clean_name(name):
    for ending in ('.r', '.l', '.t', '.j', '.o', '.e', ''):
        if ending == '':
            return name, ending
        elif name.endswith(ending):
            clean_name = name[:-len(ending)]
            return clean_name, ending

class OBJECT_OT_make_label_from_mesh(bpy.types.Operator):
    bl_idname = "object.make_label_from_mesh"
    bl_label = "Convert Selected to Labels"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and len(context.selected_objects) > 0

    def execute(self, context):
        selected_objects = context.selected_objects[:]
        bpy.ops.object.select_all(action='DESELECT')

        for mesh_object in selected_objects:
            if mesh_object.type != 'MESH':
                continue

            # Sauvegarder les informations avant modification
            parent = mesh_object.parent
            children = mesh_object.children[:]
            collections = mesh_object.users_collection[:]
            original_mesh_data_name = mesh_object.data.name
            
            # REMETTRE À ZÉRO LES TRANSFORMS ET DELTA TRANSFORMS
            self.reset_transforms(mesh_object)
            
            mesh_object.select_set(True)
            context.view_layer.objects.active = mesh_object

            base_name, _ = clean_name(mesh_object.name)

            # Calculer la position du texte (2.2 unités au-dessus du point le plus haut)
            text_location = mesh_object.location + Vector((0, 0, 2.2))
            if mesh_object.data and mesh_object.data.vertices:
                try:
                    highest_point = max((mesh_object.matrix_world @ v.co).z for v in mesh_object.data.vertices)
                    text_location = mesh_object.matrix_world @ Vector((0, 0, highest_point)) + Vector((0, 0, 2.2))
                except:
                    pass

            # Créer d'abord la ligne (.j) - qui sera le parent
            line_location = mesh_object.location
            
            # Créer les vertices de la ligne: [0] au mesh, [1] au texte
            verts = [
                Vector((0, 0, 0)),  # Vertex 0 - bas (sera hooké au mesh)
                Vector((0, 0, 2.2))  # Vertex 1 - haut (pointant vers la position du texte)
            ]
            edges = [[0, 1]]
            
            line_mesh_name = f"{original_mesh_data_name}.j"
            mesh_line = bpy.data.meshes.new(line_mesh_name)
            mesh_line.from_pydata(verts, edges, [])
            mesh_line.update()

            line_object = bpy.data.objects.new(f"{base_name}.j", mesh_line)
            line_object.location = line_location

            # Créer le texte (.t) - enfant de la ligne
            bpy.ops.object.text_add(
                radius=0.003 * 100,
                enter_editmode=False,
                align='WORLD',
                location=text_location,
                rotation=(1.5708, 0, 0),  # Rotation initiale
                scale=(1, 1, 1)
            )
            font_object = context.object
            font_object.name = f"{base_name}.t"
            font_object.data.name = original_mesh_data_name
            font_object.data.body = base_name.upper()
            font_object.data.align_x = 'CENTER'

            # Matériau pour le texte
            mat = bpy.data.materials.get("Text")
            if mat is None:
                mat = bpy.data.materials.new(name="Text")
                mat.use_nodes = True
                nodes = mat.node_tree.nodes
                links = mat.node_tree.links
                nodes.clear()
                emission_node = nodes.new(type='ShaderNodeEmission')
                emission_node.inputs['Strength'].default_value = 5.0
                emission_node.location = (0, 0)
                output_node = nodes.new(type='ShaderNodeOutputMaterial')
                output_node.location = (200, 0)
                links.new(emission_node.outputs['Emission'], output_node.inputs['Surface'])
            font_object.data.materials.append(mat)

            # Établir la hiérarchie: ligne -> texte
            font_object.parent = line_object
            font_object.matrix_parent_inverse = line_object.matrix_world.inverted()

            # Gérer les collections
            for collection in list(font_object.users_collection):
                collection.objects.unlink(font_object)
            for collection in list(line_object.users_collection):
                collection.objects.unlink(line_object)
            
            for collection in collections:
                collection.objects.link(line_object)
                collection.objects.link(font_object)

            # Parent de la ligne = ancien parent du mesh
            if parent:
                line_object.parent = parent
                line_object.matrix_parent_inverse = parent.matrix_world.inverted()

            # Les enfants du mesh deviennent enfants de la ligne
            for child in children:
                child.parent = line_object
                child.matrix_parent_inverse = line_object.matrix_world.inverted()

            # Configurer le texte pour la rotation automatique
            font_object.rotation_mode = 'QUATERNION'

            # ÉTAPE AJOUTÉE : Créer le hook du haut vers le texte
            self.create_top_hook(line_object, font_object)

            # Supprimer l'objet original
            bpy.ops.object.select_all(action='DESELECT')
            mesh_object.select_set(True)
            context.view_layer.objects.active = mesh_object
            bpy.data.objects.remove(mesh_object, do_unlink=True)
            
            # Sélectionner la ligne
            bpy.ops.object.select_all(action='DESELECT')
            line_object.select_set(True)
            context.view_layer.objects.active = line_object

        return {"FINISHED"}

    def reset_transforms(self, obj):
        """Remet à zéro tous les transforms et delta transforms d'un objet"""
        # Appliquer les transformations pour intégrer les transforms actuels dans la géométrie
        bpy.context.view_layer.objects.active = obj
        obj.select_set(True)
        
        # Appliquer la location, rotation et scale
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        
        # Remettre à zéro les delta transforms
        obj.delta_location = (0, 0, 0)
        obj.delta_rotation_euler = (0, 0, 0)
        obj.delta_rotation_quaternion = (1, 0, 0, 0)
        obj.delta_scale = (1, 1, 1)
        
        # Désélectionner l'objet
        obj.select_set(False)

    def create_top_hook(self, line_object, text_child):
        """Crée le hook du vertex 1 (haut) de la ligne vers le texte enfant"""
        if not text_child:
            return

        # Hooker le VERTEX 1 (le haut de la ligne) au texte
        bpy.ops.object.select_all(action='DESELECT')
        line_object.select_set(True)
        text_child.select_set(True)
        bpy.context.view_layer.objects.active = line_object
        
        # Passer en mode edit et sélectionner le vertex 1
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        
        bm_line = bmesh.from_edit_mesh(line_object.data)
        bm_line.verts.ensure_lookup_table()
        if len(bm_line.verts) > 1:
            bm_line.verts[1].select = True
        bmesh.update_edit_mesh(line_object.data)
        
        # Appliquer le hook avec la méthode manuelle
        bpy.ops.object.hook_add_selob()
        
        # Renommer le hook créé
        bpy.ops.object.mode_set(mode='OBJECT')
        for mod in line_object.modifiers:
            if mod.type == 'HOOK' and mod.object == text_child:
                mod.name = "Hook_Top"
                break

class ZLABEL_OT_follow_viewport_operator(bpy.types.Operator):
    bl_idname = "wm.zlabel_follow_viewport_operator"
    bl_label = "Z-Label Follow Viewport"

    _timer = None

    def modal(self, context, event):
        if event.type == 'TIMER':
            # Obtenir l'orientation de la vue 3D
            viewport_orientation = None
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    viewport_orientation = area.spaces[0].region_3d.view_rotation
                    break
            
            if viewport_orientation:
                # Appliquer la rotation à tous les labels (.t)
                for obj in bpy.data.objects:
                    if obj.name.endswith('.t') and obj.type == 'FONT':
                        if obj.rotation_mode != 'QUATERNION':
                            obj.rotation_mode = 'QUATERNION'
                        obj.rotation_quaternion = viewport_orientation

        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.1, window=context.window)
        wm.modal_handler_add(self)
        
        # Activer le suivi de la vue
        context.scene.zlabel_follow_viewport = True
        self.report({'INFO'}, "Label follow viewport activated")
        return {'RUNNING_MODAL'}

    def execute(self, context):
        # Cette méthode est appelée quand l'opérateur est exécuté directement
        return self.invoke(context, None)

    def cancel(self, context):
        wm = context.window_manager
        if self._timer:
            wm.event_timer_remove(self._timer)
        context.scene.zlabel_follow_viewport = False
        self.report({'INFO'}, "Label follow viewport deactivated")

class VIEW3D_PT_z_label_panel(bpy.types.Panel):
    bl_label = "Z-Label1"
    bl_idname = "VIEW3D_PT_z_label_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Z-Anatomy'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout

        layout.operator("object.make_label_from_mesh", text="Convert Selected to Labels")
        
        # Ajouter un bouton pour activer/désactiver le suivi de la vue
        row = layout.row()
        if context.scene.zlabel_follow_viewport:
            row.operator("wm.zlabel_follow_viewport_operator", text="Stop Viewport Follow", depress=True)
        else:
            row.operator("wm.zlabel_follow_viewport_operator", text="Start Viewport Follow")

def start_viewport_follow():
    """Démarre le suivi de la vueport si activé dans les préférences"""
    if bpy.context.scene.get('zlabel_auto_start_viewport', True):
        bpy.ops.wm.zlabel_follow_viewport_operator('INVOKE_DEFAULT')

def register():
    # Propriété pour suivre l'état du suivi de la vue
    bpy.types.Scene.zlabel_follow_viewport = bpy.props.BoolProperty(
        name="Follow Viewport",
        description="Whether labels are automatically rotating to follow the viewport",
        default=False
    )
    
    # Propriété pour le démarrage automatique
    bpy.types.Scene.zlabel_auto_start_viewport = bpy.props.BoolProperty(
        name="Auto Start Viewport Follow",
        description="Automatically start viewport follow when enabling the addon",
        default=True
    )

    classes = [
        OBJECT_OT_make_label_from_mesh,
        ZLABEL_OT_follow_viewport_operator,
        VIEW3D_PT_z_label_panel,
    ]

    for cls in classes:
        bpy.utils.register_class(cls)

    # Démarrage différé pour éviter les problèmes de contexte
    bpy.app.timers.register(start_viewport_follow, first_interval=1.0)

def unregister():
    # Arrêter l'opérateur modal s'il est en cours d'exécution
    if bpy.context.scene.zlabel_follow_viewport:
        bpy.ops.wm.zlabel_follow_viewport_operator('CANCEL')

    classes = [
        OBJECT_OT_make_label_from_mesh,
        ZLABEL_OT_follow_viewport_operator,
        VIEW3D_PT_z_label_panel,
    ]
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    
    del bpy.types.Scene.zlabel_follow_viewport
    del bpy.types.Scene.zlabel_auto_start_viewport

if __name__ == "__main__":
    try:
        unregister()
    except:
        pass
    register()