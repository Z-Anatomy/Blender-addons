# Z-Label1 for Blender

## Description

Z-Label1 is a Blender add-on designed for anatomical labeling workflows. It automatically creates and manages text labels with connecting lines, featuring automatic viewport-facing rotation and hierarchical organization.

## Features

- **Convert Selected to Labels**: Transform mesh objects into complete label systems (parent line + child text) with automatic hook creation
- **Automatic Top Hook**: Automatically creates hooks connecting the line's top vertex to the text label
- **Smart Hierarchy**: Line objects (`.j` suffix) act as parents to text labels (`.t` suffix) for organized structure
- **Automatic Viewport Rotation**: Labels automatically face the viewport without manual intervention
- **Streamlined Workflow**: Single-click conversion with all necessary setup included

## Installation

1. Download the `.py` file of the add-on
2. In Blender, go to `Edit > Preferences > Add-ons`
3. Click `Install...` and select the downloaded file
4. Enable the add-on by checking the box next to "Z-Label1"

## Usage

### Convert Meshes into Labels
- Select one or more mesh objects in Object Mode
- Click **Convert Selected to Labels** in the Z-Anatomy panel
- Each mesh becomes a line object (`.j`) with a child text label (`.t`)
- The top hook is automatically created between the line and text

### Panel Location
- Open the Sidebar in the 3D Viewport (press `N` if hidden)
- Navigate to the "Z-Anatomy" tab
- Find the "Z-Label1" panel

## Workflow Tips

- Labels automatically rotate to face the viewport - no manual control needed
- The line object serves as the parent, maintaining organizational hierarchy
- Text labels are automatically named with `.t` suffix
- Line objects are automatically named with `.j` suffix
- Original mesh hierarchy and collections are preserved during conversion

## Author

Gauthier KERVYN

## Compatibility

- Blender 2.80 and later versions

## Version

2.0

## License

This add-on is distributed under the CC-BY-SA 4.0 license.