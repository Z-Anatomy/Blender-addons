# Z-Label1 for Blender

## Description

Z-Label1 is a Blender add-on designed for anatomical labeling workflows. It automatically creates, positions, and manages text labels with connecting lines, featuring automatic viewport-facing rotation and hierarchical organization.

## Features

- **Convert Selected to Labels**: Transform mesh objects into label systems (parent line + child text)
- **Automatic Positioning & Hooking**: Position labels above specific vertices with automatic hook creation
- **Smart Hierarchy**: Line objects act as parents to text labels (`.t` suffix) for organized structure
- **Automatic Viewport Rotation**: Labels automatically face the viewport without manual intervention
- **Delta Location Conversion**: Convert positions to delta transforms for animation purposes
- **Streamlined Workflow**: Only essential functions for efficient labeling workflow

## Installation

1. Download the `.py` file of the add-on
2. In Blender, go to `Edit > Preferences > Add-ons`
3. Click `Install...` and select the downloaded file
4. Enable the add-on by checking the box next to "Z-Label1"

## Usage

### Convert Meshes into Labels
- Select one or more mesh objects in Object Mode
- Click **Convert Selected to Labels** in the Z-Anatomy panel
- Each mesh becomes a line object with a child text label (`.t`)

### Position Labels with Automatic Hooks
- Select the target mesh and a label line object
- Enter Edit Mode on the target mesh
- Select exactly one vertex
- Click **Position label + hook automatically**
- The label will be positioned above the vertex with hooks applied

### Convert to Delta Locations
- Select label line objects
- Click **Convert location to delta**
- Current positions are stored as `delta_location` and location resets to zero

## Workflow Tips

- Labels automatically rotate to face the viewport - no manual control needed
- The line object serves as the parent, maintaining organizational hierarchy
- Use delta locations when animating label positions
- Hook system ensures labels stay connected to specific mesh vertices

## Author

Gauthier KERVYN

## Compatibility

- Blender 2.80 and later versions

## Version

2.0

## License

This add-on is distributed under the CC-BY-SA 4.0 license.