# This program is free software: you can redistribute it and/or modify
# it under the terms of the Creative Commons Attribution-ShareAlike 4.0 International License (CC-BY-SA 4.0).
# 
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# For more information, visit the official license page: https://creativecommons.org/licenses/by-sa/4.0/

bl_info = {
    "name": "Z-Wiki",
    "author": "Marcin Zieliński, Z-Anatomy",
    "description": "Tools to download texts from Wiki in Z-Anatomy.",
    "blender": (2, 80, 0),
    "version": (0, 0, 1),
    "location": "",
    "warning": "",
    "category": "Interface"
}

import bpy
import requests
import json
import urllib.parse
import re

class TEXT_OT_wiki_download(bpy.types.Operator):
    bl_idname = "text.wiki_download"
    bl_label = "Download Texts From Wiki"
    bl_options = {'REGISTER'}

    def execute(self, context):
        if not "Wiki Phrases" in bpy.data.texts:
            self.report(type={"ERROR"}, message="Create 'Wiki Phrases' text file.")
            return {"CANCELLED"}

        phrases = bpy.data.texts["Wiki Phrases"].as_string().splitlines()
        not_matched = []
        partial_matches = []
        full_matches = []
        for i, possible_title in enumerate(phrases):
            print(f"Extract {i+1}/{len(phrases)}, " + possible_title)
            search_url = f"https://en.wikipedia.org/w/api.php?action=query&format=json&prop=&list=search&continue=-%7C%7Clanglinks&srsearch={urllib.parse.quote_plus(possible_title)}&srnamespace=0&srlimit=1&srinfo=&srprop="

            resp = requests.get(search_url).json()

            try:
                if len(resp['query']['search']) == 0:
                    print(' ##### Object not matched:', possible_title)
                    not_matched.append(possible_title)
                    continue
                title = resp['query']['search'][0]['title']
            except Exception as e:
                print(e)
                print(json.dumps(resp, indent=2))
                continue

            diff = len(set(title.lower()) ^ set(possible_title.lower()))

            if diff > 3:
                print(' ##### Object not matched:', possible_title)
                not_matched.append(possible_title)
                continue
            elif title.lower() != possible_title.lower():
                print(f' +++++ Object partial match ({diff}):', possible_title)
                partial_matches.append(possible_title)

            extract_url = f"https://en.wikipedia.org/w/api.php?action=query&format=json&titles={urllib.parse.quote_plus(title)}&prop=extracts|info&explaintext&inprop=url"

            resp = requests.get(extract_url).json()
            wiki_page = resp['query']['pages'].popitem()[1]
            extract = wiki_page['extract']
            wiki_url = wiki_page['canonicalurl']

            if extract.startswith(f"{title} may refer to:"):
                print(' ????? Object not matched (multi-results page):', possible_title)
                not_matched.append(possible_title)
                continue
            full_matches.append(possible_title)

            if title in bpy.data.texts:
                text_edit = bpy.data.texts[title]
                text_edit.clear()
            else:
                text_edit = bpy.data.texts.new(title)

            extract += '\n'*3
            for paragraph in ("== Additional images ==", "== See also ==", "== References ==", "== External links =="):
                extract = re.sub(rf'{paragraph}\n+.*?\n\n\n', '', extract, flags=re.MULTILINE|re.DOTALL)

            extract = re.sub(r'( ==\n)(.?)', r'\1\n\2', extract, flags=re.MULTILINE)
            extract = re.sub(r'( ===\n)(.?)', r'\1\n\2', extract, flags=re.MULTILINE)
            extract = re.sub(r'  ', r' ', extract)
            extract = re.sub(r'(\. )([A-Z])', r'\1\n\n\2', extract)
            extract = re.sub(r' \[Fig\. \d+\]', r'', extract)

            body = "\n"*2 + title.upper() + "\n"*3 + extract + "\n" + wiki_url
            text_edit.write(body)
            text_edit.cursor_set(0)

        if 'Wiki Results' in bpy.data.texts:
            wiki_results = bpy.data.texts['Wiki Results']
            wiki_results.clear()
        else:
            wiki_results = bpy.data.texts.new('Wiki Results')
        body = "===== Wiki download report =====\n"
        body += " ## Partial matches (check manually) ##\n"
        body += "\n".join(partial_matches) + "\n"*5
        body += " ## Not matched ##\n"
        body += "\n".join(not_matched) + "\n"*5
        body += " ## Fully matched ##\n"
        body += "\n".join(full_matches) + "\n"*5
        wiki_results.write(body)
        wiki_results.cursor_set(0)

        return {"FINISHED"}

class ZANATOMY_PT_wiki_panel(bpy.types.Panel):
    bl_label = "Wiki Tools"
    bl_idname = "VIEW3D_PT_z_wiki_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Z-Anatomy'

    def draw(self, context):
        layout = self.layout
        layout.operator("text.wiki_download")

def register():
    bpy.utils.register_class(TEXT_OT_wiki_download)
    bpy.utils.register_class(ZANATOMY_PT_wiki_panel)

def unregister():
    bpy.utils.unregister_class(TEXT_OT_wiki_download)
    bpy.utils.unregister_class(ZANATOMY_PT_wiki_panel)

if __name__ == "__main__":
    register()
