# Z-Wiki Add-on for Blender

## Description

Z-Wiki is a Blender add-on designed to facilitate the downloading of texts from Wikipedia directly into your Blender projects. It provides tools to search and integrate Wikipedia articles into your workflow, making it easier to access reference materials and documentation.

## Features

- Download Wikipedia articles based on phrases listed in a Blender text file.
- Automatically format and clean the extracted text for better readability.
- Integrate downloaded articles directly into Blender's text editor for easy access.
- Provide a report of matched and unmatched phrases for manual review.

## Installation

1. Download the `.zip` file of the add-on.
2. Open Blender and go to `Edit` > `Preferences`.
3. Select the `Add-ons` tab and click the downward-facing arrow in the top-right corner.
4. Choose `Install from Disk` and select the downloaded `.zip` file.
5. Enable the add-on by checking the box next to "Z-Wiki".

## Usage

### Downloading Texts

1. Create a text file named "Wiki Phrases" in Blender's text editor and list the phrases you want to search on Wikipedia, each on a new line.
2. Use the "Download Texts From Wiki" operator to fetch the articles.
3. The downloaded articles will be saved as new text files in Blender, and a report will be generated in a text file named "Wiki Results".

### Panel

The add-on includes a panel in the 3D View UI under the "Z-Anatomy" category, providing easy access to the Wikipedia download tool.

## Author

- **Marcin Zieliński**
- **Z-Anatomy**

## Compatibility

- Blender 2.80 and later versions.

## License

This add-on is distributed under the [CC-BY-SA 4.0](LICENSE) license, which allows sharing and adaptation with attribution and under the same terms.
