# Z-KeyColors Add-on for Blender

## Description

Z-KeyColors is a Blender add-on that provides tools to manage key colors in Z-Anatomy. It allows users to define and toggle key colors for objects and collections.

## Features

- Assigns a "Key Color" property to objects.
- Allows toggling of the key color property for all relevant objects.
- Updates the UI automatically when changes are made.

## Installation

1. Download the `.zip` file of the add-on.
2. Open Blender and go to `Edit` > `Preferences`.
3. Select the `Add-ons` tab and click the downward-facing arrow in the top-right corner.
4. Choose `Install from Disk` and select the downloaded `.zip` file.
5. Enable the add-on by checking the box next to "Z-Label".

## Usage

### Key Color Property

1. Open the **N** panel and go to the **Z-Anatomy** tab.
2. Locate the **Key Colors** panel.
3. Toggle the **Key Color** property to apply it to all relevant objects.

### Material Setup

A `.blend` file is included in the `.zip` package as an example of how to structure materials affected by the key color property. To use it:

1. Open the provided `.blend` file.
2. Check the node setup for materials using the key color property.
3. Apply the same structure to your own materials.

## Author

- **Marcin Zieliński**
- **Z-Anatomy**

## Compatibility

- Blender 2.80 and later versions.

## License

This add-on is distributed under the [CC-BY-SA 4.0](LICENSE) license, which allows sharing and adaptation with attribution and under the same terms.

