# This program is free software: you can redistribute it and/or modify
# it under the terms of the Creative Commons Attribution-ShareAlike 4.0 International License (CC-BY-SA 4.0).
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# For more information, visit the official license page: https://creativecommons.org/licenses/by-sa/4.0/

bl_info = {
    "name": "Z-CurveIt",
    "author": "Gauthier KERVYN, Z-Anatomy",
    "version": (1, 0, 1),
    "blender": (4, 5, 0),
    "location": "View3D > N Panel > Z-Anatomy",
    "description": "Converts the active mesh object into a Bézier curve while preserving object and data names.",
    "category": "Object",
}

import bpy


# =============================================
# Fonction principale
# =============================================

def _make_active(context, obj):
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    context.view_layer.objects.active = obj


def _replace_mesh_with_single_edge(obj):
    """Replace the mesh geometry with one centered edge in local space."""
    mesh = obj.data
    mesh.clear_geometry()
    mesh.from_pydata([(-0.1, 0.0, 0.0), (0.1, 0.0, 0.0)], [(0, 1)], [])
    mesh.update()


def create_edge_and_convert_to_bezier(context=None):
    """Convert the active mesh object into a Bézier curve.

    The object name and the original mesh data name are restored after conversion.
    Example:
    Object.name: 'Arteria X.r', Object.data.name: '1234.r', Type: MESH
    becomes:
    Object.name: 'Arteria X.r', Object.data.name: '1234.r', Type: CURVE
    """
    context = context or bpy.context
    obj = context.active_object

    if obj is None:
        bpy.ops.mesh.primitive_plane_add(size=2)
        obj = context.active_object

    if obj.type != 'MESH':
        raise TypeError("Z-CurveIt needs an active MESH object, or no active object so it can create one.")

    original_object_name = obj.name
    original_data_name = obj.data.name

    _make_active(context, obj)
    _replace_mesh_with_single_edge(obj)

    bpy.ops.object.convert(target='CURVE')
    obj = context.active_object
    curve = obj.data

    obj.name = original_object_name
    curve.name = original_data_name

    # Convert the created poly spline to Bézier through Blender's curve operator.
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.curve.select_all(action='SELECT')
    try:
        bpy.ops.curve.spline_type_set(type='BEZIER')
    except Exception:
        # Keep the curve usable even if Blender changes this operator in a future version.
        pass
    bpy.ops.curve.handle_type_set(type='AUTOMATIC')
    bpy.ops.curve.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')

    curve = obj.data
    curve.name = original_data_name
    curve.bevel_depth = 0.5

    for spline in curve.splines:
        for point in getattr(spline, 'bezier_points', []):
            point.radius = 0.3
        for point in getattr(spline, 'points', []):
            point.radius = 0.3

    bpy.ops.object.shade_smooth()

    print(
        "Object converted to curve. "
        f"Object.name kept as: {original_object_name}; "
        f"Object.data.name kept as: {original_data_name}"
    )


# =============================================
# Opérateur Blender
# =============================================

class ZANATOMY_OT_create_edge_and_convert_to_bezier(bpy.types.Operator):
    bl_idname = "zanatomy.create_edge_and_convert_to_bezier"
    bl_label = "Create Edge and Convert to Bézier"
    bl_description = "Convert the active mesh object into a Bézier curve while preserving object and data names"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            create_edge_and_convert_to_bezier(context)
        except TypeError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        self.report({"INFO"}, "Object converted to Bézier curve. Object and data names preserved.")
        return {"FINISHED"}


# =============================================
# Panneau Z-Anatomy
# =============================================

class VIEW3D_PT_z_anatomy_curveit(bpy.types.Panel):
    """Panneau pour Z-CurveIt dans le N-Panel."""
    bl_label = "Z-CurveIt"
    bl_idname = "VIEW3D_PT_z_anatomy_curveit"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Z-Anatomy'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.operator("zanatomy.create_edge_and_convert_to_bezier", icon="CURVE_BEZCURVE")


# =============================================
# Enregistrement des classes
# =============================================

def register():
    bpy.utils.register_class(ZANATOMY_OT_create_edge_and_convert_to_bezier)
    bpy.utils.register_class(VIEW3D_PT_z_anatomy_curveit)


def unregister():
    bpy.utils.unregister_class(VIEW3D_PT_z_anatomy_curveit)
    bpy.utils.unregister_class(ZANATOMY_OT_create_edge_and_convert_to_bezier)


if __name__ == "__main__":
    register()
