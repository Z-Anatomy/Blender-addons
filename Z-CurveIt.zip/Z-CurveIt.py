# This program is free software: you can redistribute it and/or modify
# it under the terms of the Creative Commons Attribution-ShareAlike 4.0 International License (CC-BY-SA 4.0).
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# For more information, visit the official license page: https://creativecommons.org/licenses/by-sa/4.0/

bl_info = {
    "name": "Z-CurveIt",
    "author": "Gauthier KERVYN, Z-Anatomy",
    "version": (1, 0, 2),
    "blender": (4, 5, 0),
    "location": "View3D > N Panel > Z-Anatomy",
    "description": "Replace the active mesh object with a Bézier curve while preserving object and data names.",
    "category": "Object",
}

import bpy


# =============================================
# Helpers
# =============================================


def _copy_vector_attr(src, dst, attr_name):
    try:
        setattr(dst, attr_name, getattr(src, attr_name)[:])
    except Exception:
        pass


def _copy_basic_object_settings(src, dst):
    """Copy safe object-level settings from the original object."""
    for attr_name in (
        "hide_viewport",
        "hide_select",
        "hide_render",
        "show_name",
        "show_in_front",
        "display_type",
        "color",
    ):
        try:
            setattr(dst, attr_name, getattr(src, attr_name))
        except Exception:
            pass

    _copy_vector_attr(src, dst, "lock_location")
    _copy_vector_attr(src, dst, "lock_rotation")
    _copy_vector_attr(src, dst, "lock_scale")

    try:
        dst.rotation_mode = src.rotation_mode
    except Exception:
        pass

    # Copy custom properties, if any.
    try:
        for key in src.keys():
            dst[key] = src[key]
    except Exception:
        pass


def _copy_materials(src_obj, curve_data):
    try:
        for slot in src_obj.material_slots:
            if slot.material is not None:
                curve_data.materials.append(slot.material)
    except Exception:
        pass


def _make_single_bezier_curve(data_name):
    """Create a small 3D Bézier curve centered on the object's origin."""
    curve = bpy.data.curves.new(name=data_name, type="CURVE")
    curve.dimensions = "3D"
    curve.resolution_u = 12
    curve.bevel_depth = 0.5
    curve.bevel_resolution = 4

    spline = curve.splines.new(type="BEZIER")
    spline.bezier_points.add(1)  # total: 2 points

    coords = [(-0.1, 0.0, 0.0), (0.1, 0.0, 0.0)]
    for point, coord in zip(spline.bezier_points, coords):
        point.co = coord
        point.handle_left_type = "AUTO"
        point.handle_right_type = "AUTO"
        point.radius = 0.3

    return curve


def _deselect_all_objects(context):
    try:
        for scene_obj in context.scene.objects:
            scene_obj.select_set(False)
    except Exception:
        # Fallback; normally not needed, but harmless when context allows it.
        try:
            bpy.ops.object.select_all(action="DESELECT")
        except Exception:
            pass


def _create_curve_object(context):
    """Create a new curve when there is no active mesh object."""
    curve = _make_single_bezier_curve("Curve")
    obj = bpy.data.objects.new("Curve", curve)
    context.collection.objects.link(obj)

    _deselect_all_objects(context)
    obj.select_set(True)
    context.view_layer.objects.active = obj
    return obj


def _replace_mesh_object_with_curve(context, obj):
    """Replace a mesh object with a curve object, preserving names and placement.

    This avoids bpy.ops.curve.select_all / bpy.ops.curve.spline_type_set because those
    operators can fail from addon panel contexts in recent Blender versions.
    """
    original_object_name = obj.name
    original_data_name = obj.data.name
    original_matrix_world = obj.matrix_world.copy()
    original_parent = obj.parent
    original_matrix_parent_inverse = obj.matrix_parent_inverse.copy()
    original_collections = list(obj.users_collection) or [context.collection]
    original_children = list(obj.children)
    original_mesh_data = obj.data

    curve_data = _make_single_bezier_curve(original_data_name)
    _copy_materials(obj, curve_data)

    # Use a temporary name while the old object still exists.
    new_obj = bpy.data.objects.new(original_object_name + "__ZCurveIt_TMP", curve_data)

    for collection in original_collections:
        collection.objects.link(new_obj)

    _copy_basic_object_settings(obj, new_obj)

    # Preserve parenting and world transform.
    new_obj.parent = original_parent
    new_obj.matrix_parent_inverse = original_matrix_parent_inverse
    new_obj.matrix_world = original_matrix_world

    # Preserve children world transforms while reparenting them to the new object.
    for child in original_children:
        try:
            child_world = child.matrix_world.copy()
            child.parent = new_obj
            child.matrix_world = child_world
        except Exception:
            pass

    # Remove old mesh object, then restore the exact object name.
    bpy.data.objects.remove(obj, do_unlink=True)
    new_obj.name = original_object_name
    new_obj.data.name = original_data_name

    # Clean unused old mesh data if possible.
    try:
        if original_mesh_data.users == 0:
            bpy.data.meshes.remove(original_mesh_data)
    except Exception:
        pass

    _deselect_all_objects(context)
    new_obj.select_set(True)
    context.view_layer.objects.active = new_obj

    return new_obj


# =============================================
# Main function
# =============================================


def create_edge_and_convert_to_bezier(context=None):
    """Create/replace with a Bézier curve.

    If the active object is a mesh, it is replaced by a curve while preserving:
    - Object.name
    - Object.data.name
    - world transform
    - collection membership

    Example:
    Object.name: 'Arteria X.r', Object.data.name: '1234.r', Type: MESH
    becomes:
    Object.name: 'Arteria X.r', Object.data.name: '1234.r', Type: CURVE
    """
    context = context or bpy.context
    obj = context.active_object

    if obj is None:
        new_obj = _create_curve_object(context)
    elif obj.type == "MESH":
        new_obj = _replace_mesh_object_with_curve(context, obj)
    else:
        raise TypeError("Z-CurveIt needs an active MESH object, or no active object so it can create a new curve.")

    print(
        "Z-CurveIt: curve ready. "
        f"Object.name: {new_obj.name}; "
        f"Object.data.name: {new_obj.data.name}; "
        f"Type: {new_obj.type}"
    )
    return new_obj


# =============================================
# Blender operator
# =============================================


class ZANATOMY_OT_create_edge_and_convert_to_bezier(bpy.types.Operator):
    bl_idname = "zanatomy.create_edge_and_convert_to_bezier"
    bl_label = "Create Edge and Convert to Bézier"
    bl_description = "Replace the active mesh with a Bézier curve while preserving object and data names"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        try:
            create_edge_and_convert_to_bezier(context)
        except TypeError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        self.report({"INFO"}, "Z-CurveIt: curve created. Object and data names preserved.")
        return {"FINISHED"}


# =============================================
# Z-Anatomy panel
# =============================================


class VIEW3D_PT_z_anatomy_curveit(bpy.types.Panel):
    """Panel for Z-CurveIt in the N-Panel."""
    bl_label = "Z-CurveIt"
    bl_idname = "VIEW3D_PT_z_anatomy_curveit"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Z-Anatomy"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        layout.operator("zanatomy.create_edge_and_convert_to_bezier", icon="CURVE_BEZCURVE")


# =============================================
# Registration
# =============================================


classes = (
    ZANATOMY_OT_create_edge_and_convert_to_bezier,
    VIEW3D_PT_z_anatomy_curveit,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()