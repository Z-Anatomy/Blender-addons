# This program is free software: you can redistribute it and/or modify
# it under the terms of the Creative Commons Attribution-ShareAlike 4.0 International License (CC-BY-SA 4.0).
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# For more information, visit the official license page: https://creativecommons.org/licenses/by-sa/4.0/

bl_info = {
    "name": "Z-List",
    "author": "Gauthier KERVYN, Z-Anatomy",
    "version": (1, 0, 0),
    "blender": (4, 5, 0),
    "location": "View3D > N Panel > Z-Anatomy",
    "description": "Copies the names of selected objects to the clipboard.",
    "category": "Object",
}

import bpy

def copy_selected_objects_to_clipboard():
    """Copie la liste des objets sélectionnés dans le presse-papiers."""
    selected_objects = bpy.context.selected_objects
    if not selected_objects:
        bpy.context.window_manager.clipboard = "Aucun objet sélectionné."
    else:
        obj_names = "\n".join(obj.name for obj in selected_objects)
        bpy.context.window_manager.clipboard = obj_names

class ZANATOMY_OT_copy_selected_objects(bpy.types.Operator):
    bl_idname = "zanatomy.copy_selected_objects"
    bl_label = "Copy names"
    bl_description = "Copy the list of selected objects to clipboard"

    def execute(self, context):
        copy_selected_objects_to_clipboard()
        self.report({"INFO"}, "Liste des objets copiée dans le presse-papiers.")
        return {"FINISHED"}

class VIEW3D_PT_z_anatomy_list(bpy.types.Panel):
    """Creates a Panel in the Object properties window"""
    bl_label = "List selection"
    bl_idname = "VIEW3D_PT_z_anatomy_list"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Z-Anatomy'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.operator("zanatomy.copy_selected_objects", icon="COPYDOWN")

def register():
    bpy.utils.register_class(ZANATOMY_OT_copy_selected_objects)
    bpy.utils.register_class(VIEW3D_PT_z_anatomy_list)

def unregister():
    bpy.utils.unregister_class(ZANATOMY_OT_copy_selected_objects)
    bpy.utils.unregister_class(VIEW3D_PT_z_anatomy_list)

if __name__ == "__main__":
    register()
