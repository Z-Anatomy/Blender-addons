# Z-List Add-on for Blender
## Description
Z-List is a Blender add-on that copies the names of selected objects to the clipboard. It is designed to simplify the process of exporting object lists for documentation, scripting, or external tools.

## Features
- Copies the names of all selected objects to the clipboard in one click.
- Simple and intuitive UI panel integrated into the **Z-Anatomy** tab.
- Useful for generating lists of objects for scripts, documentation, or external processing.

## Installation
1. Download the `.zip` file of the add-on.
2. Open Blender and go to `Edit > Preferences`.
3. Select the `Add-ons` tab and click the downward-facing arrow in the top-right corner.
4. Choose `Install from Disk` and select the downloaded `.zip` file.
5. Enable the add-on by checking the box next to **"Z-List"**.

## Usage
1. Select the objects whose names you want to copy.
2. Open the **N-panel** in the 3D Viewport.
3. Navigate to the **"Z-Anatomy"** tab.
4. Click the **"Copy names"** button in the **"List selection"** section.
5. The names of the selected objects are now in your clipboard, ready to be pasted elsewhere.

## Author
- **Gauthier KERVYN**
- **Z-Anatomy**

## Compatibility
- Blender 4.5 and later versions.

## License
This add-on is distributed under the [CC-BY-SA 4.0](LICENSE) license, which allows sharing and adaptation with attribution and under the same terms.
