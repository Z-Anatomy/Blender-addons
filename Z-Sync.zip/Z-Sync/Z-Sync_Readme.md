# Z-Sync Add-on for Blender

## Description

Z-Sync is a Blender add-on designed to synchronize the visibility of objects in the viewport with their render visibility in Z-Anatomy. This tool simplifies the process of managing object visibility, ensuring that only visible objects are rendered.

## Features

- Synchronize the render visibility of objects with their viewport visibility.
- Toggle render visibility for all objects in the scene with a single operation.
- Provides a user-friendly interface for easy access to synchronization tools.

## Installation

1. Download the `.zip` file of the add-on.
2. Open Blender and go to `Edit` > `Preferences`.
3. Select the `Add-ons` tab and click the downward-facing arrow in the top-right corner.
4. Choose `Install from Disk` and select the downloaded `.zip` file.
5. Enable the add-on by checking the box next to "Z-Sync".

## Usage

### Synchronizing Visibility

1. Ensure you are in Object Mode.
2. Use the "Render what is visible" operator to synchronize the render visibility of all objects in the scene.
3. The tool will toggle the render visibility based on the current viewport visibility of each object.

### Panel

The add-on includes a panel in the 3D View UI under the "Z-Anatomy" category, providing easy access to the visibility synchronization tool.

## Author

- **Marcin Zieliński**
- **Z-Anatomy**

## Compatibility

- Blender 2.80 and later versions.

## License

This add-on is distributed under the [CC-BY-SA 4.0](LICENSE) license, which allows sharing and adaptation with attribution and under the same terms.
