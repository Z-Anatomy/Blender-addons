bl_info = {
    "name": "Z-Mirror",
    "author": "Gauthier Kervyn, Z-Anatomy",
    "version": (0, 0, 1),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > Z-Anatomy",
    "description": "Activate or deactivate Mirror Modifiers on main collections",
    "warning": "",
    "category": "Interface",
}

import bpy

class ZANATOMY_PT_sync_panel(bpy.types.Panel):
    bl_label = "Z-Mirror"
    bl_idname = "VIEW3D_PT_Symmetrize"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Z-Anatomy'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        # Récupérer les collections principales (enfants directs de la Scene Collection)
        main_collections = [
            col for col in bpy.context.scene.collection.children
            if not col.hide_viewport
            and any(
                obj.type == 'MESH'
                and any(m.type == 'MIRROR' for m in obj.modifiers)
                for obj in col.objects
            )
        ]
        # Afficher toutes les collections principales pertinentes, dans l'ordre de la View Layer
        for collection in main_collections:
            row = layout.row()
            row.prop(collection, "zanatomy_mirror_enabled", text=collection.name)

def update_mirror_modifiers(collection, context):
    for obj in collection.objects:
        if obj.type == 'MESH':
            for modifier in obj.modifiers:
                if modifier.type == 'MIRROR':
                    modifier.show_viewport = collection.zanatomy_mirror_enabled
                    modifier.show_render = collection.zanatomy_mirror_enabled

def register():
    bpy.types.Collection.zanatomy_mirror_enabled = bpy.props.BoolProperty(
        name="Enable Mirror",
        description="Enable or disable all Mirror modifiers in this collection",
        default=True,
        update=lambda self, context: update_mirror_modifiers(self.id_data, context)
    )
    bpy.utils.register_class(ZANATOMY_PT_sync_panel)

def unregister():
    del bpy.types.Collection.zanatomy_mirror_enabled
    bpy.utils.unregister_class(ZANATOMY_PT_sync_panel)

if __name__ == "__main__":
    register()
