bl_info = {
    "name": "Z-Display",
    "author": "Marcin Zieliński, Morgan Le Chénéchal, Z-Anatomy",
    "description": "Smart hiding tools for Blender objects and collections",
    "blender": (2, 80, 0),
    "version": (0, 0, 1),
    "location": "View3D > Sidebar > Z-Anatomy",
    "warning": "",
    "category": "Interface"
}

import bpy
from bpy_extras.object_utils import object_data_add

# Ensemble des éléments de label
label_elements = {".t", ".j", ".s", ".i"}


def family_all(object):
    ''' Object + Grand children without ancestors '''
    family = [object.children[:] + (object,)]

    def rec(object, family):
        family[0] += object.children
        for ob in object.children:
            rec(ob, family)

    for ob in object.children:
        rec(ob, family)

    return family.pop()


def family(object):
    ''' Object + Grand children without ancestors (labels only) '''
    def inner_elements(children):
        return tuple(ob for ob in children if any(x in ob.name for x in label_elements))

    labels = inner_elements(object.children)
    family = [labels + (object,)]

    def rec(object, family):
        labels = inner_elements(object.children)
        family[0] += labels
        for ob in labels:
            rec(ob, family)

    for ob in object.children:
        rec(ob, family)

    return family.pop()


class OBJECT_OT_hide_wrapper(bpy.types.Operator):
    """Hide"""
    bl_idname = "object.hide_wrapper"
    bl_label = "Hide"
    bl_options = {'REGISTER', 'UNDO'}

    unselected: bpy.props.BoolProperty(default=True, name="Hide unselected")
    unselected_in_layer: bpy.props.BoolProperty(default=True, name="From active layer")
    follow_parent: bpy.props.BoolProperty(default=True, name="Follow parent's visibility")

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.object is not None

    def execute(self, context):
        def findRoot(ob):
            while ob and ob.parent:
                if ob in objects_to:
                    objects_to.remove(ob)
                if not any(x in ob.name for x in label_elements):
                    return ob
                if not ob.parent.parent and not self.unselected:
                    return ob
                ob = ob.parent
            return ob

        roots = []
        objects_to = set(context.selected_objects)

        while objects_to:
            ob = objects_to.pop()
            roots.append(findRoot(ob))

        if self.unselected and not self.unselected_in_layer:
            all_visible_objects = set(context.visible_objects)
            lights = {l for l in context.view_layer.objects if l.type == 'LIGHT'}

            family_obs = (ob for r in roots for ob in family(r))
            for ob in all_visible_objects - lights - set(family_obs):
                ob.hide_set(True)
        elif self.unselected and self.unselected_in_layer:
            all_layer_objects = set()
            for c in context.scene.collection.children:
                if context.object.name in c.all_objects:
                    all_layer_objects = set(c.all_objects)
                    break
            lights = {l for l in context.view_layer.objects if l.type == 'LIGHT'}

            family_obs = (ob for r in roots for ob in family(r))
            for ob in all_layer_objects - set(family_obs) - lights:
                ob.hide_set(True)
        else:
            if self.follow_parent:
                family_obs = (ob for r in roots for ob in family_all(r))
            else:
                family_obs = (ob for r in roots for ob in family(r))

            for ob in family_obs:
                ob.hide_set(True)

        return {'FINISHED'}


class OBJECT_OT_hide_view_clear_wrapper(bpy.types.Operator):
    """Show Hidden Objects"""
    bl_idname = "object.hide_view_clear_wrapper"
    bl_label = "Show Hidden Objects"
    bl_options = {'REGISTER', 'UNDO'}

    select: bpy.props.BoolProperty()
    active_layer: bpy.props.BoolProperty(default=True, name="Affect only active layer")

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        if self.active_layer:
            for col in context.scene.collection.children:
                if context.object.name in col.all_objects:
                    break

            for ob in col.all_objects:
                ob.hide_set(False)
        else:
            bpy.ops.object.hide_view_clear(select=self.select)

        if context.scene.z_display_only_active_labels:
            for ob in (o for o in bpy.context.visible_objects if any(x in o.name for x in label_elements) and o != context.object):
                if not ob.parent == context.object:
                    ob.hide_set(True)
                    for child in ob.children:
                        child.hide_set(True)

        return {'FINISHED'}


class OBJECT_OT_local_view_wrapper(bpy.types.Operator):
    """Local view (with lights)"""
    bl_idname = "view3d.localview_lights"
    bl_label = "Local View (w/ lights)"

    frame_selected: bpy.props.BoolProperty(default=True, name="Frame Selected")

    @classmethod
    def poll(cls, context):
        if context.area is None or context.area.type != 'VIEW_3D':
            return False
        if context.object is None:
            return False
        return context.mode == 'OBJECT' or context.mode == 'POSE' or context.mode.startswith('EDIT')

    def execute(self, context):
        def findRoot(ob):
            while ob and ob.parent:
                if ob in objects_to:
                    objects_to.remove(ob)
                if not any(x in ob.name for x in label_elements):
                    return ob
                if not ob.parent.parent:
                    return ob
                ob = ob.parent
            return ob

        active_object = context.object
        original_mode = context.mode
        restore_mode = None

        selected_objects = list(context.selected_objects)
        if active_object and active_object not in selected_objects:
            selected_objects.append(active_object)

        if original_mode != 'OBJECT':
            if original_mode == 'POSE':
                restore_mode = 'POSE'
            elif original_mode.startswith('EDIT'):
                restore_mode = 'EDIT'

            try:
                bpy.ops.object.mode_set(mode='OBJECT')
            except Exception:
                return {'CANCELLED'}

        objects_to = set(selected_objects)
        roots = []
        while objects_to:
            ob = objects_to.pop()
            roots.append(findRoot(ob))

        lights = [o for o in context.visible_objects if o.type == 'LIGHT']
        hide_selects = []
        hidden = []
        obj_family = []
        seen = set()

        def add_local_object(ob):
            if ob is None:
                return
            ptr = ob.as_pointer()
            if ptr in seen:
                return
            seen.add(ptr)
            obj_family.append(ob)

        for obj in roots:
            for ob in family(obj):
                add_local_object(ob)
        for ob in lights:
            add_local_object(ob)

        for ob in obj_family:
            if ob.hide_get():
                ob.hide_set(False)
                hidden.append(ob)
            if ob.hide_select:
                ob.hide_select = False
                hide_selects.append(ob)
            ob.select_set(True)

        if active_object:
            context.view_layer.objects.active = active_object

        bpy.ops.view3d.localview('INVOKE_DEFAULT', frame_selected=self.frame_selected)

        for ob in obj_family:
            ob.select_set(False)
        for ob in hide_selects:
            ob.hide_select = True
        for ob in hidden:
            ob.hide_set(True)

        for ob in selected_objects:
            if ob.name in bpy.data.objects:
                ob.select_set(True)
        if active_object and active_object.name in bpy.data.objects:
            context.view_layer.objects.active = active_object

        bpy.ops.view3d.view_selected()

        if restore_mode is not None:
            try:
                bpy.ops.object.mode_set(mode=restore_mode)
            except Exception:
                pass

        return {"FINISHED"}

class ZANATOMY_PT_display_panel(bpy.types.Panel):
    bl_label = "Z-display"
    bl_idname = "VIEW3D_PT_z_display"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Z-Anatomy'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        prefs = get_addon_preferences()
        if prefs is not None:
            layout.prop(prefs, "use_custom_keymap", text="Enable custom shortcuts")
        layout.prop(context.scene, "z_display_only_active_labels")
        layout.operator("object.hide_wrapper", text="Isolate on Layer")
        layout.operator("object.hide_view_clear_wrapper", text="Unhide Layer")
        layout.operator("view3d.localview_lights", text="Local View with Lights")


addon_keymaps_custom = []
addon_keymaps_shared = []
disabled_default_keymap_items_custom = []
disabled_default_keymap_items_shared = []

CUSTOM_KEYMAP_DEFS = (
    ('3D View', 'VIEW_3D', 'WINDOW', 'view3d.localview_lights', 'SLASH', 'PRESS', False, False, False, {'frame_selected': True}),
    ('3D View', 'VIEW_3D', 'WINDOW', 'view3d.localview_lights', 'NUMPAD_SLASH', 'PRESS', False, False, False, {'frame_selected': True}),
    ('Object Mode', 'EMPTY', 'WINDOW', 'object.hide_view_clear_wrapper', 'H', 'PRESS', False, False, True, {'select': True, 'active_layer': False}),
    ('Object Mode', 'EMPTY', 'WINDOW', 'object.hide_view_clear_wrapper', 'H', 'PRESS', False, True, True, {'select': False, 'active_layer': True}),
    ('Object Mode', 'EMPTY', 'WINDOW', 'object.hide_wrapper', 'H', 'PRESS', True, True, False, {'unselected': True, 'unselected_in_layer': True, 'follow_parent': False}),
    ('Object Mode', 'EMPTY', 'WINDOW', 'object.hide_wrapper', 'H', 'PRESS', True, False, False, {'unselected': True, 'unselected_in_layer': False, 'follow_parent': False}),
    ('Object Mode', 'EMPTY', 'WINDOW', 'object.hide_wrapper', 'H', 'PRESS', False, False, False, {'unselected': False, 'unselected_in_layer': False, 'follow_parent': True}),
    ('3D View', 'VIEW_3D', 'WINDOW', 'view3d.z_display_toggle_shading', 'Z', 'PRESS', False, False, False, {}),
)

LEGACY_CUSTOM_KEYMAP_DEFS = (
    ('Object Mode', 'EMPTY', 'WINDOW', 'view3d.localview_lights', 'SLASH', 'PRESS', False, False, False, {'frame_selected': True}),
    ('Object Mode', 'EMPTY', 'WINDOW', 'view3d.localview_lights', 'NUMPAD_SLASH', 'PRESS', False, False, False, {'frame_selected': True}),
)


SHARED_KEYMAP_DEFS = (
    ('Curve', 'EMPTY', 'WINDOW', 'curve.z_display_handle_type_modal', 'V', 'PRESS', False, False, False, {}),
)

ADDON_OPERATOR_IDS = {definition[3] for definition in CUSTOM_KEYMAP_DEFS + SHARED_KEYMAP_DEFS}


def get_addon_preferences():
    addon = bpy.context.preferences.addons.get(__name__)
    return addon.preferences if addon else None


def _store_disabled_keymap_item(store, kmi):
    ptr = kmi.as_pointer()
    if any(entry[0] == ptr for entry in store):
        return
    store.append((ptr, kmi, bool(kmi.active)))


def _disable_keymap_items_by_event(specs, store):
    wm = bpy.context.window_manager
    kc = getattr(wm.keyconfigs, "active", None)
    if kc is None:
        return

    for km_name, space_type, region_type, key_type, value, shift, ctrl, alt in specs:
        km = kc.keymaps.get(km_name)
        if km is None:
            continue
        if km.space_type != space_type or km.region_type != region_type:
            continue
        for kmi in km.keymap_items:
            if getattr(kmi, "idname", "") in ADDON_OPERATOR_IDS:
                continue
            if (
                kmi.type == key_type and
                kmi.value == value and
                bool(kmi.shift) == shift and
                bool(kmi.ctrl) == ctrl and
                bool(kmi.alt) == alt
            ):
                _store_disabled_keymap_item(store, kmi)
                kmi.active = False


def _restore_keymap_items(store):
    while store:
        _ptr, kmi, was_active = store.pop()
        try:
            kmi.active = was_active
        except ReferenceError:
            pass
        except Exception:
            pass




def _clear_preexisting_addon_keymap_items(definitions):
    wm = bpy.context.window_manager
    kc = getattr(wm.keyconfigs, "addon", None)
    if kc is None:
        return

    for km_name, space_type, region_type, operator_id, key_type, value, shift, ctrl, alt, _properties in definitions:
        km = kc.keymaps.get(km_name)
        if km is None or km.space_type != space_type or km.region_type != region_type:
            continue
        for kmi in list(km.keymap_items):
            if (
                kmi.idname == operator_id and
                kmi.type == key_type and
                kmi.value == value and
                bool(kmi.shift) == shift and
                bool(kmi.ctrl) == ctrl and
                bool(kmi.alt) == alt
            ):
                try:
                    km.keymap_items.remove(kmi)
                except Exception:
                    pass


def _register_keymap_definitions(definitions, store):
    wm = bpy.context.window_manager
    kc = getattr(wm.keyconfigs, "addon", None)
    if kc is None:
        return

    keymap_cache = {}
    for km_name, space_type, region_type, operator_id, key_type, value, shift, ctrl, alt, properties in definitions:
        key = (km_name, space_type, region_type)
        km = keymap_cache.get(key)
        if km is None:
            km = kc.keymaps.new(name=km_name, space_type=space_type, region_type=region_type)
            keymap_cache[key] = km

        kmi = km.keymap_items.new(operator_id, key_type, value, shift=shift, ctrl=ctrl, alt=alt)
        for prop_name, prop_value in properties.items():
            setattr(kmi.properties, prop_name, prop_value)
        store.append((km, kmi))

def _clear_addon_keymaps(store):
    wm = bpy.context.window_manager
    kc = getattr(wm.keyconfigs, "addon", None)
    if kc is None:
        store.clear()
        return

    while store:
        km, kmi = store.pop()
        try:
            km.keymap_items.remove(kmi)
        except ReferenceError:
            pass
        except Exception:
            pass


def disable_shared_default_keymaps():
    specs = [
        ("Curve", 'EMPTY', 'WINDOW', 'V', 'PRESS', False, False, False),
    ]
    _disable_keymap_items_by_event(specs, disabled_default_keymap_items_shared)


def restore_shared_default_keymaps():
    _restore_keymap_items(disabled_default_keymap_items_shared)


def disable_conflicting_default_keymaps():
    specs = [
        ("3D View", 'VIEW_3D', 'WINDOW', 'Z', 'PRESS', False, False, False),
        ("3D View", 'VIEW_3D', 'WINDOW', 'SLASH', 'PRESS', False, False, False),
        ("3D View", 'VIEW_3D', 'WINDOW', 'NUMPAD_SLASH', 'PRESS', False, False, False),
        ("Object Mode", 'EMPTY', 'WINDOW', 'H', 'PRESS', False, False, False),
        ("Object Mode", 'EMPTY', 'WINDOW', 'H', 'PRESS', True, False, False),
        ("Object Mode", 'EMPTY', 'WINDOW', 'H', 'PRESS', True, True, False),
        ("Object Mode", 'EMPTY', 'WINDOW', 'H', 'PRESS', False, False, True),
    ]
    _disable_keymap_items_by_event(specs, disabled_default_keymap_items_custom)


def restore_conflicting_default_keymaps():
    _restore_keymap_items(disabled_default_keymap_items_custom)


def register_shared_keymaps():
    if addon_keymaps_shared:
        return

    _clear_preexisting_addon_keymap_items(SHARED_KEYMAP_DEFS)
    _register_keymap_definitions(SHARED_KEYMAP_DEFS, addon_keymaps_shared)


def unregister_shared_keymaps():
    _clear_addon_keymaps(addon_keymaps_shared)


def register_custom_keymaps():
    if addon_keymaps_custom:
        return

    _clear_preexisting_addon_keymap_items(LEGACY_CUSTOM_KEYMAP_DEFS + CUSTOM_KEYMAP_DEFS)
    _register_keymap_definitions(CUSTOM_KEYMAP_DEFS, addon_keymaps_custom)


def unregister_custom_keymaps():
    _clear_addon_keymaps(addon_keymaps_custom)


def sync_custom_keymap_state():
    prefs = get_addon_preferences()
    use_custom = bool(prefs.use_custom_keymap) if prefs is not None else True

    if use_custom:
        disable_conflicting_default_keymaps()
        register_custom_keymaps()
    else:
        unregister_custom_keymaps()
        restore_conflicting_default_keymaps()


def z_display_keymap_update(self, context):
    sync_custom_keymap_state()


class ZDisplayPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    use_custom_keymap: bpy.props.BoolProperty(
        name="Enable custom shortcuts",
        description="Enable Z-Display custom shortcut set and restore the default shortcuts when disabled",
        default=True,
        update=z_display_keymap_update,
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "use_custom_keymap")


class VIEW3D_OT_z_display_toggle_shading(bpy.types.Operator):
    bl_idname = "view3d.z_display_toggle_shading"
    bl_label = "Toggle Solid/Rendered"

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D'

    def execute(self, context):
        space = context.space_data
        if space is None or space.type != 'VIEW_3D':
            return {'CANCELLED'}

        shading = space.shading
        shading.type = 'SOLID' if shading.type == 'RENDERED' else 'RENDERED'
        return {'FINISHED'}


class CURVE_OT_z_display_handle_type_modal(bpy.types.Operator):
    bl_idname = "curve.z_display_handle_type_modal"
    bl_label = "Set Handle Type"

    _choices = {
        'A': 'AUTOMATIC',
        'V': 'VECTOR',
        'L': 'ALIGNED',
    }

    @classmethod
    def poll(cls, context):
        return context.mode == 'EDIT_CURVE'

    def invoke(self, context, event):
        if context.area:
            context.area.header_text_set("Handle Type: A = Automatic, V = Vector, L = Aligned, Esc = Cancel")
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.value != 'PRESS':
            return {'RUNNING_MODAL'}

        if event.type == 'ESC':
            if context.area:
                context.area.header_text_set(None)
            return {'CANCELLED'}

        handle_type = self._choices.get(event.type)
        if handle_type is None:
            return {'RUNNING_MODAL'}

        if context.area:
            context.area.header_text_set(None)

        try:
            bpy.ops.curve.handle_type_set(type=handle_type)
        except TypeError:
            if handle_type == 'AUTOMATIC':
                bpy.ops.curve.handle_type_set(type='AUTO')
            else:
                raise
        return {'FINISHED'}


def _deferred_keymap_sync():
    try:
        register_shared_keymaps()
        disable_shared_default_keymaps()
        sync_custom_keymap_state()
    except Exception:
        pass
    return None


from bpy.app.handlers import persistent
import mathutils
import math


def _parent_space_is_inverted(obj):
    parent = obj.parent
    while parent:
        try:
            if parent.matrix_world.to_3x3().determinant() < 0.0:
                return True
        except Exception:
            return False
        parent = parent.parent
    return False


def _set_label_view_rotation(obj, viewport_orientation):
    # Safe rotation path: do not assign matrix_world from the refresh timer.
    # Writing matrix_world continuously can fight Blender undo/delete/collection ops,
    # especially on parented or mirrored labels.
    if obj.rotation_mode != 'QUATERNION':
        obj.rotation_mode = 'QUATERNION'

    if obj.rotation_quaternion != viewport_orientation:
        obj.rotation_quaternion = viewport_orientation


_z_display_refresh_enabled = False
_z_display_refresh_registered = False
_z_display_refresh_paused = False


def _z_display_pause_refresh(*args):
    global _z_display_refresh_paused
    _z_display_refresh_paused = True


def _z_display_resume_refresh(*args):
    global _z_display_refresh_paused
    _z_display_refresh_paused = False


def _add_handler_once(handler_list, handler):
    if handler not in handler_list:
        handler_list.append(handler)


def _remove_handler_if_present(handler_list, handler):
    if handler in handler_list:
        handler_list.remove(handler)



def _z_display_refresh():
    global _z_display_refresh_registered

    if not _z_display_refresh_enabled:
        _z_display_refresh_registered = False
        return None

    if _z_display_refresh_paused:
        return 0.05

    screen = getattr(bpy.context, "screen", None)
    if not screen:
        return 0.0165

    for area in screen.areas:
        if area.type != 'VIEW_3D':
            continue

        space = area.spaces.active
        region_3d = getattr(space, "region_3d", None)
        if region_3d is None:
            continue

        viewport_orientation = region_3d.view_rotation

        for obj in bpy.context.visible_objects:
            is_label = ".t" in obj.name or ".s" in obj.name or obj.name.endswith('...')

            if is_label and not obj.select_get():
                _set_label_view_rotation(obj, viewport_orientation)

            if 'always_show' in obj.name and obj.hide_get():
                obj.hide_set(False)

    return 0.0165

@persistent
def z_anatomy_load_post(scene=None):
    global _z_display_refresh_enabled, _z_display_refresh_registered

    _z_display_refresh_enabled = True
    if not _z_display_refresh_registered:
        _z_display_refresh_registered = True
        bpy.app.timers.register(_z_display_refresh, first_interval=0.01)

    bpy.msgbus.subscribe_rna(
        key=subscribe_to,
        owner=owner,
        args=(),
        notify=msgbus_callback,
    )

    bpy.msgbus.subscribe_rna(
        key=(bpy.types.Window, "workspace"),
        owner=owner,
        args=(),
        notify=msgbus_callback_workspace,
    )


def msgbus_callback_workspace(*args):
    workspace = bpy.context.workspace
    if workspace.name == "Biomechanics":
        bpy.context.window.view_layer = bpy.data.scenes['Scene'].view_layers["Biomechanics"]
        bpy.context.view_layer.objects.active = bpy.data.objects['Armature']
        bpy.ops.object.mode_set(mode='POSE')
    elif workspace.name == "Anatomy":
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.context.window.view_layer = bpy.data.scenes['Scene'].view_layers["Anatomy"]


def msgbus_callback(*args):
    active_object = bpy.context.active_object
    if not active_object or not active_object.data:
        return

    basename, _ = clean_name(active_object.data.name)
    text_editor_area = None
    for area in bpy.context.screen.areas:
        if area.type == "TEXT_EDITOR":
            text_editor_area = area
            break

    if text_editor_area and basename in bpy.data.texts:
        text_editor_area.spaces[0].text = bpy.data.texts[basename]
        text_editor_area.spaces[0].top = 0
        text_editor_area.spaces[0].text.select_set(0, 0, 0, 0)

    if any(x in active_object.name for x in label_elements) or ".st" in active_object.name:
        return

    if not bpy.context.scene.z_display_only_active_labels:
        return

    select_family = family(active_object)

    for child in select_family:
        child.hide_set(False)

    for ob in (c for c in bpy.context.visible_objects if c.name.endswith('.g') or (c.name.endswith('-line') and c.parent and c.parent.name.endswith('.g'))):
        ob.hide_set(True)

    for ob in (o for o in set(bpy.context.visible_objects) - set(active_object.users_collection[0].all_objects) if o.name.endswith('.g')):
        ob.hide_set(True)

        for child in (c for c in bpy.context.visible_objects if c.parent == ob and c.name.endswith('-line')):
            child.hide_set(True)

    for ob in (o for o in active_object.users_collection[0].all_objects if not o.visible_get() and o.name.endswith('.g')):
        ob.hide_set(False)

        for child in (c for c in bpy.context.scene.objects if c.parent == ob and not c.visible_get() and c.name.endswith('-line')):
            child.hide_set(False)

    for ob in (o for o in bpy.context.visible_objects if any(x in o.name for x in label_elements)):
        if not ob.parent == active_object and not ob in select_family:
            ob.hide_set(True)
            for child in ob.children:
                child.hide_set(True)
            if ".s" in ob.name and ob.parent:
                if ".i" in ob.parent.name or ".j" in ob.parent.name:
                    ob.parent.hide_set(True)

    for ob in (o for o in bpy.context.visible_objects if o.name.endswith('...')):
        if ob == active_object:
            for child in ob.children:
                child.hide_set(False)
        else:
            for child in ob.children:
                child.hide_set(True)

    if active_object.name.endswith('.g'):
        bpy.ops.object.select_grouped('INVOKE_DEFAULT', type='CHILDREN_RECURSIVE')
        active_object.select_set(True)


subscribe_to = bpy.types.LayerObjects, "active"
owner = object()

classes = (
    OBJECT_OT_hide_wrapper,
    OBJECT_OT_hide_view_clear_wrapper,
    OBJECT_OT_local_view_wrapper,
    VIEW3D_OT_z_display_toggle_shading,
    CURVE_OT_z_display_handle_type_modal,
    ZDisplayPreferences,
    ZANATOMY_PT_display_panel,
)

font_info = {
    "handler": None,
}


def clean_name(name):
    for ending in ('.r', '.l', '.t', '.st', '.r.t', '.l.t', '.r-line', '.l-line', '.g', '-line', '.o', '.e', ''):
        if ending == '':
            return name, ending
        elif name.endswith(ending):
            clean_name = name[:-len(ending)]
            return clean_name, ending


import blf


def draw_callback_px(self, context):
    context = bpy.context
    if not hasattr(context, 'area') or not context.object:
        return

    font_size = 24
    blf.color(0, 255, 255, 255, 255)
    blf.size(0, font_size)
    blf.position(0, 55, context.area.height - 70 - font_size, 0)
    blf.draw(0, f'{clean_name(context.object.name)[0]}')


def register():
    for c in classes:
        bpy.utils.register_class(c)

    bpy.types.Scene.z_display_only_active_labels = bpy.props.BoolProperty(
        default=True,
        name="Only labels of active object",
        description="Show only labels related to the active object"
    )

    z_anatomy_load_post()
    if z_anatomy_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(z_anatomy_load_post)

    if hasattr(bpy.app.handlers, "undo_pre"):
        _add_handler_once(bpy.app.handlers.undo_pre, _z_display_pause_refresh)
    if hasattr(bpy.app.handlers, "redo_pre"):
        _add_handler_once(bpy.app.handlers.redo_pre, _z_display_pause_refresh)
    if hasattr(bpy.app.handlers, "undo_post"):
        _add_handler_once(bpy.app.handlers.undo_post, _z_display_resume_refresh)
    if hasattr(bpy.app.handlers, "redo_post"):
        _add_handler_once(bpy.app.handlers.redo_post, _z_display_resume_refresh)

    font_info["handler"] = bpy.types.SpaceView3D.draw_handler_add(
        draw_callback_px, (None, None), 'WINDOW', 'POST_PIXEL')

    bpy.app.timers.register(_deferred_keymap_sync, first_interval=0.05)


def unregister():
    global _z_display_refresh_enabled, _z_display_refresh_paused
    _z_display_refresh_enabled = False
    _z_display_refresh_paused = False

    unregister_custom_keymaps()
    restore_conflicting_default_keymaps()
    unregister_shared_keymaps()
    restore_shared_default_keymaps()

    if font_info.get("handler") is not None:
        bpy.types.SpaceView3D.draw_handler_remove(font_info["handler"], 'WINDOW')
        font_info["handler"] = None

    bpy.msgbus.clear_by_owner(owner)

    if z_anatomy_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(z_anatomy_load_post)

    if hasattr(bpy.app.handlers, "undo_pre"):
        _remove_handler_if_present(bpy.app.handlers.undo_pre, _z_display_pause_refresh)
    if hasattr(bpy.app.handlers, "redo_pre"):
        _remove_handler_if_present(bpy.app.handlers.redo_pre, _z_display_pause_refresh)
    if hasattr(bpy.app.handlers, "undo_post"):
        _remove_handler_if_present(bpy.app.handlers.undo_post, _z_display_resume_refresh)
    if hasattr(bpy.app.handlers, "redo_post"):
        _remove_handler_if_present(bpy.app.handlers.redo_post, _z_display_resume_refresh)

    if hasattr(bpy.types.Scene, "z_display_only_active_labels"):
        del bpy.types.Scene.z_display_only_active_labels

    for c in reversed(classes):
        bpy.utils.unregister_class(c)


if __name__ == "__main__":
    register()
