# Z-Display Add-on for Blender

## Description
**Z-Display** est un add-on Blender conçu pour optimiser la gestion de la visibilité des objets et des collections dans des scènes 3D complexes. Il permet d'isoler, masquer ou afficher des objets de manière intelligente, en tenant compte de leur hiérarchie et de leur appartenance à des couches spécifiques. Idéal pour les projets comme **Z-Anatomy**, il facilite la navigation et l'édition dans des environnements denses.

## Features
- **Isolation des objets** : Masquez tous les objets non sélectionnés dans la scène ou la couche active, en respectant la hiérarchie parent-enfant.
- **Affichage sélectif** : Rendez visibles uniquement les objets d'une couche spécifique, tout en masquant les labels ou éléments non pertinents (ex. : objets avec les suffixes `.t`, `.s`, `.j`, `.i`).
- **Vue locale avec lumières** : Activez une vue locale incluant automatiquement les lumières, pour un travail ciblé sans perdre le contexte d'éclairage.
- **Synchronisation automatique** : Les labels (ex. : `.t`) s'orientent automatiquement selon la vue 3D, et les objets marqués `always_show` restent toujours visibles.
- **Intégration avec Z-Anatomy** : Compatible avec les workflows de **Z-Anatomy**, notamment pour la gestion des modèles anatomiques et des hiérarchies complexes.

## Installation
1. Téléchargez le fichier `.zip` de l'add-on.
2. Dans Blender, allez dans `Edit` > `Preferences`.
3. Sélectionnez l'onglet `Add-ons` et cliquez sur l'icône de flèche vers le bas en haut à droite.
4. Choisissez `Install from Disk` et sélectionnez le fichier `.zip` téléchargé.
5. Activez l'add-on en cochant la case **"Z-Display"**.

## Usage
### Panneau Z-Display
1. Ouvrez le panneau **Z-Display** dans la barre latérale **N** de la vue 3D (catégorie **Z-Anatomy**).
2. Utilisez les boutons suivants :
   - **"Isolate on Layer"** : Masque tous les objets non sélectionnés dans la couche active ou la scène, selon les options choisies.
   - **"Unhide Layer"** : Affiche tous les objets masqués de la couche active ou de la scène.
   - **"Local View with Lights"** : Active une vue locale incluant les lumières, avec option pour encadrer les objets sélectionnés.

### Options avancées
- **Follow parent's visibility** : Masque ou affiche les objets en suivant la visibilité de leur parent.
- **Affect only active layer** : Limite les actions de masquage/affichage à la couche active.
- **Frame Selected** : Encadre les objets sélectionnés lors de l'activation de la vue locale.

## Compatibility
- Blender 2.80 et versions ultérieures (testé jusqu'à Blender 4.5).

## Author
- **Marcin Zieliński** (développeur principal)
- **Z-Anatomy** (intégration et adaptation)

## License
Cet add-on est distribué sous la licence [CC-BY-SA 4.0](LICENSE), permettant le partage et l'adaptation sous réserve d'attribution et de partage à l'identique.
