# Propriété pour stocker la liste de noms (multi-lignes)
bpy.types.Scene.navid_collection_list = bpy.props.StringProperty(
    name="Collection Names",
    description="Paste the list of collection names here (one per line).",
    subtype='TEXT',  # Active le mode multi-lignes
    default="",
)

# Panneau d'interface
class ZANATOMY_PT_bonus_panel(bpy.types.Panel):
    bl_label = "Create collections"
    bl_idname = "VIEW3D_PT_z_bonus_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Z-Anatomy"
    bl_order = 10

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # Zone de texte pour coller la liste (multi-lignes)
        layout.label(text="Paste collection names (one per line):")
        row = layout.row()
        row.scale_y = 3.0  # Ajuste la hauteur de la zone de texte
        row.prop(scene, "navid_collection_list", text="", icon='OUTLINER')

        # Bouton pour créer les collections
        layout.operator("object.create_navid_collections", text="Create Collections")
