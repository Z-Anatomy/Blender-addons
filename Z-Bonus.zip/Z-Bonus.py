# This program is free software: you can redistribute it and/or modify
# it under the terms of the Creative Commons Attribution-ShareAlike 4.0 International License (CC-BY-SA 4.0).
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# For more information, visit the official license page: https://creativecommons.org/licenses/by-sa/4.0/

bl_info = {
    "name": "Z-BONUS",
    "author": "Gauthier Kervyn",
    "description": "Create collections with a custom 'NAVID' property. Enter a comma-separated list of names to generate collections automatically.",
    "blender": (4, 5, 0),
    "version": (1, 0, 0),
    "location": "View3D > Sidebar > Z-Anatomy",
    "warning": "",
    "category": "Interface",
}

import bpy

# Fonction pour créer une collection avec une custom property 'NAVID'
def create_collection_with_navid(name):
    if name in bpy.data.collections:
        print(f"Collection '{name}' already exists.")
        return False
    new_collection = bpy.data.collections.new(name)
    bpy.context.scene.collection.children.link(new_collection)
    new_collection["NAVID"] = name
    print(f"Collection '{name}' created with NAVID = '{name}'.")
    return True

# Opérateur pour créer les collections
class OBJECT_OT_create_navid_collections(bpy.types.Operator):
    bl_idname = "object.create_navid_collections"
    bl_label = "Create Collections"
    bl_description = "Create collections from the comma-separated list, with 'NAVID' custom property."
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        text = scene.get("navid_collection_list", "")
        # Découpe la chaîne par des virgules
        names = [name.strip() for name in text.split(",") if name.strip()]

        if not names:
            self.report({'ERROR'}, "No valid collection names found.")
            return {'CANCELLED'}

        created = 0
        for name in names:
            if create_collection_with_navid(name):
                created += 1

        self.report({'INFO'}, f"{created} collections created.")
        return {'FINISHED'}

# Panneau d'interface
class ZANATOMY_PT_bonus_panel(bpy.types.Panel):
    bl_label = "Create collections"
    bl_idname = "VIEW3D_PT_z_bonus_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Z-Anatomy"
    bl_order = 10

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # Zone de texte pour entrer la liste (séparée par des virgules)
        layout.label(text="Enter collection names (comma-separated):")
        layout.prop(scene, "navid_collection_list", text="", icon='OUTLINER')

        # Bouton pour créer les collections
        layout.operator("object.create_navid_collections", text="Create Collections")

# Enregistrement des classes
classes = (
    OBJECT_OT_create_navid_collections,
    ZANATOMY_PT_bonus_panel,
)

def register():
    # Désenregistre la propriété si elle existe déjà
    if hasattr(bpy.types.Scene, "navid_collection_list"):
        del bpy.types.Scene.navid_collection_list

    # Enregistre les classes
    for cls in classes:
        bpy.utils.register_class(cls)

    # Ajoute la propriété à la scène
    bpy.types.Scene.navid_collection_list = bpy.props.StringProperty(
        name="Collection Names",
        description="Enter the list of collection names here (comma-separated).",
        default="",
    )

def unregister():
    # Supprime la propriété
    if hasattr(bpy.types.Scene, "navid_collection_list"):
        del bpy.types.Scene.navid_collection_list

    # Désenregistre les classes
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
