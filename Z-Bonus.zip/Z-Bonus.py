# This program is free software: you can redistribute it and/or modify
# it under the terms of the Creative Commons Attribution-ShareAlike 4.0 International License (CC-BY-SA 4.0).
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# For more information, visit the official license page: https://creativecommons.org/licenses/by-sa/4.0/

bl_info = {
    "name": "Z-BONUS",
    "author": "Gauthier Kervyn",
    "description": "Create collections with a custom 'NAVID' property. Paste a list of names (one per line) to generate collections automatically.",
    "blender": (4, 5, 0),
    "version": (1, 0, 0),
    "location": "View3D > Sidebar > Z-Anatomy",
    "warning": "",
    "category": "Interface",
}

import bpy

# Fonction pour créer une collection avec une custom property 'NAVID'
def create_collection_with_navid(name):
    if name in bpy.data.collections:
        print(f"Collection '{name}' already exists.")
        return False
    new_collection = bpy.data.collections.new(name)
    bpy.context.scene.collection.children.link(new_collection)
    new_collection["NAVID"] = name
    print(f"Collection '{name}' created with NAVID = '{name}'.")
    return True

# Opérateur pour créer les collections
class OBJECT_OT_create_navid_collections(bpy.types.Operator):
    bl_idname = "object.create_navid_collections"
    bl_label = "Create Collections"
    bl_description = "Create collections from the pasted list, with 'NAVID' custom property."
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        text = scene.navid_collection_list
        names = [name.strip() for name in text.split("\n") if name.strip()]

        if not names:
            self.report({'ERROR'}, "No valid collection names found.")
            return {'CANCELLED'}

        created = 0
        for name in names:
            if create_collection_with_navid(name):
                created += 1

        self.report({'INFO'}, f"{created} collections created.")
        return {'FINISHED'}

# Panneau d'interface
class ZANATOMY_PT_bonus_panel(bpy.types.Panel):
    bl_label = "Create collections"
    bl_idname = "VIEW3D_PT_z_bonus_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Z-Anatomy"
    bl_order = 10  # Position dans la catégorie Z-Anatomy

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # Zone de texte pour coller la liste
        layout.label(text="Paste collection names (one per line):")
        layout.prop(scene, "navid_collection_list", text="")

        # Bouton pour créer les collections
        layout.operator("object.create_navid_collections", text="Create Collections")

# Propriété pour stocker la liste de noms
bpy.types.Scene.navid_collection_list = bpy.props.StringProperty(
    name="Collection Names",
    description="Paste the list of collection names here (one per line).",
)

# Enregistrement des classes
classes = (
    OBJECT_OT_create_navid_collections,
    ZANATOMY_PT_bonus_panel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.navid_collection_list

if __name__ == "__main__":
    register()
