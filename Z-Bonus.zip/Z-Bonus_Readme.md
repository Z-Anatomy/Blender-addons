# Z-BONUS Add-on for Blender

## Description
Z-BONUS is a Blender add-on designed to quickly create collections with a custom 'NAVID' property. It allows users to paste a list of collection names (one per line) and automatically generates the collections, each with a 'NAVID' property matching its name.

## Features
- **Create collections in bulk**: Paste a list of names (one per line) to generate collections automatically.
- **Custom property 'NAVID'**: Each collection is created with a 'NAVID' property, matching its name.
- **Simple and intuitive interface**: Integrated into the **Z-Anatomy** panel for easy access.

## Installation
1. Download the `.zip` file of the add-on.
2. Open Blender and go to `Edit` > `Preferences`.
3. Select the `Add-ons` tab and click the downward-facing arrow in the top-right corner.
4. Choose `Install from Disk` and select the downloaded `.zip` file.
5. Enable the add-on by checking the box next to **"Z-BONUS"**.

## Usage
### Creating Collections
1. Open the **Z-Anatomy** panel in the **N** sidebar of the 3D Viewport.
2. Navigate to the **"Create collections"** tab.
3. Paste your list of collection names (one per line) into the provided text box.
4. Click the **"Create Collections"** button to generate the collections.

## Author
- **Gauthier Kervyn**
- **Z-Anatomy**

## Compatibility
- Blender 4.5 and later versions.

## License
This add-on is distributed under the [CC-BY-SA 4.0](LICENSE) license, which allows sharing and adaptation with attribution and under the same terms.
