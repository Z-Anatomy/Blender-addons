# Z-Label for Blender

## Description

Z-Label is a Blender add-on designed for anatomical labeling workflows. It allows you to automatically create, position, and manage text labels attached to vertices on mesh objects, with fine control over hierarchies and child objects.

## Features

- Convert selected meshes into text labels with connecting line objects (`.j` suffix).
- Position labels above specific vertices with automatic hook modifier creation.
- Only the direct child `.j` line follows the label's movement; all other children and descendants remain fixed.
- Toggle the selectability of all `.j` line objects via a checkbox in the UI.
- Convert label locations into delta transforms for animation purposes.
- Easy management through an integrated panel in the "Z-Anatomy" tab.

## Installation

1. Download the `.zip` or `.py` file of the add-on.
2. In Blender, go to `Edit > Preferences > Add-ons`.
3. Click `Install...` and select the downloaded file.
4. Enable the add-on in the list.

## Usage

### Convert meshes into labels

- Select the mesh objects and click **Convert Selected to Labels**.

### Position labels above vertices with hook

- In Edit Mode, select a vertex, then select the label text object.
- Click **Position label + hook automatically**.
- The label will be placed above the vertex with a hook on the `.j` line.

### Convert locations into deltas

- Select labels (`.t` objects).
- Click **Convert location to delta** to store current positions as `delta_location` and reset location to zero for animation.

### Toggle lines selectability

- Use the checkbox **Lines Selectable** in the panel to enable or disable selection for all `.j` objects.

## Author

- Gauthier KERVYN

## Compatibility

- Blender 2.80 and later versions.

## License

This add-on is distributed under the [CC-BY-SA 4.0](LICENSE) license.