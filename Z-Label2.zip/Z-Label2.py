import bpy
import bmesh
from mathutils import Vector

bl_info = {
    "name": "Z-Label",
    "blender": (2, 80, 0),
    "category": "Object",
    "description": "Convert selected meshes to labels, managing hierarchy and children.",
    "author": "Gauthier KERVYN",
    "version": (1, 8),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > Z-Anatomy",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
}

def clean_name(name):
    for ending in ('.r', '.l', '.t', '.j', '.o', '.e', ''):
        if ending == '':
            return name, ending
        elif name.endswith(ending):
            clean_name = name[:-len(ending)]
            return clean_name, ending

def set_local_from_global(obj, target_world_mat, parent_world_mat):
    obj.matrix_parent_inverse.identity()
    obj.matrix_local = parent_world_mat.inverted() @ target_world_mat

class OBJECT_OT_make_label_from_mesh(bpy.types.Operator):
    bl_idname = "object.make_label_from_mesh"
    bl_label = "Convert Selected to Labels"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and len(context.selected_objects) > 0

    def execute(self, context):
        selected_objects = context.selected_objects[:]
        bpy.ops.object.select_all(action='DESELECT')

        for mesh_object in selected_objects:
            if mesh_object.type != 'MESH':
                continue

            parent = mesh_object.parent
            children = mesh_object.children[:]
            collections = mesh_object.users_collection[:]
            mesh_object.select_set(True)
            context.view_layer.objects.active = mesh_object

            base_name, _ = clean_name(mesh_object.name)

            text_location = mesh_object.location + Vector((0, 0, 0.05))
            line_end_location = text_location - Vector((0, 0, 0.05))

            if mesh_object.data and mesh_object.data.vertices:
                try:
                    highest_point = max((mesh_object.matrix_world @ v.co).z for v in mesh_object.data.vertices)
                    text_location = mesh_object.matrix_world @ Vector((0, 0, highest_point)) + Vector((0, 0, 0.05))
                    line_end_location = mesh_object.matrix_world @ Vector((0, 0, highest_point))
                except:
                    pass

            bpy.ops.object.text_add(
                radius=0.003,
                enter_editmode=False,
                align='WORLD',
                location=text_location,
                rotation=(1.5708, 0, 0),
                scale=(1, 1, 1)
            )
            font_object = context.object
            font_object.name = f"{base_name}.t"
            font_object.data.name = mesh_object.data.name
            font_object.data.body = base_name.upper()
            font_object.data.align_x = 'CENTER'

            try:
                font_object.data.font = bpy.data.fonts["DejaVuSansCondensed"]
            except:
                self.report(type={"WARNING"}, message=f"Font DejaVuSansCondensed not found for {base_name}. Add it manually.")

            mat = bpy.data.materials.get("Text")
            if mat is None:
                mat = bpy.data.materials.new(name="Text")
            font_object.data.materials.append(mat)

            bpy.context.view_layer.update()
            bbox = [font_object.matrix_world @ Vector(corner) for corner in font_object.bound_box]
            base_z = min([v.z for v in bbox])
            base_xy = sum((Vector((v.x, v.y, 0)) for v in bbox), Vector()) / 8
            base_pos = Vector((base_xy.x, base_xy.y, base_z))
            verts = [base_pos, mesh_object.location]
            edges = [[0, 1]]
            mesh = bpy.data.meshes.new(f"{base_name}.j")
            mesh.from_pydata(verts, edges, [])
            mesh.update()

            line_object = bpy.data.objects.new(f"{base_name}.j", mesh)
            context.collection.objects.link(line_object)

            line_object.parent = font_object
            line_object.matrix_parent_inverse = font_object.matrix_world.inverted()
            line_object.location = Vector((0, 0, 0))

            if parent:
                font_object.parent = parent
                font_object.matrix_parent_inverse = parent.matrix_world.inverted()

            for collection in collections:
                if font_object.name not in collection.objects:
                    collection.objects.link(font_object)
                if line_object.name not in collection.objects:
                    collection.objects.link(line_object)

            for child in children:
                child.parent = font_object
                child.matrix_parent_inverse = font_object.matrix_world.inverted()

            bpy.ops.object.select_all(action='DESELECT')
            mesh_object.select_set(True)
            context.view_layer.objects.active = mesh_object
            bpy.data.objects.remove(mesh_object, do_unlink=True)
            bpy.ops.object.select_all(action='DESELECT')

        return {"FINISHED"}

class OBJECT_OT_place_label_above_vertex(bpy.types.Operator):
    bl_idname = "object.place_label_above_vertex"
    bl_label = "Position label + hook automatically"
    bl_options = {'REGISTER', 'UNDO'}

    offset: bpy.props.FloatProperty(
        name="Z Offset (mm)",
        description="Distance above the selected vertex",
        default=50.0,
        min=0.0,
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and context.mode == 'EDIT_MESH' and len(context.selected_objects) >= 2

    def execute(self, context):
        selected = [obj for obj in context.selected_objects if obj != context.active_object]
        if not selected or selected[0].type != 'FONT':
            self.report({'ERROR'}, "Select the label text first, then the active mesh.")
            return {'CANCELLED'}
        label_obj = selected[0]
        mesh_obj = context.active_object

        bm = bmesh.from_edit_mesh(mesh_obj.data)
        verts = [v for v in bm.verts if v.select]
        if len(verts) != 1:
            self.report({'ERROR'}, "Select exactly one vertex in Edit Mode.")
            return {'CANCELLED'}
        v_co = mesh_obj.matrix_world @ verts[0].co
        new_label_pos = v_co + Vector((0, 0, self.offset / 1000.0))
        delta = new_label_pos - label_obj.matrix_world.to_translation()

        child_worlds = {child: child.matrix_world.copy() for child in label_obj.children}

        label_obj.location += delta

        for child in label_obj.children:
            if child.name.endswith('.j'):
                child.location = Vector((0, 0, 0))
            else:
                set_local_from_global(child, child_worlds[child], label_obj.matrix_world)

        bpy.ops.object.mode_set(mode='OBJECT')

        label_obj.select_set(False)

        bpy.ops.object.select_all(action='DESELECT')
        mesh_obj.select_set(True)
        bpy.context.view_layer.objects.active = mesh_obj

        line_obj = None
        for child in label_obj.children:
            if child.name.endswith('.j'):
                line_obj = child
                break

        if line_obj is None:
            self.report({'WARNING'}, "No '.j' line child found to add hook.")
            return {'FINISHED'}

        line_obj.select_set(True)
        bpy.context.view_layer.objects.active = line_obj

        bpy.ops.object.mode_set(mode='EDIT')

        bpy.ops.mesh.select_all(action='DESELECT')
        last_vert_index = len(line_obj.data.vertices) - 1
        line_obj.data.vertices[last_vert_index].select = True

        bpy.ops.object.mode_set(mode='OBJECT')
        mod_hook = line_obj.modifiers.new(name="Hook", type='HOOK')
        mod_hook.object = mesh_obj
        mod_hook.vertex_indices_set([last_vert_index])

        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')

        label_obj.select_set(True)
        bpy.context.view_layer.objects.active = label_obj

        self.report({'INFO'}, "Label positioned, hook added, selections and modes updated.")
        return {'FINISHED'}

class OBJECT_OT_convert_location_to_delta(bpy.types.Operator):
    bl_idname = "object.convert_location_to_delta"
    bl_label = "Convert location to delta"
    bl_description = "For all selected labels, convert location to delta_location and reset location to zero."
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return any(obj.type == 'FONT' and obj.name.endswith('.t') for obj in context.selected_objects)

    def execute(self, context):
        count = 0
        for obj in context.selected_objects:
            if obj.type == 'FONT' and obj.name.endswith('.t'):
                obj.delta_location = obj.location.copy()
                obj.location = Vector((0, 0, 0))
                count += 1
        self.report({'INFO'}, f"Converted location to delta_location on {count} labels.")
        return {'FINISHED'}

class VIEW3D_PT_z_label_panel(bpy.types.Panel):
    bl_label = "Z-Label"
    bl_idname = "VIEW3D_PT_z_label_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Z-Anatomy'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout

        layout.operator("object.make_label_from_mesh", text="Convert Selected to Labels")
        layout.operator("object.place_label_above_vertex", text="Position label + hook automatically")
        layout.operator("object.convert_location_to_delta", text="Convert location to delta")

        # Checkbox to toggle selectability of all '.j' line objects
        scene = context.scene
        row = layout.row()
        row.prop(scene, "z_label_lines_selectable")

def update_lines_selectability(self, context):
    toggle = context.scene.z_label_lines_selectable
    for obj in bpy.data.objects:
        if obj.name.endswith('.j'):
            obj.hide_select = not toggle

def register():
    bpy.types.Scene.z_label_lines_selectable = bpy.props.BoolProperty(
        name="Lines Selectable",
        description="Toggle selectability of all line (.j) objects",
        default=True,
        update=update_lines_selectability
    )

    classes = [
        OBJECT_OT_make_label_from_mesh,
        OBJECT_OT_place_label_above_vertex,
        OBJECT_OT_convert_location_to_delta,
        VIEW3D_PT_z_label_panel,
    ]

    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    classes = [
        OBJECT_OT_make_label_from_mesh,
        OBJECT_OT_place_label_above_vertex,
        OBJECT_OT_convert_location_to_delta,
        VIEW3D_PT_z_label_panel,
    ]

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.z_label_lines_selectable

if __name__ == "__main__":
    try:
        unregister()
    except:
        pass
    register()
