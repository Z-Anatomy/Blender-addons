bl_info = {
    "name": "Z-Family",
    "author": "Gauthier Kervyn (modifié pour Blender 4.5.0)",
    "description": "Synchronise automatiquement l'éditeur de texte avec l'objet actif et permet la sélection automatique des enfants.",
    "blender": (4, 5, 0),
    "version": (0, 1, 2),
    "location": "View3D > Sidebar > Z-Anatomy",
    "category": "Interface"
}

import bpy
import os

def clean_name(name):
    return os.path.splitext(name)[0]

def get_all_children(obj):
    children = []
    for child in obj.children:
        children.append(child)
        children.extend(get_all_children(child))
    return children

def select_children_callback():
    try:
        if not bpy.context.scene.zanatomy_family.auto_select_children:
            return
        active_object = bpy.context.active_object
        if not active_object:
            return
        all_children = get_all_children(active_object)
        for child in all_children:
            child.select_set(True)
        if all_children:
            print(f"Z-Family: {len(all_children)} enfant(s) sélectionné(s) automatiquement.")
    except Exception as e:
        print(f"Z-Family Error (select_children): {str(e)}")

def msgbus_callback(*args):
    try:
        select_children_callback()
        if not bpy.context.scene.zanatomy_family.sync_text:
            return
        active_object = bpy.context.active_object
        if not active_object or not hasattr(active_object, "data"):
            print("Z-Family: Aucun objet actif ou objet sans data.")
            return
        ta2id_name = active_object.get("TA2ID", active_object.data.name)
        basename = clean_name(ta2id_name)
        if basename not in bpy.data.texts:
            print(f"Z-Family: Texte '{basename}' introuvable.")
            return
        text_editor_area = next((area for area in bpy.context.screen.areas if area.type == "TEXT_EDITOR"), None)
        if not text_editor_area:
            print("Z-Family: Aucun éditeur de texte ouvert.")
            return
        current_text = text_editor_area.spaces[0].text
        if current_text and current_text.name != basename:
            text_editor_area.spaces[0].text = bpy.data.texts[basename]
            text_editor_area.spaces[0].top = 0
            text_editor_area.spaces[0].text.select_set(0, 0, 0, 0)
            text_editor_area.tag_redraw()
            print(f"Z-Family: Synchronisation réussie pour '{basename}'.")
    except Exception as e:
        print(f"Z-Family Error: {str(e)}")

class ZAnatomyFamilyProps(bpy.types.PropertyGroup):
    sync_text: bpy.props.BoolProperty(
        name="Sync Text Editor",
        description="Active la synchronisation automatique de l'éditeur de texte avec l'objet actif",
        default=True,
        update=lambda self, context: msgbus_callback() if self.sync_text else None
    )
    auto_select_children: bpy.props.BoolProperty(
        name="Auto Select Children",
        description="Sélectionne automatiquement tous les enfants de l'objet actif",
        default=False
    )

class SYNCTEXT_PT_sync_text_panel(bpy.types.Panel):
    bl_label = "Show Definition"
    bl_idname = "VIEW3D_PT_sync_text"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Z-Anatomy'
    bl_options = {'DEFAULT_CLOSED'}
    def draw(self, context):
        layout = self.layout
        zanatomy = context.scene.zanatomy_family
        layout.prop(zanatomy, "sync_text")

class AUTOSELECT_PT_panel(bpy.types.Panel):
    bl_label = "Auto Select Children"
    bl_idname = "VIEW3D_PT_auto_select_children"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Z-Anatomy'
    bl_options = {'DEFAULT_CLOSED'}
    def draw(self, context):
        layout = self.layout
        props = context.scene.zanatomy_family
        layout.prop(props, "auto_select_children")

def register():
    for cls in (SYNCTEXT_PT_sync_text_panel, AUTOSELECT_PT_panel, ZAnatomyFamilyProps):
        try:
            bpy.utils.unregister_class(cls)
        except:
            pass
    bpy.utils.register_class(ZAnatomyFamilyProps)
    bpy.utils.register_class(SYNCTEXT_PT_sync_text_panel)
    bpy.utils.register_class(AUTOSELECT_PT_panel)
    bpy.types.Scene.zanatomy_family = bpy.props.PointerProperty(type=ZAnatomyFamilyProps)
    try:
        bpy.msgbus.clear_by_owner(bpy.context.window_manager)
    except:
        pass
    bpy.msgbus.subscribe_rna(
        key=(bpy.types.LayerObjects, "active"),
        owner=bpy.context.window_manager,
        args=(),
        notify=lambda *args: msgbus_callback() if (bpy.context.scene.zanatomy_family.sync_text or bpy.context.scene.zanatomy_family.auto_select_children) else None,
    )
    bpy.msgbus.subscribe_rna(
        key=(bpy.types.Object, "name"),
        owner=bpy.context.window_manager,
        args=(),
        notify=lambda *args: msgbus_callback() if (bpy.context.scene.zanatomy_family.sync_text or bpy.context.scene.zanatomy_family.auto_select_children) else None,
    )
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

def unregister():
    for cls in (ZAnatomyFamilyProps, SYNCTEXT_PT_sync_text_panel, AUTOSELECT_PT_panel):
        try:
            bpy.utils.unregister_class(cls)
        except:
            pass
    if hasattr(bpy.types.Scene, "zanatomy_family"):
        del bpy.types.Scene.zanatomy_family

if __name__ == "__main__":
    register()
