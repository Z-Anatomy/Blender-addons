# Z-Family Add-on for Blender

## Description
**Z-Family** is a Blender add-on designed to streamline the workflow of 3D artists and anatomists working with hierarchical object structures. It automatically synchronizes the text editor with the active object and allows for automatic selection of all child objects, making it easier to manage complex scenes and anatomical models. This tool is especially useful for projects involving detailed 3D anatomy, where objects are often organized in parent-child relationships.

## Features
- **Automatic Text Editor Synchronization**: Automatically opens the text block associated with the active object in Blender's text editor, based on the object's `TA2ID` or data name.
- **Auto-Select Children**: Automatically selects all child objects of the active object, simplifying the management of complex hierarchies.
- **Real-Time Updates**: Synchronizes the text editor and child selection in real-time as you change the active object.
- **Seamless Integration**: Fits naturally into Blender's UI under the **Z-Anatomy** tab for quick and easy access.
- **Customizable**: Toggle synchronization and child selection features on or off as needed.

## Installation
1. Download the `.zip` file of the **Z-Family** add-on.
2. Open Blender and go to `Edit` > `Preferences`.
3. Select the `Add-ons` tab and click the downward-facing arrow in the top-right corner.
4. Choose `Install from Disk` and select the downloaded `.zip` file.
5. Enable the add-on by checking the box next to **"Z-Family"**.

## Usage

### Synchronizing the Text Editor
1. Open the **N** panel in the 3D View and go to the **Z-Anatomy** tab.
2. Locate the **Show Definition** panel.
3. Toggle the **Sync Text Editor** checkbox to enable or disable automatic synchronization of the text editor with the active object.

### Auto-Selecting Child Objects
1. In the **Z-Anatomy** tab, find the **Auto Select Children** panel.
2. Toggle the **Auto Select Children** checkbox to automatically select all child objects of the active object.

### Panel Overview
- **Show Definition**: Controls the synchronization of the text editor with the active object.
- **Auto Select Children**: Controls the automatic selection of child objects.

## Author
- **Gauthier Kervyn**
- **Z-Anatomy**

## Compatibility
- Blender 4.5 and later versions.

## License
This add-on is distributed under the [CC-BY-SA 4.0](LICENSE) license, which allows sharing and adaptation with attribution and under the same terms.