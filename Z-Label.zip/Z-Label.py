import bpy
import bmesh
from mathutils import Vector

bl_info = {
    "name": "Z-Label1",
    "blender": (2, 80, 0),
    "category": "Object",
    "description": "Convert selected meshes or curves to labels, managing hierarchy and children.",
    "author": "Marcin Zielinski, Gauthier Kervyn",
    "version": (2, 6),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > Z-Anatomy",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
}

_last_active_name = None

# --- Opérateur pour créer un label droit ---
class OBJECT_OT_make_label_from_mesh(bpy.types.Operator):
    bl_idname = "object.make_label_from_mesh"
    bl_label = "Create Right Label"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and len(context.selected_objects) > 0

    def execute(self, context):
        try:
            selected_objects = context.selected_objects[:]
            bpy.ops.object.select_all(action='DESELECT')

            for mesh_object in selected_objects:
                if mesh_object.type not in {'MESH', 'CURVE'}:
                    continue

                parent = mesh_object.parent
                children = mesh_object.children[:]
                collections = mesh_object.users_collection[:]
                original_mesh_name = mesh_object.name
                original_mesh_data_name = mesh_object.data.name

                self.reset_transforms(mesh_object)

                mesh_object.select_set(True)
                context.view_layer.objects.active = mesh_object

                text_location = mesh_object.location + Vector((0, 0, 2.0))
                if mesh_object.type == 'MESH' and mesh_object.data.vertices:
                    try:
                        highest_point = max((mesh_object.matrix_world @ v.co).z for v in mesh_object.data.vertices)
                        text_location = Vector((
                            mesh_object.location.x,
                            mesh_object.location.y,
                            highest_point + 2.0
                        ))
                    except:
                        pass
                elif mesh_object.type == 'CURVE' and mesh_object.data.splines:
                    try:
                        highest_point = max(
                            (mesh_object.matrix_world @ spline.points[-1].co).z
                            for spline in mesh_object.data.splines
                            if spline.points
                        )
                        text_location = Vector((
                            mesh_object.location.x,
                            mesh_object.location.y,
                            highest_point + 2.0
                        ))
                    except:
                        pass

                line_location = mesh_object.location

                verts = [
                    Vector((0, 0, 0)),
                    Vector((0, 0, 1.8))
                ]
                edges = [[0, 1]]

                line_mesh = bpy.data.meshes.new(f"{original_mesh_data_name}.j")
                line_mesh.from_pydata(verts, edges, [])
                line_mesh.update()

                line_object = bpy.data.objects.new(f"{original_mesh_name}.j", line_mesh)
                line_object.location = line_location

                bpy.ops.object.text_add(
                    radius=0.003 * 100,
                    enter_editmode=False,
                    align='WORLD',
                    location=text_location,
                    rotation=(1.5708, 0, 0),
                    scale=(1, 1, 1)
                )
                font_object = context.object
                font_object.name = f"{original_mesh_name}.t"
                font_object.data.name = f"{original_mesh_data_name}.t"
                font_object.data.body = original_mesh_name.upper()
                font_object.data.align_x = 'CENTER'

                mat = bpy.data.materials.get("Text")
                if mat is None:
                    mat = bpy.data.materials.new(name="Text")
                    mat.use_nodes = True
                    nodes = mat.node_tree.nodes
                    links = mat.node_tree.links
                    nodes.clear()
                    emission_node = nodes.new(type='ShaderNodeEmission')
                    emission_node.inputs['Strength'].default_value = 5.0
                    emission_node.location = (0, 0)
                    output_node = nodes.new(type='ShaderNodeOutputMaterial')
                    output_node.location = (200, 0)
                    links.new(emission_node.outputs['Emission'], output_node.inputs['Surface'])
                font_object.data.materials.append(mat)

                font_object.parent = line_object
                font_object.matrix_parent_inverse = line_object.matrix_world.inverted()

                for collection in list(font_object.users_collection):
                    collection.objects.unlink(font_object)
                for collection in list(line_object.users_collection):
                    collection.objects.unlink(line_object)

                for collection in collections:
                    collection.objects.link(line_object)
                    collection.objects.link(font_object)

                if parent:
                    line_object.parent = parent
                    line_object.matrix_parent_inverse = parent.matrix_world.inverted()

                for child in children:
                    child.parent = line_object
                    child.matrix_parent_inverse = line_object.matrix_world.inverted()

                font_object.rotation_mode = 'QUATERNION'
                self.create_top_hook(line_object, font_object)

                bpy.ops.object.select_all(action='DESELECT')
                mesh_object.select_set(True)
                context.view_layer.objects.active = mesh_object
                bpy.data.objects.remove(mesh_object, do_unlink=True)

                bpy.ops.object.select_all(action='DESELECT')
                line_object.select_set(True)
                context.view_layer.objects.active = line_object

            return {"FINISHED"}
        except Exception as e:
            self.report({'ERROR'}, f"Erreur : {e}")
            return {'CANCELLED'}

    def reset_transforms(self, obj):
        bpy.context.view_layer.objects.active = obj
        obj.select_set(True)
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        obj.delta_location = (0, 0, 0)
        obj.delta_rotation_euler = (0, 0, 0)
        obj.delta_rotation_quaternion = (1, 0, 0, 0)
        obj.delta_scale = (1, 1, 1)
        obj.select_set(False)

    def create_top_hook(self, line_object, text_child):
        if not text_child or not line_object:
            return

        try:
            bpy.ops.object.select_all(action='DESELECT')
            line_object.select_set(True)
            text_child.select_set(True)
            bpy.context.view_layer.objects.active = line_object

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='DESELECT')

            bm_line = bmesh.from_edit_mesh(line_object.data)
            bm_line.verts.ensure_lookup_table()
            if len(bm_line.verts) > 1:
                bm_line.verts[1].select = True
            bmesh.update_edit_mesh(line_object.data)

            bpy.ops.object.hook_add_selob()
            bpy.ops.object.mode_set(mode='OBJECT')

            for mod in line_object.modifiers:
                if mod.type == 'HOOK' and mod.object == text_child:
                    mod.name = "Hook_Top"
                    break
        except Exception as e:
            print(f"Erreur lors de la création du hook : {e}")
            bpy.ops.object.mode_set(mode='OBJECT')

# --- Opérateur pour créer un label gauche ---
class OBJECT_OT_make_label_from_mesh_alternative(bpy.types.Operator):
    bl_idname = "object.make_label_from_mesh_alternative"
    bl_label = "Create Left Label"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and len(context.selected_objects) > 0

    def execute(self, context):
        try:
            selected_objects = context.selected_objects[:]
            bpy.ops.object.select_all(action='DESELECT')

            for mesh_object in selected_objects:
                if mesh_object.type not in {'MESH', 'CURVE'}:
                    continue

                parent = mesh_object.parent
                children = mesh_object.children[:]
                collections = mesh_object.users_collection[:]
                original_mesh_name = mesh_object.name
                original_mesh_data_name = mesh_object.data.name

                self.reset_transforms(mesh_object)

                mesh_object.select_set(True)
                context.view_layer.objects.active = mesh_object

                text_location = mesh_object.location + Vector((0, 0, 2.0))
                if mesh_object.type == 'MESH' and mesh_object.data.vertices:
                    try:
                        highest_point = max((mesh_object.matrix_world @ v.co).z for v in mesh_object.data.vertices)
                        text_location = Vector((
                            mesh_object.location.x,
                            mesh_object.location.y,
                            highest_point + 2.0
                        ))
                    except:
                        pass
                elif mesh_object.type == 'CURVE' and mesh_object.data.splines:
                    try:
                        highest_point = max(
                            (mesh_object.matrix_world @ spline.points[-1].co).z
                            for spline in mesh_object.data.splines
                            if spline.points
                        )
                        text_location = Vector((
                            mesh_object.location.x,
                            mesh_object.location.y,
                            highest_point + 2.0
                        ))
                    except:
                        pass

                line_location = mesh_object.location

                verts = [
                    Vector((0, 0, 0)),
                    Vector((0, 0, 1.8))
                ]
                edges = [[0, 1]]

                line_mesh = bpy.data.meshes.new(f"{original_mesh_data_name}.i")
                line_mesh.from_pydata(verts, edges, [])
                line_mesh.update()

                line_object = bpy.data.objects.new(f"{original_mesh_name}.i", line_mesh)
                line_object.location = line_location

                bpy.ops.object.text_add(
                    radius=0.003 * 100,
                    enter_editmode=False,
                    align='WORLD',
                    location=text_location,
                    rotation=(1.5708, 0, 0),
                    scale=(1, 1, 1)
                )
                font_object = context.object
                font_object.name = f"{original_mesh_name}.s"
                font_object.data.name = f"{original_mesh_data_name}.s"
                font_object.data.body = original_mesh_name.upper()
                font_object.data.align_x = 'CENTER'

                mat = bpy.data.materials.get("Text")
                if mat is None:
                    mat = bpy.data.materials.new(name="Text")
                    mat.use_nodes = True
                    nodes = mat.node_tree.nodes
                    links = mat.node_tree.links
                    nodes.clear()
                    emission_node = nodes.new(type='ShaderNodeEmission')
                    emission_node.inputs['Strength'].default_value = 5.0
                    emission_node.location = (0, 0)
                    output_node = nodes.new(type='ShaderNodeOutputMaterial')
                    output_node.location = (200, 0)
                    links.new(emission_node.outputs['Emission'], output_node.inputs['Surface'])
                font_object.data.materials.append(mat)

                font_object.parent = line_object
                font_object.matrix_parent_inverse = line_object.matrix_world.inverted()

                for collection in list(font_object.users_collection):
                    collection.objects.unlink(font_object)
                for collection in list(line_object.users_collection):
                    collection.objects.unlink(line_object)

                for collection in collections:
                    collection.objects.link(line_object)
                    collection.objects.link(font_object)

                if parent:
                    line_object.parent = parent
                    line_object.matrix_parent_inverse = parent.matrix_world.inverted()

                for child in children:
                    child.parent = line_object
                    child.matrix_parent_inverse = line_object.matrix_world.inverted()

                font_object.rotation_mode = 'QUATERNION'
                self.create_top_hook(line_object, font_object)

                bpy.ops.object.select_all(action='DESELECT')
                mesh_object.select_set(True)
                context.view_layer.objects.active = mesh_object
                bpy.data.objects.remove(mesh_object, do_unlink=True)

                bpy.ops.object.select_all(action='DESELECT')
                line_object.select_set(True)
                context.view_layer.objects.active = line_object

            return {"FINISHED"}
        except Exception as e:
            self.report({'ERROR'}, f"Erreur : {e}")
            return {'CANCELLED'}

    def reset_transforms(self, obj):
        bpy.context.view_layer.objects.active = obj
        obj.select_set(True)
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        obj.delta_location = (0, 0, 0)
        obj.delta_rotation_euler = (0, 0, 0)
        obj.delta_rotation_quaternion = (1, 0, 0, 0)
        obj.delta_scale = (1, 1, 1)
        obj.select_set(False)

    def create_top_hook(self, line_object, text_child):
        if not text_child or not line_object:
            return

        try:
            bpy.ops.object.select_all(action='DESELECT')
            line_object.select_set(True)
            text_child.select_set(True)
            bpy.context.view_layer.objects.active = line_object

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='DESELECT')

            bm_line = bmesh.from_edit_mesh(line_object.data)
            bm_line.verts.ensure_lookup_table()
            if len(bm_line.verts) > 1:
                bm_line.verts[1].select = True
            bmesh.update_edit_mesh(line_object.data)

            bpy.ops.object.hook_add_selob()
            bpy.ops.object.mode_set(mode='OBJECT')

            for mod in line_object.modifiers:
                if mod.type == 'HOOK' and mod.object == text_child:
                    mod.name = "Hook_Top"
                    break
        except Exception as e:
            print(f"Erreur lors de la création du hook : {e}")
            bpy.ops.object.mode_set(mode='OBJECT')

# --- Panneau UI ---
class VIEW3D_PT_z_label_panel(bpy.types.Panel):
    bl_label = "Z-Label1"
    bl_idname = "VIEW3D_PT_z_label_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Z-Anatomy'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout

        layout.operator("object.make_label_from_mesh", text="Create Right Label")
        layout.operator("object.make_label_from_mesh_alternative", text="Create Left Label")

# --- Enregistrement ---
def register():
    classes = [
        OBJECT_OT_make_label_from_mesh,
        OBJECT_OT_make_label_from_mesh_alternative,
        VIEW3D_PT_z_label_panel,
    ]

    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    classes = [
        OBJECT_OT_make_label_from_mesh,
        OBJECT_OT_make_label_from_mesh_alternative,
        VIEW3D_PT_z_label_panel,
    ]
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    try:
        unregister()
    except:
        pass
    register()
