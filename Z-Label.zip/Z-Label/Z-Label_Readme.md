Here is the updated README with the corrected installation instructions in English:

# Z-Label Add-on for Blender

## Description

Z-Label is a Blender add-on designed to manage labels within the Z-Anatomy framework. It provides tools to create, modify, and manage text labels associated with vertices in your 3D models.

## Features

- Create custom labels at selected vertices.
- Use existing text names from the Text Editor as labels.
- Convert label transformations to delta for precise adjustments.
- Change labels easily with a user-friendly interface.

## Installation

1. Download the `.zip` file of the add-on.
2. Open Blender and go to `Edit` > `Preferences`.
3. Select the `Add-ons` tab and click the downward-facing arrow in the top-right corner.
4. Choose `Install from Disk` and select the downloaded `.zip` file.
5. Enable the add-on by checking the box next to "Z-Label".

## Usage

### Creating Labels

1. Select a vertex in Edit Mode or Object Mode.
2. Use the "Make Label" operator to create a label at the selected vertex.
3. Customize the label text if needed.

### Modifying Labels

1. Select the label object.
2. Use the "Label's Transforms to Delta" operator to convert transformations to delta.
3. Use the "Change Label" operator to update the label text.

### Panel

The add-on includes a panel in the 3D View UI under the "Z-Anatomy" category, providing easy access to all label management tools.

## Author

- **Marcin Zieliński**
- **Z-Anatomy**

## Compatibility

- Blender 2.80 and later versions.

## License

This add-on is distributed under the [CC-BY-SA 4.0](LICENSE) license, which allows sharing and adaptation with attribution and under the same terms.