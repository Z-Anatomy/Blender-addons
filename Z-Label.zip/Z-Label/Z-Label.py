# This program is free software: you can redistribute it and/or modify
# it under the terms of the Creative Commons Attribution-ShareAlike 4.0 International License (CC-BY-SA 4.0).
# 
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# For more information, visit the official license page: https://creativecommons.org/licenses/by-sa/4.0/


bl_info = {
    "name": "Z-Label",
    "blender": (2, 80, 0),  # Version de Blender compatible
    "category": "Object",
    "description": "Ajoute des labels aux objets dans Blender.",
    "author": "Votre Nom",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > Z-Anatomy",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
}

import bpy
from mathutils import Vector
import mathutils
from bpy_extras.object_utils import object_data_add

# Fonction pour nettoyer les noms en enlevant les suffixes spécifiques
def clean_name(name):
    for ending in ('.r', '.l', '.t', '.j', '.o', '.e', ''):
        if ending == '':
            return name, ending
        elif name.endswith(ending):
            clean_name = name[:-len(ending)]
            return clean_name, ending

# Fonction pour obtenir la famille d'objets (labels) associés à un objet parent
def family(object):
    def inner_elements(children):
        return tuple(ob for ob in children if any(x in ob.name for x in {".t", ".j"}))

    labels = inner_elements(object.children)
    family = [labels + (object,)]

    def rec(object, family):
        labels = inner_elements(object.children)
        family[0] += labels
        for ob in labels:
            rec(ob, family)

    for ob in object.children:
        rec(ob, family)

    return family.pop()

# Opérateur pour créer un label
class OBJECT_OT_make_label(bpy.types.Operator):
    """Make Label\n 1. Select vertex in Edit Mode"""
    bl_idname = "object.make_label"
    bl_label = "Make Label"
    bl_options = {'REGISTER', 'UNDO'}

    custom_label: bpy.props.StringProperty(default="Label", name="Label Name")

    @classmethod
    def poll(cls, context):
        return context.mode in {'EDIT_MESH', 'OBJECT'} and context.object is not None

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

    def execute(self, context):
        font_radius = 0.003
        font_x_align = 'CENTER'
        line_offset = 0.0015

        bpy.ops.object.mode_set(mode='OBJECT')

        selected_verts = [v for v in context.object.data.vertices if v.select]
        if len(selected_verts) != 1:
            self.report(type={"ERROR"}, message="Select one vertex.")
            return {"CANCELLED"}

        active_object = context.object
        vert_co = active_object.matrix_world @ Vector(selected_verts[0].co)
        text_co = vert_co.copy()
        text_co.z += 0.05
        line_end_co = vert_co.copy()

        bpy.ops.object.text_add(radius=font_radius, enter_editmode=False, align='WORLD', location=text_co, rotation=(1.5708, 0, 0), scale=(1, 1, 1))
        font_object = context.object
        font_object.name = f"{self.custom_label}.t"
        font_object.data.name = font_object.name
        font_object.data.body = self.custom_label.upper()
        font_object.data.align_x = font_x_align
        try:
            font_object.data.font = bpy.data.fonts["DejaVuSansCondensed"]
        except:
            self.report(type={"WARNING"}, message="Font DejaVuSansCondensed not found. Add it manually.")

        mat = bpy.data.materials.get("Text")
        if mat is None:
            mat = bpy.data.materials.new(name="Text")
        font_object.data.materials.append(mat)

        context.collection.objects.unlink(font_object)
        try:
            for col in active_object.users_collection:
                col.objects.link(font_object)
        except:
            pass

        verts = [text_co - Vector((0, 0, line_offset)), line_end_co]
        edges = [[0, 1]]
        faces = []
        mesh = bpy.data.meshes.new(name=f"{self.custom_label}.j")
        mesh.from_pydata(verts, edges, faces)

        old_cursor_loc = context.scene.cursor.location.copy()
        context.scene.cursor.location = (0, 0, 0)
        line_object = object_data_add(context, mesh)
        context.scene.cursor.location = old_cursor_loc
        line_object.hide_select = False  # Assurez-vous que l'objet est sélectionnable
        line_object.show_wire = True

        context.collection.objects.unlink(line_object)
        try:
            for col in active_object.users_collection:
                col.objects.link(line_object)
        except:
            pass

        line_object.data.transform(mathutils.Matrix.Translation(-text_co))
        line_object.matrix_world.translation += text_co

        line_object.parent = font_object
        line_object.matrix_parent_inverse = font_object.matrix_world.inverted()

        font_object.parent = active_object
        font_object.matrix_parent_inverse = active_object.matrix_world.inverted()
        font_object.delta_location = font_object.delta_location + font_object.location
        font_object.location = (0, 0, 0)

        hm = line_object.modifiers.new(name="Hook", type='HOOK')
        hm.object = active_object
        hm.vertex_indices_set([1])

        context.view_layer.objects.active = font_object
        font_object.select_set(True)
        font_object.hide_set(False)
        font_object.hide_select = False  # Assurez-vous que l'objet est sélectionnable

        return {"FINISHED"}

# Opérateur pour convertir les transformations d'un label en deltas
class OBJECT_OT_label_delta(bpy.types.Operator):
    """Convert label transforms to delta"""
    bl_idname = "object.transforms_to_deltas"
    bl_label = "Label's transforms to delta"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.object is not None and context.object.name.endswith('.t')

    def execute(self, context):
        label = context.object
        label.delta_location = label.delta_location + label.location
        label.delta_scale = label.delta_scale * label.scale
        label.location = (0,0,0)
        label.scale = (1,1,1)

        line = label.children[0]
        line.scale = (1,1,1)

        return {"FINISHED"}

# Opérateur pour modifier le texte d'un label existant
class OBJECT_OT_change_label_wrapper(bpy.types.Operator):
    """Change label\n 1. Select label"""
    bl_idname = "object.change_label"
    bl_label = "Change Label"
    bl_options = {'REGISTER', 'UNDO'}

    custom_label: bpy.props.StringProperty(default="Label", name="New Label")

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.object is not None and ".t" in context.object.name

    def execute(self, context):
        font_object = context.object
        line_object = context.object.children[0]

        font_object.name = font_object.data.name = f"{self.custom_label}.t"
        font_object.data.body = self.custom_label.upper()

        line_object.name = line_object.data.name = f"{self.custom_label}.j"

        return {"FINISHED"}

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

# Fonction pour gérer la visibilité des labels
def msgbus_callback(*args):
    active_object = bpy.context.active_object
    if not active_object or not active_object.data: return

    if ".t" in active_object.name:
        return

    for child in family(active_object):
        child.hide_set(False)
        child.hide_select = False  # Assurez-vous que l'objet est sélectionnable

    for ob in (o for o in bpy.context.visible_objects if ".t" in o.name):
        if not ob.parent == active_object:
            ob.hide_set(True)
            for child in ob.children:
                child.hide_set(True)

    for ob in (o for o in bpy.context.visible_objects if ob.name.endswith('...')):
        if ob == active_object:
            for child in ob.children:
                child.hide_set(False)
        else:
            for child in ob.children:
                child.hide_set(True)

# Panneau pour gérer les labels
class VIEW3D_PT_z_label_panel(bpy.types.Panel):
    bl_label = "Z-Label"
    bl_idname = "VIEW3D_PT_z_label_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Z-Anatomy'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.operator("object.make_label", text="Make Label")
        layout.operator("object.transforms_to_deltas", text="Transforms to Deltas")
        layout.operator("object.change_label", text="Change Label")

# Enregistrement des classes
def register():
    bpy.utils.register_class(OBJECT_OT_make_label)
    bpy.utils.register_class(OBJECT_OT_label_delta)
    bpy.utils.register_class(OBJECT_OT_change_label_wrapper)
    bpy.utils.register_class(VIEW3D_PT_z_label_panel)

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_make_label)
    bpy.utils.unregister_class(OBJECT_OT_label_delta)
    bpy.utils.unregister_class(OBJECT_OT_change_label_wrapper)
    bpy.utils.unregister_class(VIEW3D_PT_z_label_panel)

if __name__ == "__main__":
    register()
