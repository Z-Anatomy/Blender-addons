# Z-Hide Add-on for Blender

## Description
Z-Hide is a Blender add-on designed to **smartly hide and isolate objects** in the 3D viewport. It provides advanced tools for managing object visibility, especially useful for complex scenes with hierarchical structures (e.g., parent-child relationships).

## Features
- **Smart Hiding**: Hide selected objects, including their children, with options to follow parent visibility.
- **Isolation Tools**: Isolate selected objects or entire layers, with support for lights.
- **Local View with Lights**: Enter local view mode while keeping lights visible.
- **Toggle Functionality**: Enable or disable the add-on directly from the sidebar panel.

## Installation
1. Download the `.zip` file of the add-on.
2. Open Blender and go to `Edit` > `Preferences`.
3. Select the `Add-ons` tab and click the downward-facing arrow in the top-right corner.
4. Choose `Install from Disk` and select the downloaded `.zip` file.
5. Enable the add-on by checking the box next to **"Z-Hide"**.

## Usage
### Smart Hiding Panel
1. Open the **N-panel** in the 3D Viewport.
2. Navigate to the **Z-Anatomy** tab.
3. Enable the **Enable Add-on** checkbox to activate Z-Hide.
4. Use the following tools:
   - **Isolate on Layer**: Hide all objects except those in the active layer.
   - **Unhide Layer**: Show all hidden objects in the active layer.
   - **Local View with Lights**: Isolate selected objects in a local view while keeping lights visible.

### Keyboard Shortcuts
- Z-Hide automatically registers keyboard shortcuts for quick access to its features.
- Shortcuts are only active when the add-on is enabled.

## Author
- **Marcin Zieliński**
- **Z-Anatomy**

## Compatibility
- Blender 2.80 and later versions.

## License
This add-on is distributed under the [CC-BY-SA 4.0](LICENSE) license, which allows sharing and adaptation with attribution and under the same terms.
