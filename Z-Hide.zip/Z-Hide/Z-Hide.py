bl_info = {
    "name": "Z-Hide",
    "author": "Marcin Zieliński, Z-Anatomy",
    "description": "Hiding smartly",
    "blender": (2, 80, 0),
    "version": (0, 0, 1),
    "location": "View3D > Sidebar > Z-Anatomy",
    "warning": "",
    "category": "Interface"
}

import bpy
from mathutils import Vector
import mathutils
from bpy_extras.object_utils import object_data_add

def family_all(object):
    ''' Object + Grand children without ancestors '''
    family = []
    stack = [object]

    while stack:
        current = stack.pop()
        family.append(current)
        stack.extend(current.children)

    return family

def family(object):
    ''' Object + Grand children without ancestors '''
    family = []
    stack = [object]

    while stack:
        current = stack.pop()
        family.append(current)
        stack.extend(current.children)

    return family

class OBJECT_OT_hide_wrapper(bpy.types.Operator):
    """Hide"""
    bl_idname = "object.hide_wrapper"
    bl_label = "Hide"
    bl_options = {'REGISTER', 'UNDO'}

    unselected: bpy.props.BoolProperty(default=False, name="Hide unselected")
    unselected_in_layer: bpy.props.BoolProperty(default=False, name="From active layer")
    follow_parent: bpy.props.BoolProperty(default=True, name="Follow parent's visibility")

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.object is not None

    def execute(self, context):
        def findRoot(ob):
            while ob and ob.parent:
                if ob in objects_to:
                    objects_to.remove(ob)
                return ob

        roots = []
        objects_to = set(context.selected_objects)

        while objects_to:
            ob = objects_to.pop()
            roots.append(findRoot(ob))

        if self.unselected and not self.unselected_in_layer:
            all_visible_objects = set(context.visible_objects)
            lights = {l for l in context.view_layer.objects if l.type == 'LIGHT'}

            family_obs = {ob for r in roots for ob in family(r)}
            for ob in all_visible_objects - lights - family_obs:
                ob.hide_set(True)
        elif self.unselected and self.unselected_in_layer:
            all_layer_objects = set()
            for c in context.scene.collection.children:
                if context.object.name in c.all_objects:
                    all_layer_objects = set(c.all_objects)
                    break
            lights = {l for l in context.view_layer.objects if l.type == 'LIGHT'}

            family_obs = {ob for r in roots for ob in family(r)}
            for ob in all_layer_objects - family_obs - lights:
                ob.hide_set(True)
        else:
            if self.follow_parent:
                family_obs = {ob for r in roots for ob in family_all(r)}
            else:
                family_obs = {ob for r in roots for ob in family(r)}

            for ob in family_obs:
                ob.hide_set(True)

        return {'FINISHED'}

class OBJECT_OT_hide_view_clear_wrapper(bpy.types.Operator):
    """Show Hidden Objects"""
    bl_idname = "object.hide_view_clear_wrapper"
    bl_label = "Show Hidden Objects"
    bl_options = {'REGISTER', 'UNDO'}

    select: bpy.props.BoolProperty()
    active_layer: bpy.props.BoolProperty(default=False, name="Affect only active layer")

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        if self.active_layer:
            for col in context.scene.collection.children:
                if context.object.name in col.all_objects:
                    break

            for ob in col.all_objects:
                ob.hide_set(False)
        else:
            bpy.ops.object.hide_view_clear(select=self.select)

        return {'FINISHED'}

class OBJECT_OT_isolate_wrapper(bpy.types.Operator):
    """Isolate Selected Objects"""
    bl_idname = "object.isolate_wrapper"
    bl_label = "Isolate Selected"
    bl_options = {'REGISTER', 'UNDO'}

    unselected_in_layer: bpy.props.BoolProperty(default=False, name="From active layer")

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.object is not None

    def execute(self, context):
        def findRoot(ob):
            while ob and ob.parent:
                if ob in objects_to:
                    objects_to.remove(ob)
                return ob

        roots = []
        objects_to = set(context.selected_objects)

        while objects_to:
            ob = objects_to.pop()
            roots.append(findRoot(ob))

        if self.unselected_in_layer:
            all_layer_objects = set()
            for c in context.scene.collection.children:
                if context.object.name in c.all_objects:
                    all_layer_objects = set(c.all_objects)
                    break
            lights = {l for l in context.view_layer.objects if l.type == 'LIGHT'}

            family_obs = {ob for r in roots for ob in family(r)}
            for ob in all_layer_objects - family_obs - lights:
                ob.hide_set(True)
        else:
            all_visible_objects = set(context.visible_objects)
            lights = {l for l in context.view_layer.objects if l.type == 'LIGHT'}

            family_obs = {ob for r in roots for ob in family(r)}
            for ob in all_visible_objects - lights - family_obs:
                ob.hide_set(True)

        return {'FINISHED'}

class OBJECT_OT_isolate_on_layer_wrapper(bpy.types.Operator):
    """Isolate Selected Objects on Active Layer"""
    bl_idname = "object.isolate_on_layer_wrapper"
    bl_label = "Isolate on Layer"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.object is not None

    def execute(self, context):
        def findRoot(ob):
            while ob and ob.parent:
                if ob in objects_to:
                    objects_to.remove(ob)
                return ob

        roots = []
        objects_to = set(context.selected_objects)

        while objects_to:
            ob = objects_to.pop()
            roots.append(findRoot(ob))

        all_layer_objects = set()
        for c in context.scene.collection.children:
            if context.object.name in c.all_objects:
                all_layer_objects = set(c.all_objects)
                break
        lights = {l for l in context.view_layer.objects if l.type == 'LIGHT'}

        family_obs = {ob for r in roots for ob in family(r)}
        for ob in all_layer_objects - family_obs - lights:
            ob.hide_set(True)

        return {'FINISHED'}

class OBJECT_OT_unhide_layer_wrapper(bpy.types.Operator):
    """Unhide All Objects in Active Layer"""
    bl_idname = "object.unhide_layer_wrapper"
    bl_label = "Unhide Layer"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        for col in context.scene.collection.children:
            if context.object.name in col.all_objects:
                for ob in col.all_objects:
                    ob.hide_set(False)
                break

        return {'FINISHED'}

def get_user_keymap_item(keymap_name, keymap_item_idname, multiple_entries=False):
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.user

    km = kc.keymaps.get(keymap_name)
    if multiple_entries:
        return km, [i[1] for i in km.keymap_items.items() if i[0] == keymap_item_idname]
    else:
        return km, km.keymap_items.get(keymap_item_idname)

def register_keymaps():
    kc = bpy.context.window_manager.keyconfigs
    areas = ['Window', 'Text', 'Object Mode', '3D View']

    if not all(i in kc.active.keymaps for i in areas):
        return

    wm = bpy.context.window_manager
    addon_km = wm.keyconfigs.addon.keymaps.new(name='Object Mode', space_type='EMPTY')

    try:
        km, kmis = get_user_keymap_item('Object Mode', 'object.hide_view_set', multiple_entries=True)
        for default_kmi in kmis:
            addon_kmi = addon_km.keymap_items.new(OBJECT_OT_hide_wrapper.bl_idname, default_kmi.type, default_kmi.value)
            addon_kmi.map_type = default_kmi.map_type
            if hasattr(addon_kmi, 'repeat'):
                addon_kmi.repeat = default_kmi.repeat
            addon_kmi.any = default_kmi.any
            addon_kmi.shift = default_kmi.shift
            addon_kmi.ctrl = default_kmi.ctrl
            addon_kmi.alt = default_kmi.alt
            addon_kmi.oskey = default_kmi.oskey
            addon_kmi.key_modifier = default_kmi.key_modifier

            for prop in default_kmi.properties.__dir__():
                if not (prop.startswith('_') or prop in {'bl_rna', 'rna_type'}):
                    setattr(addon_kmi.properties, prop, getattr(default_kmi.properties, prop))

            addon_kmi.properties.unselected_in_layer = False
            addon_keymaps.append((addon_km, addon_kmi))

        addon_kmi = addon_km.keymap_items.new(OBJECT_OT_hide_wrapper.bl_idname, kmis[0].type, kmis[0].value)
        addon_kmi.map_type = "KEYBOARD"
        if hasattr(addon_kmi, 'repeat'):
            addon_kmi.repeat = False
        addon_kmi.any = False
        addon_kmi.shift = True
        addon_kmi.ctrl = True
        addon_kmi.alt = False
        addon_kmi.oskey = False
        addon_kmi.key_modifier = "NONE"
        addon_kmi.properties.unselected = True
        addon_kmi.properties.unselected_in_layer = True
        addon_keymaps.append((addon_km, addon_kmi))

        km, kmis = get_user_keymap_item('Object Mode', 'object.hide_view_clear', multiple_entries=True)
        for default_kmi in kmis:
            addon_kmi = addon_km.keymap_items.new(OBJECT_OT_hide_view_clear_wrapper.bl_idname, default_kmi.type, default_kmi.value)
            addon_kmi.map_type = default_kmi.map_type
            if hasattr(addon_kmi, 'repeat'):
                addon_kmi.repeat = default_kmi.repeat
            addon_kmi.any = default_kmi.any
            addon_kmi.shift = default_kmi.shift
            addon_kmi.ctrl = default_kmi.ctrl
            addon_kmi.alt = default_kmi.alt
            addon_kmi.oskey = default_kmi.oskey
            addon_kmi.key_modifier = default_kmi.key_modifier

            for prop in default_kmi.properties.__dir__():
                if not (prop.startswith('_') or prop in {'bl_rna', 'rna_type'}):
                    setattr(addon_kmi.properties, prop, getattr(default_kmi.properties, prop))

            addon_kmi.properties.active_layer = False
            addon_keymaps.append((addon_km, addon_kmi))

        km, kmis = get_user_keymap_item('3D View', 'view3d.localview', multiple_entries=True)
        for default_kmi in kmis:
            addon_kmi = addon_km.keymap_items.new(OBJECT_OT_local_view_wrapper.bl_idname, default_kmi.type, default_kmi.value)
            addon_kmi.map_type = default_kmi.map_type
            addon_kmi.repeat = default_kmi.repeat
            addon_kmi.any = default_kmi.any
            addon_kmi.shift = default_kmi.shift
            addon_kmi.ctrl = default_kmi.ctrl
            addon_kmi.alt = default_kmi.alt
            addon_kmi.oskey = default_kmi.oskey
            addon_kmi.key_modifier = default_kmi.key_modifier

            for prop in default_kmi.properties.__dir__():
                if not (prop.startswith('_') or prop in {'bl_rna', 'rna_type'}):
                    setattr(addon_kmi.properties, prop, getattr(default_kmi.properties, prop))

            addon_keymaps.append((addon_km, addon_kmi))
    except Exception as e:
        print(f"Error registering keymaps: {e}")

addon_keymaps = []

def add_shortkeys():
    register_keymaps()

def remove_shortkeys():
    wm = bpy.context.window_manager
    for km, kmi in addon_keymaps:
        try:
            km.keymap_items.remove(kmi)
        except:
            pass

    addon_keymaps.clear()

class OBJECT_OT_local_view_wrapper(bpy.types.Operator):
    """Local view (with lights)"""
    bl_idname = "view3d.localview_lights"
    bl_label = "Local View (w/ lights)"

    frame_selected: bpy.props.BoolProperty(default=True, name="Frame Selected")

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.object is not None

    def execute(self, context):
        def findRoot(ob):
            while ob and ob.parent:
                if ob in objects_to:
                    objects_to.remove(ob)
                return ob

        roots = []
        objects_to = set(context.selected_objects)
        selected_objects = list(objects_to)
        while objects_to:
            ob = objects_to.pop()
            roots.append(findRoot(ob))

        lights = [o for o in context.visible_objects if o.type == 'LIGHT']
        hide_selects = []
        hidden = []
        obj_family = []
        for obj in roots:
            obj_family += list(family(obj))
        obj_family += lights

        for ob in obj_family:
            if ob.hide_get():
                ob.hide_set(False)
                hidden.append(ob)
            if ob.hide_select:
                ob.hide_select = False
                hide_selects.append(ob)
            ob.select_set(True)

        bpy.ops.view3d.localview('INVOKE_DEFAULT', frame_selected=self.frame_selected)

        for ob in obj_family:
            ob.select_set(False)
        obj.select_set(True)
        for ob in hide_selects:
            ob.hide_select = True
        for ob in hidden:
            ob.hide_set(True)

        for ob in selected_objects:
            ob.select_set(True)
        bpy.ops.view3d.view_selected()

        self.previous_view = context.space_data.region_3d.view_matrix.copy()

        return {"FINISHED"}

    def cancel(self, context):
        if hasattr(self, 'previous_view'):
            context.space_data.region_3d.view_matrix = self.previous_view

        return {'CANCELLED'}

class ZAnatomyProps(bpy.types.PropertyGroup):
    enable_addon: bpy.props.BoolProperty(default=True, name="Enable Add-on", description="Enable or disable the add-on functionality")

class ZANATOMY_PT_sync_panel(bpy.types.Panel):
    bl_label = "Smart hiding"
    bl_idname = "VIEW3D_PT_smart_hiding"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Z-Anatomy'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.prop(context.scene.zanatomy, "enable_addon")
        if context.scene.zanatomy.enable_addon:
            layout.operator("object.isolate_on_layer_wrapper", text="Isolate on Layer")
            layout.operator("object.unhide_layer_wrapper", text="Unhide Layer")
            layout.operator("view3d.localview_lights", text="Local View with Lights")

classes = (
    OBJECT_OT_hide_wrapper,
    OBJECT_OT_hide_view_clear_wrapper,
    OBJECT_OT_isolate_wrapper,
    OBJECT_OT_isolate_on_layer_wrapper,
    OBJECT_OT_unhide_layer_wrapper,
    OBJECT_OT_local_view_wrapper,
    ZAnatomyProps,
    ZANATOMY_PT_sync_panel,
)

def register():
    for c in classes:
        bpy.utils.register_class(c)

    bpy.types.Scene.zanatomy = bpy.props.PointerProperty(type=ZAnatomyProps)

    add_shortkeys()

def unregister():
    for c in classes:
        bpy.utils.unregister_class(c)

    remove_shortkeys()

if __name__ == "__main__":
    register()
