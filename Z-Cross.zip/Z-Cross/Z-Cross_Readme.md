# Z-Cross Add-on for Blender

## Description

Z-Cross is a Blender add-on that provides tools for managing cross-sections in Z-Anatomy. It allows integration of a specific node-group into all materials and manages named cutting planes.

## Features

- Integrates a specific node-group into all materials.
- Manages named cutting planes.
- Supports collections and individual objects.

## Installation

1. Download the `.zip` file of the add-on.
2. Open Blender and go to `Edit` > `Preferences`.
3. Select the `Add-ons` tab and click the downward-facing arrow in the top-right corner.
4. Choose `Install from Disk` and select the downloaded `.zip` file.
5. Enable the add-on by checking the box next to "Z-Label".

## Usage

### Node-Group

A specific node-group is included in the `Cross-sections.blend` file. To use it:

1. Open the `Cross-sections.blend` file.
2. Select the node-group and add it to your materials.

### Cutting Planes

To manage cutting planes:

1. Select a collection or an object.
2. Use the provided operators to enable or disable cross-sections along the X, Y, or Z axes.
3. Inversion options are also available for each axis.

## Included Files

- `Cross-sections.blend`: Example file containing the node-group and cutting planes.

## Author

- **Marcin Zieliński**
- **Z-Anatomy**

## Compatibility

- Blender 2.80 and later versions.

## License

This add-on is distributed under the [CC-BY-SA 4.0](LICENSE) license, which allows sharing and adaptation with attribution and under the same terms.

