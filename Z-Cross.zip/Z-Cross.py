bl_info = {
    "name": "Z-Cross Section",
    "author": "Marcin Zielinski; Gauthier KERVYN",
    "version": (0, 0, 1),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > Z-Anatomy",
    "description": "Manage cross-section for collections",
    "warning": "",
    "category": "Object",
}

import bpy

def is_mesh_collection(collection):
    return len(collection.all_objects) > 0

def is_cutting_plane(collection):
    return collection.get('is_cutting_plane', False)

class OBJECT_OT_collection_x_section(bpy.types.Operator):
    bl_idname = "collection.cross_section"
    bl_label = "Collection Cross Section"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    collection_name: bpy.props.StringProperty()
    enable: bpy.props.BoolProperty()
    axis: bpy.props.EnumProperty(
        items=[
            ('X', 'X', '', 0),
            ('Y', 'Y', '', 1),
            ('Z', 'Z', '', 2),
        ],
        default='X',
        name="Axis"
    )
    invert: bpy.props.BoolProperty()

    def execute(self, context):
        if not self.collection_name:
            self.report({'ERROR'}, "No collection specified.")
            return {"CANCELLED"}

        if self.collection_name in bpy.data.collections:
            collection = bpy.data.collections[self.collection_name]
            for axis in ['X', 'Y', 'Z']:
                if f'Cross-section-{axis}' not in collection:
                    collection[f'Cross-section-{axis}'] = False
                if f'Cross-section-{axis}-inverse' not in collection:
                    collection[f'Cross-section-{axis}-inverse'] = False

            collection[f'Cross-section-{self.axis}'] = self.enable
            collection[f'Cross-section-{self.axis}-inverse'] = self.invert

            for ob in collection.all_objects:
                for axis in ['X', 'Y', 'Z']:
                    if f'Cross-section-{axis}' not in ob:
                        ob[f'Cross-section-{axis}'] = False
                    if f'Cross-section-{axis}-inverse' not in ob:
                        ob[f'Cross-section-{axis}-inverse'] = False
                ob[f'Cross-section-{self.axis}'] = self.enable
                ob[f'Cross-section-{self.axis}-inverse'] = self.invert
                ob.update_tag(refresh={'OBJECT'})

            context.area.tag_redraw()
        else:
            self.report({'ERROR'}, f"Collection '{self.collection_name}' not found.")
        return {"FINISHED"}

class VIEW3D_PT_z_cross_panel(bpy.types.Panel):
    bl_label = "Cross section"
    bl_idname = "VIEW3D_PT_z_cross"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Z-Anatomy'
    bl_context = 'objectmode'

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.label(text="Active:")

        for collection in bpy.data.collections:
            if any(f'Cross-section-{axis}' in collection for axis in ['X', 'Y', 'Z']):
                for axis in ['X', 'Y', 'Z']:
                    if f'Cross-section-{axis}' not in collection:
                        collection[f'Cross-section-{axis}'] = False
                    if f'Cross-section-{axis}-inverse' not in collection:
                        collection[f'Cross-section-{axis}-inverse'] = False

                row = col.split(factor=0.5, align=True)
                row.label(text=collection.name)
                box = row.box()
                sub = box.grid_flow(row_major=True, columns=3, align=True)

                for axis in ['X', 'Y', 'Z']:
                    emboss, depress = (True, True) if collection[f'Cross-section-{axis}'] else (True, False)
                    op = sub.operator("collection.cross_section", emboss=emboss, depress=depress, text=axis)
                    op.collection_name = collection.name
                    op.axis = axis
                    op.enable = not collection[f'Cross-section-{axis}']

                for axis in ['X', 'Y', 'Z']:
                    emboss, depress = (True, True) if collection[f'Cross-section-{axis}-inverse'] else (True, False)
                    op = sub.operator("collection.cross_section", emboss=emboss, depress=depress, text='', icon='ARROW_LEFTRIGHT')
                    op.collection_name = collection.name
                    op.axis = axis
                    op.enable = collection[f'Cross-section-{axis}']
                    op.invert = not collection[f'Cross-section-{axis}-inverse']

def register():
    bpy.utils.register_class(OBJECT_OT_collection_x_section)
    bpy.utils.register_class(VIEW3D_PT_z_cross_panel)

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_collection_x_section)
    bpy.utils.unregister_class(VIEW3D_PT_z_cross_panel)

if __name__ == "__main__":
    register()