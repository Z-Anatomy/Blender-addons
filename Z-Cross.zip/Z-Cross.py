bl_info = {
    "name": "Z-Cross",
    "author": "Marcin Zieliński, Z-Anatomy",
    "description": "Tools to manage cross sections (mesh objects only).",
    "blender": (2, 80, 0),
    "version": (0, 0, 1),
    "location": "View3D > Sidebar > Z-Anatomy > Z-Cross",
    "warning": "",
    "category": "Interface"
}

import bpy

def is_mesh_collection(collection):
    """Retourne True si la collection contient au moins un objet mesh."""
    return any(ob.type == 'MESH' for ob in collection.all_objects)

def is_cutting_plane(collection):
    """Retourne True si la collection est marquée comme un plan de coupe (optionnel)."""
    return collection.get('is_cutting_plane', False)

class OBJECT_OT_collection_x_section(bpy.types.Operator):
    bl_idname = "collection.cross_section"
    bl_label = "Collection Cross Section"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    collection_name: bpy.props.StringProperty()
    enable: bpy.props.BoolProperty()
    axis: bpy.props.EnumProperty(
        items=[
            ('X', 'X', '', 0),
            ('Y', 'Y', '', 1),
            ('Z', 'Z', '', 2),
        ],
        default='X',
        name="Axis"
    )
    invert: bpy.props.BoolProperty()

    def execute(self, context):
        if not self.collection_name:
            self.report({'ERROR'}, "No collection specified.")
            return {"CANCELLED"}

        if self.collection_name in bpy.data.collections:
            collection = bpy.data.collections[self.collection_name]
            # Initialise les propriétés si elles n'existent pas
            for axis in ['X', 'Y', 'Z']:
                if f'Cross-section-{axis}' not in collection:
                    collection[f'Cross-section-{axis}'] = False
                if f'Cross-section-{axis}-inverse' not in collection:
                    collection[f'Cross-section-{axis}-inverse'] = False

            # Met à jour la propriété de la collection
            collection[f'Cross-section-{self.axis}'] = self.enable
            collection[f'Cross-section-{self.axis}-inverse'] = self.invert

            # Met à jour les objets mesh de la collection
            for ob in collection.all_objects:
                if ob.type == 'MESH':
                    ob[f'Cross-section-{self.axis}'] = self.enable
                    ob[f'Cross-section-{self.axis}-inverse'] = self.invert
                    ob.update_tag(refresh={'OBJECT'})

            context.area.tag_redraw()
        else:
            self.report({'ERROR'}, f"Collection '{self.collection_name}' not found.")
        return {"FINISHED"}

class VIEW3D_PT_z_cross_panel(bpy.types.Panel):
    bl_label = "Cross section"
    bl_idname = "VIEW3D_PT_z_cross"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Z-Anatomy'
    bl_context = 'objectmode'

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.label(text="Active:")

        # --- Filtrer les collections contenant des objets mesh et marquées pour les coupes ---
        for collection in bpy.data.collections:
            if is_mesh_collection(collection) and any(f'Cross-section-{axis}' in collection for axis in ['X', 'Y', 'Z']):
                # Initialise les propriétés si elles n'existent pas
                for axis in ['X', 'Y', 'Z']:
                    if f'Cross-section-{axis}' not in collection:
                        collection[f'Cross-section-{axis}'] = False
                    if f'Cross-section-{axis}-inverse' not in collection:
                        collection[f'Cross-section-{axis}-inverse'] = False

                # Affiche la collection
                row = col.split(factor=0.5, align=True)
                row.label(text=collection.name)
                box = row.box()
                sub = box.grid_flow(row_major=True, columns=3, align=True)

                # Boutons pour X, Y, Z
                for axis in ['X', 'Y', 'Z']:
                    emboss, depress = (True, True) if collection[f'Cross-section-{axis}'] else (True, False)
                    op = sub.operator("collection.cross_section", emboss=emboss, depress=depress, text=axis)
                    op.collection_name = collection.name
                    op.axis = axis
                    op.enable = not collection[f'Cross-section-{axis}']

                # Boutons d'inversion pour X, Y, Z
                for axis in ['X', 'Y', 'Z']:
                    emboss, depress = (True, True) if collection[f'Cross-section-{axis}-inverse'] else (True, False)
                    op = sub.operator("collection.cross_section", emboss=emboss, depress=depress, text='', icon='ARROW_LEFTRIGHT')
                    op.collection_name = collection.name
                    op.axis = axis
                    op.enable = collection[f'Cross-section-{axis}']
                    op.invert = not collection[f'Cross-section-{axis}-inverse']

def register():
    bpy.utils.register_class(OBJECT_OT_collection_x_section)
    bpy.utils.register_class(VIEW3D_PT_z_cross_panel)

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_collection_x_section)
    bpy.utils.unregister_class(VIEW3D_PT_z_cross_panel)

if __name__ == "__main__":
    register()
