# Z-Cross Add-on for Blender

## Description
Z-Cross is a Blender add-on designed to manage **cross-sections** for **Z-Anatomy**. It integrates a **specific node group** into materials and manages **named cutting planes**, providing precise control over cross-sections along the X, Y, and Z axes.

This add-on is particularly useful for:
- Studying **3D anatomy** with accurate cross-sections.
- Filtering **collections and objects** to focus only on relevant elements.
- Synchronizing **cross-section properties** between collections and their objects.

---

## Features
- **Node Group Integration**: Automatically integrates a node group into all materials to handle cross-sections.
- **Cutting Plane Management**: Uses named cutting planes (Empty objects or mesh planes) to define geometric references for cross-sections.
- **Collection and Object Support**: Allows control over both collections and individual objects.
- **Automatic Filtering**: Filters out non-relevant collections/objects (e.g., lights, cameras).
- **Custom Properties**: Uses integer-based custom properties to enable/disable cross-sections and inversion.

---

## Why Use Cutting Planes in the Node Group?
Cutting planes (Empty objects or mesh planes) serve as **geometric references** for cross-sections. Their role is critical:

- **Define Geometric References**:
  Cutting planes specify **where and how** objects should be sliced. For example, a plane positioned at `X = 0.5` will hide parts of objects on one side of the plane.

- **Integration with Node Group**:
  The node group uses the **coordinates of the planes** (position, orientation) to calculate cross-sections. It then applies this information to **material shaders**, creating a visual slicing effect.

- **Example**:
  If a cutting plane is positioned at `X = 0.5`, the node group will hide parts of objects where `X > 0.5` (or `X < 0.5` if inverted).

---

## Why Use Custom Properties on Collections and Objects?
Custom properties (`Cross-section-X`, `Cross-section-Y`, etc.) are essential for:

### **On Collections**:
- **Filter Relevant Collections**:
  Only collections with these properties will appear in the **Z-Cross panel**, avoiding clutter from irrelevant collections (e.g., lights, cameras).

- **Enable/Disable Cross-Sections**:
  These properties store the **state of cross-sections** (enabled/disabled) for each axis. For example, `Cross-section-X = 1` enables the X-axis cross-section for the collection.

- **Synchronization with Objects**:
  Collection properties are automatically **replicated to their mesh objects** for consistent management.

### **On Objects**:
- **Individual Control**:
  Allows per-object control of cross-sections, even if the object belongs to a collection. For example, an object can have `Cross-section-X = 0` even if its collection has `Cross-section-X = 1`.

- **Compatibility with Node Group**:
  The node group uses these properties to determine **whether an object should be sliced** and along which axis. Without them, the node group cannot function correctly.

---

## Why Filter Collections and Objects?
Filtering is essential for:

- **Avoiding Overload**:
  Without filtering, the **Z-Cross panel** would display all collections, including irrelevant ones (e.g., lights, cameras, empty collections).

- **Performance Optimization**:
  The script only processes **eligible collections/objects** (those containing meshes and marked for cross-sections), improving performance.

- **Consistency with Node Group**:
  The node group is designed to work with **mesh objects**. Filtering ensures it only processes relevant objects.

---

## Installation
1. Download the `.zip` file of the add-on.
2. In Blender, go to `Edit > Preferences`.
3. Select the `Add-ons` tab and click the downward arrow in the top-right corner.
4. Choose `Install from Disk` and select the downloaded `.zip` file.
5. Enable the add-on by checking the box next to **"Z-Cross"**.

---

## Usage

### Node Group
A **specific node group** (`CrossSectionControllerGroup`) is included in the `Cross-sections.blend` file. To use it:
1. Open the `Cross-sections.blend` file.
2. Select the node group and add it to your materials.

### Cutting Planes
To manage cutting planes:
1. **Create Empty Objects or Mesh Planes**:
   - Example: An Empty object named `CuttingPlane_X` positioned at `X = 0`.
2. **Link Planes to Node Group**:
   - In the node group, reference the cutting planes by name or object (e.g., using an *Object Info* node + *Value* node to retrieve their position).
3. **Use the Z-Cross Panel**:
   - Select a collection or object.
   - Use the operators to enable/disable cross-sections along the X, Y, or Z axes.
   - Inversion options are also available for each axis.

---

## Initializing Custom Properties
If your collections and objects do not yet have the required **custom properties**, initialize them with this script (run in Blender's Python console):

```python
import bpy

def is_mesh_collection(collection):
    """Check if the collection contains at least one mesh object."""
    return any(ob.type == 'MESH' for ob in collection.all_objects)

# Initialize integer-based Cross-section properties for all mesh collections
for collection in bpy.data.collections:
    if is_mesh_collection(collection):
        for axis in ['X', 'Y', 'Z']:
            if f'Cross-section-{axis}' not in collection:
                collection[f'Cross-section-{axis}'] = 0  # Integer (0 = disabled, 1 = enabled)
            if f'Cross-section-{axis}-inverse' not in collection:
                collection[f'Cross-section-{axis}-inverse'] = 0  # Integer (0 = normal, 1 = inverted)
        print(f"Custom properties initialized for collection: {collection.name}")
