# This program is free software: you can redistribute it and/or modify
# it under the terms of the Creative Commons Attribution-ShareAlike 4.0 International License (CC-BY-SA 4.0).
# 
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# For more information, visit the official license page: https://creativecommons.org/licenses/by-sa/4.0/

bl_info = {
    "name": "Z-Def",
    "author": "Marcin Zieliński, Z-Anatomy",
    "description": "Synchronize the text editor with a .txt file matching the active object's data name.",
    "blender": (2, 80, 0),
    "version": (0, 0, 1),
    "location": "View3D > Sidebar > Sync Text",
    "category": "Interface"
}

import bpy
import os

def clean_name(name):
    # Remove any unwanted characters from the name
    return os.path.splitext(name)[0], ""

def msgbus_callback(*args):
    # Sync selection to text editor
    active_object = bpy.context.active_object
    if not active_object or not active_object.data:
        return

    basename, _ = clean_name(active_object.data.name)
    text_editor_area = None
    for area in bpy.context.screen.areas:
        if area.type == "TEXT_EDITOR":
            text_editor_area = area
            break

    if text_editor_area and basename in bpy.data.texts:
        text_editor_area.spaces[0].text = bpy.data.texts[basename]
        text_editor_area.spaces[0].top = 0
        text_editor_area.spaces[0].text.select_set(0, 0, 0, 0)

class ZAnatomyDefProps(bpy.types.PropertyGroup):
    sync_text: bpy.props.BoolProperty(
        name="Sync Text Editor",  # Texte affiché à côté de la checkbox
        description="Toggle the synchronization of the text editor with the active object's data name",
        default=True,
        update=lambda self, context: msgbus_callback() if self.sync_text else None
    )

class SYNCTEXT_PT_sync_text_panel(bpy.types.Panel):
    bl_label = "Show Definition"  # Texte de l'onglet
    bl_idname = "VIEW3D_PT_sync_text"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Z-Anatomy'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        zanatomy = context.scene.zanatomy_def
        layout.prop(zanatomy, "sync_text")  # Correct property name

def register():
    bpy.utils.register_class(ZAnatomyDefProps)
    bpy.utils.register_class(SYNCTEXT_PT_sync_text_panel)
    bpy.types.Scene.zanatomy_def = bpy.props.PointerProperty(type=ZAnatomyDefProps)

    # Subscribe to changes in the active object
    bpy.msgbus.subscribe_rna(
        key=(bpy.types.LayerObjects, 'active'),
        owner=bpy.context.window_manager,
        args=(),
        notify=lambda: msgbus_callback() if bpy.context.scene.zanatomy_def.sync_text else None,
    )

    # Force UI update after registration
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

def unregister():
    bpy.utils.unregister_class(ZAnatomyDefProps)
    bpy.utils.unregister_class(SYNCTEXT_PT_sync_text_panel)
    del bpy.types.Scene.zanatomy_def

    # Clear the msgbus subscription
    bpy.msgbus.clear_by_owner(bpy.context.window_manager)

if __name__ == "__main__":
    register()
