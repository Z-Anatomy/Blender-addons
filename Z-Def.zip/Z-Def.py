# This program is free software: you can redistribute it and/or modify
# it under the terms of the Creative Commons Attribution-ShareAlike 4.0 International License (CC-BY-SA 4.0).
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# For more information, visit the official license page: https://creativecommons.org/licenses/by-sa/4.0/

bl_info = {
    "name": "Z-Def",
    "author": "Marcin Zieliński, Z-Anatomy (modifié pour Blender 4.5.0)",
    "description": "Synchronise automatiquement l'éditeur de texte avec l'objet actif dès que la checkbox est cochée.",
    "blender": (4, 5, 0),
    "version": (0, 1, 2),
    "location": "View3D > Sidebar > Z-Anatomy",
    "category": "Interface"
}

import bpy

def clean_name(name):
    """Nettoie le nom du datablock en retirant uniquement les suffixes Blender (.001, .002, etc.)."""
    # Supprime les suffixes de type .001, .002, etc. ajoutés par Blender
    if '.' in name:
        parts = name.rsplit('.', 1)
        # Vérifie si la partie après le point est un nombre (suffixe Blender)
        if len(parts) == 2 and parts[1].isdigit():
            return parts[0]
    return name

def msgbus_callback(*args):
    """Callback pour synchroniser l'éditeur de texte UNIQUEMENT lors d'un changement d'objet actif."""
    try:
        if not bpy.context.scene.zanatomy_def.sync_text:
            return

        active_object = bpy.context.active_object
        if not active_object or not hasattr(active_object, "data"):
            print("Z-Def: Aucun objet actif ou objet sans data.")
            return

        # Utiliser TA2ID comme clé stable si disponible
        ta2id_name = active_object.get("TA2ID", active_object.data.name)
        basename = clean_name(ta2id_name)

        if basename not in bpy.data.texts:
            print(f"Z-Def: Texte '{basename}' introuvable.")
            return

        # Trouver l'éditeur de texte ouvert
        text_editor_area = next((area for area in bpy.context.screen.areas if area.type == "TEXT_EDITOR"), None)
        if not text_editor_area:
            print("Z-Def: Aucun éditeur de texte ouvert.")
            return

        # Synchroniser UNIQUEMENT si le texte actuel est différent
        current_text = text_editor_area.spaces[0].text
        if current_text and current_text.name != basename:
            text_editor_area.spaces[0].text = bpy.data.texts[basename]
            text_editor_area.spaces[0].top = 0
            text_editor_area.spaces[0].text.select_set(0, 0, 0, 0)
            text_editor_area.tag_redraw()
            print(f"Z-Def: Synchronisation réussie pour '{basename}'.")

    except Exception as e:
        print(f"Z-Def Error: {str(e)}")

class ZAnatomyDefProps(bpy.types.PropertyGroup):
    sync_text: bpy.props.BoolProperty(
        name="Sync Text Editor",
        description="Active la synchronisation automatique de l'éditeur de texte avec l'objet actif",
        default=True,
        update=lambda self, context: msgbus_callback() if self.sync_text else None
    )

class SYNCTEXT_PT_sync_text_panel(bpy.types.Panel):
    bl_label = "Show Definition"
    bl_idname = "VIEW3D_PT_sync_text"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Z-Anatomy'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        zanatomy = context.scene.zanatomy_def
        layout.prop(zanatomy, "sync_text")

def register():
    # Désenregistrer les classes si déjà enregistrées
    for cls in (SYNCTEXT_PT_sync_text_panel, ZAnatomyDefProps):
        try:
            bpy.utils.unregister_class(cls)
        except:
            pass

    bpy.utils.register_class(ZAnatomyDefProps)
    bpy.utils.register_class(SYNCTEXT_PT_sync_text_panel)
    bpy.types.Scene.zanatomy_def = bpy.props.PointerProperty(type=ZAnatomyDefProps)

    # Nettoyage des anciennes souscriptions MsgBus
    try:
        bpy.msgbus.clear_by_owner(bpy.context.window_manager)
    except:
        pass

    # Souscription UNIQUEMENT aux changements d'objet actif (Vue 3D et Outliner)
    bpy.msgbus.subscribe_rna(
        key=(bpy.types.LayerObjects, "active"),
        owner=bpy.context.window_manager,
        args=(),
        notify=lambda *args: msgbus_callback() if bpy.context.scene.zanatomy_def.sync_text else None,
    )

    # Souscription aux changements de nom d'objet (pour Z-Translate)
    bpy.msgbus.subscribe_rna(
        key=(bpy.types.Object, "name"),
        owner=bpy.context.window_manager,
        args=(),
        notify=lambda *args: msgbus_callback() if bpy.context.scene.zanatomy_def.sync_text else None,
    )

    # Force la mise à jour de l'interface
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

def unregister():
    # Désenregistre les classes
    for cls in (ZAnatomyDefProps, SYNCTEXT_PT_sync_text_panel):
        try:
            bpy.utils.unregister_class(cls)
        except:
            pass

    if hasattr(bpy.types.Scene, "zanatomy_def"):
        del bpy.types.Scene.zanatomy_def

if __name__ == "__main__":
    register()