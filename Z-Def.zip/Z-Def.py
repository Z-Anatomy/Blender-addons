# This program is free software: you can redistribute it and/or modify
# it under the terms of the Creative Commons Attribution-ShareAlike 4.0 International License (CC-BY-SA 4.0).
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# For more information, please visit the official license page: [https://creativecommons.org/licenses/by-sa/4.0/](https://creativecommons.org/licenses/by-sa/4.0/)

bl_info = {
    "name": "Z-Def",
    "author": "Marcin Zieliński, Z-Anatomy (modifié pour Blender 4.5.0)",
    "description": "Synchronise automatiquement l'éditeur de texte avec l'objet actif dès que la checkbox est cochée. Prend en charge les suffixes .l, .r, .i, .s, .t, .j",
    "blender": (4, 5, 0),
    "version": (0, 1, 4),
    "location": "View3D > Sidebar > Z-Anatomy",
    "category": "Interface"
}

import bpy

SUFFIXES = ('.l', '.r', '.i', '.s', '.t', '.j')


def clean_name(name):
    """Nettoie le nom du datablock en retirant uniquement les suffixes Blender (.001, .002, etc.)."""
    if '.' in name:
        parts = name.rsplit('.', 1)
        if len(parts) == 2 and parts[1].isdigit():
            return parts[0]
    return name


def get_possible_text_names(ta2id_name):
    """Retourne une liste de noms de texte possibles à essayer, en tenant compte des suffixes .l, .r, .i, .s, .t, .j"""
    base_name = clean_name(ta2id_name)
    possible_names = []

    def add_unique(n):
        if n and n not in possible_names:
            possible_names.append(n)

    add_unique(base_name)

    if base_name.endswith(SUFFIXES):
        add_unique(base_name[:-2])

    for suffix in SUFFIXES:
        add_unique(base_name + suffix)

    return possible_names


def msgbus_callback(*args):
    """Callback pour synchroniser l'éditeur de texte UNIQUEMENT lors d'un changement d'objet actif."""
    try:
        if not bpy.context.scene.zanatomy_def.sync_text:
            return

        active_object = bpy.context.active_object
        if not active_object or not hasattr(active_object, "data"):
            print("Z-Def: Aucun objet actif ou objet sans data.")
            return

        ta2id_name = active_object.get("TA2ID", active_object.data.name)
        possible_names = get_possible_text_names(ta2id_name)
        found_text = None

        for name in possible_names:
            if name in bpy.data.texts:
                found_text = bpy.data.texts[name]
                break

        if not found_text:
            print(f"Z-Def: Aucun texte trouvé pour {possible_names}.")
            return

        text_editor_area = next((area for area in bpy.context.screen.areas if area.type == "TEXT_EDITOR"), None)
        if not text_editor_area:
            print("Z-Def: Aucun éditeur de texte ouvert.")
            return

        current_text = text_editor_area.spaces[0].text
        if current_text and current_text.name != found_text.name:
            text_editor_area.spaces[0].text = found_text
            text_editor_area.spaces[0].top = 0
            text_editor_area.spaces[0].text.select_set(0, 0, 0, 0)
            text_editor_area.tag_redraw()
            print(f"Z-Def: Synchronisation réussie pour '{found_text.name}'.")

    except Exception as e:
        print(f"Z-Def Error: {str(e)}")


class ZAnatomyDefProps(bpy.types.PropertyGroup):
    sync_text: bpy.props.BoolProperty(
        name="Sync Text Editor",
        description="Active la synchronisation automatique de l'éditeur de texte avec l'objet actif",
        default=True,
        update=lambda self, context: msgbus_callback() if self.sync_text else None
    )


class SYNCTEXT_PT_sync_text_panel(bpy.types.Panel):
    bl_label = "Show Definition"
    bl_idname = "VIEW3D_PT_sync_text"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Z-Anatomy'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        zanatomy = context.scene.zanatomy_def
        layout.prop(zanatomy, "sync_text")


def register():
    for cls in (SYNCTEXT_PT_sync_text_panel, ZAnatomyDefProps):
        try:
            bpy.utils.unregister_class(cls)
        except:
            pass

    bpy.utils.register_class(ZAnatomyDefProps)
    bpy.utils.register_class(SYNCTEXT_PT_sync_text_panel)
    bpy.types.Scene.zanatomy_def = bpy.props.PointerProperty(type=ZAnatomyDefProps)

    try:
        bpy.msgbus.clear_by_owner(bpy.context.window_manager)
    except:
        pass

    bpy.msgbus.subscribe_rna(
        key=(bpy.types.LayerObjects, "active"),
        owner=bpy.context.window_manager,
        args=(),
        notify=lambda *args: msgbus_callback() if bpy.context.scene.zanatomy_def.sync_text else None,
    )

    bpy.msgbus.subscribe_rna(
        key=(bpy.types.Object, "name"),
        owner=bpy.context.window_manager,
        args=(),
        notify=lambda *args: msgbus_callback() if bpy.context.scene.zanatomy_def.sync_text else None,
    )

    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


def unregister():
    for cls in (ZAnatomyDefProps, SYNCTEXT_PT_sync_text_panel):
        try:
            bpy.utils.unregister_class(cls)
        except:
            pass

    if hasattr(bpy.types.Scene, "zanatomy_def"):
        del bpy.types.Scene.zanatomy_def


if __name__ == "__main__":
    register()