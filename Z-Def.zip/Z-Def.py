# This program is free software: you can redistribute it and/or modify
# it under the terms of the Creative Commons Attribution-ShareAlike 4.0 International License (CC-BY-SA 4.0).
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# For more information, visit the official license page: https://creativecommons.org/licenses/by-sa/4.0/

bl_info = {
    "name": "Z-Def (Outliner Compatible)",
    "author": "Marcin Zieliński, Z-Anatomy (modifié pour Blender 4.5.0)",
    "description": "Synchronize the text editor with a .txt file matching the active object's data name. Works with Outliner selection.",
    "blender": (4, 5, 0),
    "version": (0, 0, 3),
    "location": "View3D > Sidebar > Sync Text",
    "category": "Interface"
}

import bpy
import os

def clean_name(name):
    """Nettoie le nom du datablock pour correspondre au nom du texte."""
    return os.path.splitext(name)[0]

def msgbus_callback(*args):
    """Callback pour synchroniser l'éditeur de texte avec l'objet actif."""
    active_object = bpy.context.active_object
    if not active_object or not active_object.data:
        return

    # Récupère le nom du datablock (maillage, courbe, etc.)
    basename = clean_name(active_object.data.name)

    # Cherche un éditeur de texte ouvert
    text_editor_area = None
    for area in bpy.context.screen.areas:
        if area.type == "TEXT_EDITOR":
            text_editor_area = area
            break

    # Si un éditeur de texte est trouvé et que le texte existe, affiche-le
    if text_editor_area and basename in bpy.data.texts:
        text_editor_area.spaces[0].text = bpy.data.texts[basename]
        text_editor_area.spaces[0].top = 0
        text_editor_area.spaces[0].text.select_set(0, 0, 0, 0)

def scene_update_handler(scene):
    """Handler pour déclencher le callback à chaque changement de sélection."""
    if bpy.context.scene.zanatomy_def.sync_text:
        msgbus_callback()

class ZAnatomyDefProps(bpy.types.PropertyGroup):
    sync_text: bpy.props.BoolProperty(
        name="Sync Text Editor",
        description="Toggle the synchronization of the text editor with the active object's data name",
        default=True,
        update=lambda self, context: msgbus_callback() if self.sync_text else None
    )

class SYNCTEXT_PT_sync_text_panel(bpy.types.Panel):
    bl_label = "Show Definition"
    bl_idname = "VIEW3D_PT_sync_text"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Z-Anatomy'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        zanatomy = context.scene.zanatomy_def
        layout.prop(zanatomy, "sync_text")

def register():
    bpy.utils.register_class(ZAnatomyDefProps)
    bpy.utils.register_class(SYNCTEXT_PT_sync_text_panel)
    bpy.types.Scene.zanatomy_def = bpy.props.PointerProperty(type=ZAnatomyDefProps)

    # Efface les anciennes souscriptions msgbus
    bpy.msgbus.clear_by_owner(bpy.context.window_manager)

    # Souscription aux changements d'objet actif (pour la vue 3D et l'Outliner)
    bpy.msgbus.subscribe_rna(
        key=(bpy.types.LayerObjects, 'active'),
        owner=bpy.context.window_manager,
        args=(),
        notify=lambda: msgbus_callback() if bpy.context.scene.zanatomy_def.sync_text else None,
    )

    # Ajoute un handler pour plus de fiabilité
    bpy.app.handlers.depsgraph_update_post.append(scene_update_handler)

    # Force la mise à jour de l'interface
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

def unregister():
    # Retire le handler
    if scene_update_handler in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(scene_update_handler)

    # Nettoie les souscriptions msgbus
    bpy.msgbus.clear_by_owner(bpy.context.window_manager)

    # Désenregistre les classes
    bpy.utils.unregister_class(ZAnatomyDefProps)
    bpy.utils.unregister_class(SYNCTEXT_PT_sync_text_panel)
    del bpy.types.Scene.zanatomy_def

if __name__ == "__main__":
    register()
