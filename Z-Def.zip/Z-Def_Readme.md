# Z-Def Add-on for Blender

## Description

Z-Def is a Blender add-on that synchronizes the text editor with a `.txt` file matching the active object's data name.

## Features

- Automatically syncs the text editor with the active object.
- Displays the corresponding `.txt` file if available in Blender.
- Enables/disables synchronization via a dedicated panel.

## Installation

1. Download the `.zip` file of the add-on.
2. Open Blender and go to `Edit` > `Preferences`.
3. Select the `Add-ons` tab and click the downward-facing arrow in the top-right corner.
4. Choose `Install from Disk` and select the downloaded `.zip` file.
5. Enable the add-on by checking the box next to "Z-Label".

## Usage

### Text Editor Synchronization

1. Enable the **Sync Text Editor** option in the **N** panel under the **Z-Anatomy** tab.
2. When selecting an object, the text editor will automatically display the `.txt` file matching its data name.
3. If no corresponding file exists, no text will be displayed.

## Author

- **Marcin Zieliński**
- **Z-Anatomy**

## Compatibility

- Blender 2.80 and later versions.

## License

This add-on is distributed under the [CC-BY-SA 4.0](LICENSE) license, which allows sharing and adaptation with attribution and under the same terms.