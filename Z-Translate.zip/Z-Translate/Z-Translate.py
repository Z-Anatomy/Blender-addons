# This program is free software: you can redistribute it and/or modify
# it under the terms of the Creative Commons Attribution-ShareAlike 4.0 International License (CC-BY-SA 4.0).
# 
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# For more information, visit the official license page: https://creativecommons.org/licenses/by-sa/4.0/

bl_info = {
    "name": "Z-Translate",
    "author": "Marcin Zieliński, Z-Anatomy",
    "description": "Tools to translate objects using a list of translations.",
    "blender": (2, 80, 0),
    "version": (0, 0, 1),
    "location": "",
    "warning": "",
    "category": "Interface"
}

import bpy
import re

fonts = {
    'English': 'Bfont',
    'TA2ID': 'Bfont',
}

def clean_name(name):
    suffixes = ['.r', '.l', '.t', '.j', '.o', '.e', '.i']
    for suffix in suffixes:
        if suffix in name:
            base_name = name.split(suffix)[0]
            ending = suffix + name.split(suffix)[1]
            return base_name, ending
    return name, ''

def first_n_bytes(string, n=63):
    byte_length = 0
    out = ''
    for char in string:
        byte_length += len(char.encode())
        if byte_length <= n:
            out += char
        else:
            return out
    return out

class OBJECT_OT_translate_atlas(bpy.types.Operator):
    bl_idname = "object.translate_atlas"
    bl_label = "Translate"
    bl_options = {'REGISTER', 'UNDO'}

    lang: bpy.props.EnumProperty(items=[
        ('TA2ID', 'TA2ID', '', 0),
        ('English', 'English', '', 1),
        ],
        default='TA2ID',
        name="Language")

    def execute(self, context):
        if self.lang == "TA2ID":
            for ob in bpy.data.objects[:]:
                if ob.type == "MESH":
                    base_name, ending = clean_name(ob.name)
                    ta2id_name, _ = clean_name(ob.data.name)
                    ob.name = ta2id_name + ending
                elif ob.type == "CURVE":
                    base_name, ending = clean_name(ob.name)
                    ta2id_name, _ = clean_name(ob.data.name)
                    ob.name = ta2id_name + ending
                elif ob.type == "FONT":
                    ob.name = ob.data.name
                    ob.data.body = clean_name(ob.data.name)[0].upper()
                    ob.data.font = bpy.data.fonts['Bfont']
                    if not ob.name.endswith('.st'):
                        ob.data.size = 0.003

            for col in bpy.data.collections[:]:
                if 'TA2ID' in col.keys():
                    col.name = col['English']
            return {"FINISHED"}

        translations = bpy.data.texts['Translations'].as_string().splitlines()
        languages = translations[0].split(';')
        trans_dict = dict()
        for langs in translations[1:]:
            langs = list(zip(languages, langs.split(';')))
            translated_phrase = trans_dict[langs[0][1]] = dict()
            for lang in langs[1:]:
                translated_phrase[lang[0]] = lang[1]

        for ob in bpy.data.objects[:]:
            if ob.type == "MESH":
                base_name, ending = clean_name(ob.name)
                ta2id_name, _ = clean_name(ob.data.name)
                if ta2id_name in trans_dict:
                    new_name = trans_dict[ta2id_name][self.lang]
                    new_name = first_n_bytes(new_name)
                    ob.name = new_name + ending
            elif ob.type == "FONT":
                base_name, ending = clean_name(ob.name)
                ta2id_name, _ = clean_name(ob.data.name)
                if ta2id_name in trans_dict:
                    new_name = trans_dict[ta2id_name][self.lang]
                    ob.data.body = new_name.upper()

                    new_name = first_n_bytes(new_name)
                    ob.name = new_name + ending

                    try:
                        ob.data.font = bpy.data.fonts[fonts[self.lang]]
                    except:
                        self.report(type={"WARNING"}, message=f"Font {fonts[self.lang]} not found. Add it manually.")

                    if not ob.name.endswith('.st'):
                        ob.data.size = 0.003
            elif ob.type == "CURVE":
                base_name, ending = clean_name(ob.name)
                ta2id_name, _ = clean_name(ob.data.name)
                if ta2id_name in trans_dict:
                    new_name = trans_dict[ta2id_name][self.lang]
                    new_name = first_n_bytes(new_name)
                    ob.name = new_name + ending

        for col in bpy.data.collections[:]:
            if 'TA2ID' in col.keys():
                ta2id_name = col['English']
                if ta2id_name.endswith("'"):
                    ta2id_name = ta2id_name[:-1]
                    if ta2id_name in trans_dict:
                        col.name = trans_dict[ta2id_name][self.lang] + "'"
                elif ta2id_name in trans_dict:
                    col.name = trans_dict[ta2id_name][self.lang]

        return {"FINISHED"}

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

class ZANATOMY_PT_translate_panel(bpy.types.Panel):
    bl_label = "Translate"
    bl_idname = "VIEW3D_PT_z_translate_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Z-Anatomy'

    def draw(self, context):
        layout = self.layout
        layout.operator("object.translate_atlas")

def register():
    bpy.utils.register_class(OBJECT_OT_translate_atlas)
    bpy.utils.register_class(ZANATOMY_PT_translate_panel)

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_translate_atlas)
    bpy.utils.unregister_class(ZANATOMY_PT_translate_panel)

if __name__ == "__main__":
    register()
