# Z-Translate Add-on for Blender

## Description

Z-Translate is a Blender add-on designed to facilitate the translation of objects using a predefined list of translations. It allows users to switch between different languages for object names and text data within Blender projects, enhancing multilingual workflows.

## Features

- Translate object names and text data based on a list of translations.
- Additional languages can be added and a custom translation dictionarie can be imported.
- Automatically updates object names and text data according to the selected language.
- Provides a user-friendly interface for easy language switching.

## Installation

1. Download the `.zip` file of the add-on.
2. Open Blender and go to `Edit` > `Preferences`.
3. Select the `Add-ons` tab and click the downward-facing arrow in the top-right corner.
4. Choose `Install from Disk` and select the downloaded `.zip` file.
5. Enable the add-on by checking the box next to "Z-Translate".

## Usage

### Translating Objects

1. Ensure you have a text file named "Translations" in Blender's text editor with your translation data.
2. Use the "Translate" operator to apply translations to your objects.
3. Select the desired language from the provided options.
4. The name of the content (mesh, curve) should correspond to the first term of one the lines of the Translations.txt file

### Panel

The add-on includes a panel in the 3D View UI under the "Z-Anatomy" category, providing easy access to the translation tools.

## Author

- **Marcin Zieliński**
- **Z-Anatomy**

## Compatibility

- Blender 2.80 and later versions.

## License

This add-on is distributed under the [CC-BY-SA 4.0](LICENSE) license, which allows sharing and adaptation with attribution and under the same terms.
