# This program is free software: you can redistribute it and/or modify
# it under the terms of the Creative Commons Attribution-ShareAlike 4.0 International License (CC-BY-SA 4.0).
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# For more information, visit the official license page: https://creativecommons.org/licenses/by-sa/4.0/
bl_info = {
    "name": "Z-Translate",
    "authors": "Marcin Zieliński, Gauthier Kervyn",
    "description": "Tools to translate objects using a list of translations. Stores TA2ID as a custom property for Z-Def compatibility.",
    "blender": (4, 5, 0),
    "version": (0, 0, 19),
    "location": "View3D > Sidebar > Z-Anatomy",
    "warning": "",
    "category": "Interface"
}
import bpy
import re
from collections import defaultdict

# Police par défaut pour toutes les langues
fonts = {
    'TA2ID': 'Bfont',
    'NAVID': 'Bfont',
    'English': 'Bfont',
    'Latin': 'Bfont',
    'Français': 'Bfont',
    'Español': 'Bfont',
    'Portugues': 'Bfont',
    'Polski': 'Bfont',
    'Parsi': 'Bfont',
}

def clean_name(name):
    suffixes = ['.r', '.l', '.t', '.j', '.o', '.e', '.i']
    for suffix in suffixes:
        if suffix in name:
            parts = name.split(suffix, 1)
            base_name = parts[0]
            ending = suffix + parts[1]
            return base_name, ending
    return name, ''

def first_n_bytes(string, n=63):
    byte_length = 0
    out = ''
    for char in string:
        byte_length += len(char.encode('utf-8', errors='replace'))
        if byte_length <= n:
            out += char
        else:
            return out
    return out

def decode_text_safely(text_block):
    encodings = ['utf-8', 'latin1', 'windows-1252', 'iso-8859-1']
    for encoding in encodings:
        try:
            return text_block.as_string().encode(encoding).decode('utf-8', errors='replace')
        except UnicodeError:
            continue
    return text_block.as_string()

def get_available_languages(self, context):
    translations_text = bpy.data.texts.get('0.Translations')
    if not translations_text:
        return [
            ('TA2ID', 'TA2ID', '', 0),
            ('NAVID', 'NAVID', '', 1),
            ('English', 'English', '', 2),
            ('Latin', 'Latin', '', 3),
            ('Français', 'Français', '', 4),
            ('Español', 'Español', '', 5),
            ('Portugues', 'Portugues', '', 6),
            ('Polski', 'Polski', '', 7),
            ('Parsi', 'Parsi', '', 8),
        ]
    try:
        first_line = decode_text_safely(translations_text).splitlines()[0]
        first_line = first_line.strip()
        languages = [lang.strip() for lang in first_line.split(';') if lang.strip()]
    except Exception as e:
        print(f"Erreur de lecture des langues : {e}")
        return [
            ('TA2ID', 'TA2ID', '', 0),
            ('NAVID', 'NAVID', '', 1),
            ('English', 'English', '', 2),
            ('Latin', 'Latin', '', 3),
            ('Français', 'Français', '', 4),
            ('Español', 'Español', '', 5),
            ('Portugues', 'Portugues', '', 6),
            ('Polski', 'Polski', '', 7),
            ('Parsi', 'Parsi', '', 8),
        ]
    all_languages = [
        ('TA2ID', 'TA2ID', '', 0),
        ('NAVID', 'NAVID', '', 1),
        ('English', 'English', '', 2),
        ('Latin', 'Latin', '', 3),
        ('Français', 'Français', '', 4),
        ('Español', 'Español', '', 5),
        ('Portugues', 'Portugues', '', 6),
        ('Polski', 'Polski', '', 7),
        ('Parsi', 'Parsi', '', 8),
    ]
    available_languages = []
    for lang in all_languages:
        if lang[0] in languages:
            available_languages.append(lang)
    return available_languages

class OBJECT_OT_translate_atlas(bpy.types.Operator):
    bl_idname = "object.translate_atlas"
    bl_label = "Translate All"
    bl_description = "Translate both objects and collections to selected language"
    bl_options = {'REGISTER', 'UNDO'}
    lang: bpy.props.EnumProperty(
        items=get_available_languages,
        name="Language"
    )
    
    def execute(self, context):
        translations_text = bpy.data.texts.get('0.Translations')
        if not translations_text:
            self.report(type={"ERROR"}, message="Le fichier '0.Translations' est introuvable.")
            return {"CANCELLED"}
            
        # Purge des propriétés personnalisées des collections
        for col in bpy.data.collections:
            for key in list(col.keys()):
                if key not in {'_RNA_UI'}:
                    del col[key]
                    
        if self.lang in ["TA2ID", "NAVID"]:
            self._translate_to_ta2id_navid()
            return {"FINISHED"}
            
        try:
            translations = decode_text_safely(translations_text).splitlines()
        except Exception as e:
            self.report(type={"ERROR"}, message=f"Erreur de lecture du fichier : {str(e)}")
            return {"CANCELLED"}
            
        languages = translations[0].split(';')
        trans_dict = {}
        for line in translations[1:]:
            if not line.strip():
                continue
            values = line.split(';')
            if len(values) != len(languages):
                continue
            key = values[0]
            trans_dict[key] = dict(zip(languages[1:], values[1:]))
            
        # OPTIMISATION: Créer un mapping collection -> TA2ID en une seule passe
        collection_ta2id_map = self._build_collection_ta2id_map()
        
        # Traduire les objets
        self._translate_objects(trans_dict)
        
        # Traduire les collections
        self._translate_collections(trans_dict, collection_ta2id_map)
        
        return {"FINISHED"}
    
    def _translate_to_ta2id_navid(self):
        """Traduction optimisée pour TA2ID/NAVID"""
        # Traiter tous les objets en une seule passe
        for ob in bpy.data.objects:
            if ob.type in {"MESH", "CURVE"}:
                base_name, ending = clean_name(ob.name)
                ta2id_name, _ = clean_name(ob.data.name)
                ob.name = ta2id_name + ending
                ob["TA2ID"] = ta2id_name
            elif ob.type == "FONT":
                ob.name = ob.data.name
                ob["TA2ID"] = ob.data.name
                ob.data.body = clean_name(ob.data.name)[0].upper()
                ob.data.font = bpy.data.fonts.get('Bfont')
                if not ob.name.endswith('.st'):
                    ob.data.size = 0.003
        
        # OPTIMISATION: Construire le mapping collection -> TA2ID une seule fois
        collection_ta2id_map = self._build_collection_ta2id_map()
        
        # Appliquer les noms TA2ID aux collections
        for col, ta2id_name in collection_ta2id_map.items():
            if ta2id_name:
                col.name = ta2id_name
    
    def _build_collection_ta2id_map(self):
        """Construit un mapping collection -> TA2ID optimisé"""
        collection_ta2id_map = {}
        
        # Pré-calculer les TA2ID pour chaque collection
        for col in bpy.data.collections:
            ta2id_name = None
            # Prendre le premier objet valide trouvé
            for ob in col.objects:
                if ob.get("TA2ID"):
                    ta2id_name = ob["TA2ID"]
                    break
                elif ob.type in {"MESH", "CURVE"}:
                    # Extraire le TA2ID du nom du mesh/data
                    ta2id_name, _ = clean_name(ob.data.name)
                    break
                elif ob.type == "FONT":
                    ta2id_name = ob.data.name
                    break
            
            collection_ta2id_map[col] = ta2id_name
        
        return collection_ta2id_map
    
    def _translate_objects(self, trans_dict):
        """Traduire tous les objets optimisé"""
        for ob in bpy.data.objects:
            if ob.type not in {"MESH", "FONT", "CURVE"}:
                continue
                
            base_name, ending = clean_name(ob.name)
            
            # Déterminer le TA2ID selon le type d'objet
            if ob.type in {"MESH", "CURVE"}:
                ta2id_name, _ = clean_name(ob.data.name)
            else:  # FONT
                ta2id_name, _ = clean_name(ob.data.name)
            
            if ta2id_name in trans_dict and self.lang in trans_dict[ta2id_name]:
                new_name = trans_dict[ta2id_name][self.lang]
                new_name = first_n_bytes(new_name)
                ob.name = new_name + ending
                ob["TA2ID"] = ta2id_name  # Toujours stocker le TA2ID
                
                # Traitement spécifique aux textes
                if ob.type == "FONT":
                    ob.data.body = new_name.upper()
                    try:
                        ob.data.font = bpy.data.fonts[fonts[self.lang]]
                    except:
                        pass  # Font warning déjà géré ailleurs
                    if not ob.name.endswith('.st'):
                        ob.data.size = 0.003
    
    def _translate_collections(self, trans_dict, collection_ta2id_map):
        """Traduire les collections avec le mapping pré-calculé"""
        collections_translated = 0
        
        for col, ta2id_name in collection_ta2id_map.items():
            if not ta2id_name:
                continue
                
            # CORRECTION : Gérer l'apostrophe dans le nom original
            has_apostrophe = ta2id_name.endswith("'")
            clean_ta2id = ta2id_name.rstrip("'") if has_apostrophe else ta2id_name
            
            if clean_ta2id in trans_dict and self.lang in trans_dict[clean_ta2id]:
                new_name = trans_dict[clean_ta2id][self.lang]
                # Réappliquer l'apostrophe si elle était présente dans le TA2ID original
                if has_apostrophe:
                    col.name = new_name + "'"
                else:
                    col.name = new_name
                collections_translated += 1
    
    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

class OBJECT_OT_translate_collections_only(bpy.types.Operator):
    bl_idname = "object.translate_collections_only"
    bl_label = "Translate Collections Only"
    bl_description = "Translate only collection names to selected language"
    bl_options = {'REGISTER', 'UNDO'}
    
    lang: bpy.props.EnumProperty(
        items=get_available_languages,
        name="Language"
    )
    
    def execute(self, context):
        translations_text = bpy.data.texts.get('0.Translations')
        if not translations_text:
            self.report(type={"ERROR"}, message="Le fichier '0.Translations' est introuvable.")
            return {"CANCELLED"}
            
        if self.lang in ["TA2ID", "NAVID"]:
            self._reset_collections_to_ta2id()
            return {"FINISHED"}
            
        try:
            translations = decode_text_safely(translations_text).splitlines()
        except Exception as e:
            self.report(type={"ERROR"}, message=f"Erreur de lecture du fichier : {str(e)}")
            return {"CANCELLED"}
            
        languages = translations[0].split(';')
        trans_dict = {}
        for line in translations[1:]:
            if not line.strip():
                continue
            values = line.split(';')
            if len(values) != len(languages):
                continue
            key = values[0]
            trans_dict[key] = dict(zip(languages[1:], values[1:]))
        
        # Construire le mapping collection -> TA2ID
        collection_ta2id_map = self._build_collection_ta2id_map()
        
        # Traduire seulement les collections
        self._translate_collections_only(trans_dict, collection_ta2id_map)
        
        return {"FINISHED"}
    
    def _build_collection_ta2id_map(self):
        """Construit un mapping collection -> TA2ID optimisé"""
        collection_ta2id_map = {}
        
        for col in bpy.data.collections:
            ta2id_name = None
            # Prendre le premier objet valide trouvé
            for ob in col.objects:
                if ob.get("TA2ID"):
                    ta2id_name = ob["TA2ID"]
                    break
                elif ob.type in {"MESH", "CURVE"}:
                    # Extraire le TA2ID du nom du mesh/data
                    ta2id_name, _ = clean_name(ob.data.name)
                    break
                elif ob.type == "FONT":
                    ta2id_name = ob.data.name
                    break
            
            collection_ta2id_map[col] = ta2id_name
        
        return collection_ta2id_map
    
    def _translate_collections_only(self, trans_dict, collection_ta2id_map):
        """Traduire seulement les collections"""
        collections_translated = 0
        
        for col, ta2id_name in collection_ta2id_map.items():
            if not ta2id_name:
                continue
                
            # CORRECTION : Gérer l'apostrophe dans le nom original
            has_apostrophe = ta2id_name.endswith("'")
            clean_ta2id = ta2id_name.rstrip("'") if has_apostrophe else ta2id_name
            
            if clean_ta2id in trans_dict and self.lang in trans_dict[clean_ta2id]:
                new_name = trans_dict[clean_ta2id][self.lang]
                # Réappliquer l'apostrophe si elle était présente dans le TA2ID original
                if has_apostrophe:
                    col.name = new_name + "'"
                else:
                    col.name = new_name
                collections_translated += 1
        
        self.report(type={"INFO"}, message=f"{collections_translated} collections translated to {self.lang}")
    
    def _reset_collections_to_ta2id(self):
        """Reset des collections vers TA2ID/NAVID"""
        collection_ta2id_map = self._build_collection_ta2id_map()
        collections_reset = 0
        
        for col, ta2id_name in collection_ta2id_map.items():
            if ta2id_name:
                col.name = ta2id_name
                collections_reset += 1
        
        self.report(type={"INFO"}, message=f"{collections_reset} collections reset to {self.lang}")
    
    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

class ZANATOMY_PT_translate_panel(bpy.types.Panel):
    bl_label = "Translate"
    bl_idname = "VIEW3D_PT_z_translate_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Z-Anatomy'
    def draw(self, context):
        layout = self.layout
        layout.operator("object.translate_atlas")
        layout.operator("object.translate_collections_only")

classes = (
    OBJECT_OT_translate_atlas,
    OBJECT_OT_translate_collections_only,
    ZANATOMY_PT_translate_panel,
)

def register():
    for cls in classes:
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass

if __name__ == "__main__":
    register()