# This program is free software: you can redistribute it and/or modify
# it under the terms of the Creative Commons Attribution-ShareAlike 4.0 International License (CC-BY-SA 4.0).
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# For more information, visit the official license page: https://creativecommons.org/licenses/by-sa/4.0/

bl_info = {
    "name": "Z-Translate",
    "author": "Marcin Zieliński, Z-Anatomy",
    "description": "Tools to translate objects using a list of translations.",
    "blender": (2, 80, 0),
    "version": (0, 0, 17),
    "location": "View3D > Sidebar > Z-Anatomy",
    "warning": "",
    "category": "Interface"
}

import bpy
import re

# Police par défaut pour toutes les langues
fonts = {
    'TA2ID': 'Bfont',
    'NAVID': 'Bfont',
    'English': 'Bfont',
    'Latin': 'Bfont',
    'Français': 'Bfont',
    'Español': 'Bfont',
    'Portugues': 'Bfont',
    'Polski': 'Bfont',
    'Parsi': 'Bfont',
}

def clean_name(name):
    # Définition des suffixes à considérer
    suffixes = ['.r', '.l', '.t', '.j', '.o', '.e', '.i']
    for suffix in suffixes:
        if suffix in name:
            # Séparation du nom au premier suffixe rencontré
            parts = name.split(suffix, 1)
            base_name = parts[0]
            ending = suffix + parts[1]
            return base_name, ending
    return name, ''

def first_n_bytes(string, n=63):
    byte_length = 0
    out = ''
    for char in string:
        byte_length += len(char.encode('utf-8', errors='replace'))
        if byte_length <= n:
            out += char
        else:
            return out
    return out

def decode_text_safely(text_block):
    """Essaie de lire le texte avec plusieurs encodages."""
    encodings = ['utf-8', 'latin1', 'windows-1252', 'iso-8859-1']
    for encoding in encodings:
        try:
            return text_block.as_string().encode(encoding).decode('utf-8', errors='replace')
        except UnicodeError:
            continue
    return text_block.as_string()

def get_available_languages(self, context):
    """Récupère les langues disponibles depuis le fichier Translations."""
    translations_text = bpy.data.texts.get('Translations')
    if not translations_text:
        return [
            ('TA2ID', 'TA2ID', '', 0),
            ('NAVID', 'NAVID', '', 1),
            ('English', 'English', '', 2),
            ('Latin', 'Latin', '', 3),
            ('Français', 'Français', '', 4),
            ('Español', 'Español', '', 5),
            ('Portugues', 'Portugues', '', 6),
            ('Polski', 'Polski', '', 7),
            ('Parsi', 'Parsi', '', 8),
        ]

    try:
        first_line = decode_text_safely(translations_text).splitlines()[0]
        first_line = first_line.strip()
        languages = [lang.strip() for lang in first_line.split(';') if lang.strip()]
    except Exception as e:
        print(f"Erreur de lecture des langues : {e}")
        return [
            ('TA2ID', 'TA2ID', '', 0),
            ('NAVID', 'NAVID', '', 1),
            ('English', 'English', '', 2),
            ('Latin', 'Latin', '', 3),
            ('Français', 'Français', '', 4),
            ('Español', 'Español', '', 5),
            ('Portugues', 'Portugues', '', 6),
            ('Polski', 'Polski', '', 7),
            ('Parsi', 'Parsi', '', 8),
        ]

    # Filtre les langues disponibles
    all_languages = [
        ('TA2ID', 'TA2ID', '', 0),
        ('NAVID', 'NAVID', '', 1),
        ('English', 'English', '', 2),
        ('Latin', 'Latin', '', 3),
        ('Français', 'Français', '', 4),
        ('Español', 'Español', '', 5),
        ('Portugues', 'Portugues', '', 6),
        ('Polski', 'Polski', '', 7),
        ('Parsi', 'Parsi', '', 8),
    ]

    available_languages = []
    for lang in all_languages:
        if lang[0] in languages:
            available_languages.append(lang)

    return available_languages

class OBJECT_OT_translate_atlas(bpy.types.Operator):
    bl_idname = "object.translate_atlas"
    bl_label = "Translate"
    bl_options = {'REGISTER', 'UNDO'}

    lang: bpy.props.EnumProperty(
        items=get_available_languages,
        name="Language"
    )

    def execute(self, context):
        translations_text = bpy.data.texts.get('Translations')
        if not translations_text:
            self.report(type={"ERROR"}, message="Le fichier 'Translations' est introuvable.")
            return {"CANCELLED"}

        if self.lang in ["TA2ID", "NAVID"]:
            for ob in bpy.data.objects:
                if ob.type == "MESH":
                    base_name, ending = clean_name(ob.name)
                    ta2id_name, _ = clean_name(ob.data.name)
                    ob.name = ta2id_name + ending
                elif ob.type == "CURVE":
                    base_name, ending = clean_name(ob.name)
                    ta2id_name, _ = clean_name(ob.data.name)
                    ob.name = ta2id_name + ending
                elif ob.type == "FONT":
                    ob.name = ob.data.name
                    ob.data.body = clean_name(ob.data.name)[0].upper()
                    ob.data.font = bpy.data.fonts.get('Bfont')
                    if not ob.name.endswith('.st'):
                        ob.data.size = 0.003

            for col in bpy.data.collections:
                if 'English' in col:
                    col.name = col.get('English', col.name)
            return {"FINISHED"}

        try:
            translations = decode_text_safely(translations_text).splitlines()
        except Exception as e:
            self.report(type={"ERROR"}, message=f"Erreur de lecture du fichier : {str(e)}")
            return {"CANCELLED"}

        languages = translations[0].split(';')
        trans_dict = {}

        for line in translations[1:]:
            if not line.strip():
                continue
            values = line.split(';')
            if len(values) != len(languages):
                continue
            key = values[0]
            trans_dict[key] = dict(zip(languages[1:], values[1:]))

        for ob in bpy.data.objects:
            if ob.type == "MESH":
                base_name, ending = clean_name(ob.name)
                ta2id_name, _ = clean_name(ob.data.name)
                if ta2id_name in trans_dict and self.lang in trans_dict[ta2id_name]:
                    new_name = trans_dict[ta2id_name][self.lang]
                    new_name = first_n_bytes(new_name)
                    ob.name = new_name + ending
            elif ob.type == "FONT":
                base_name, ending = clean_name(ob.name)
                ta2id_name, _ = clean_name(ob.data.name)
                if ta2id_name in trans_dict and self.lang in trans_dict[ta2id_name]:
                    new_name = trans_dict[ta2id_name][self.lang]
                    ob.data.body = new_name.upper()
                    new_name = first_n_bytes(new_name)
                    ob.name = new_name + ending
                    try:
                        ob.data.font = bpy.data.fonts[fonts[self.lang]]
                    except:
                        self.report(type={"WARNING"}, message=f"Font {fonts[self.lang]} not found. Add it manually.")
                    if not ob.name.endswith('.st'):
                        ob.data.size = 0.003
            elif ob.type == "CURVE":
                base_name, ending = clean_name(ob.name)
                ta2id_name, _ = clean_name(ob.data.name)
                if ta2id_name in trans_dict and self.lang in trans_dict[ta2id_name]:
                    new_name = trans_dict[ta2id_name][self.lang]
                    new_name = first_n_bytes(new_name)
                    ob.name = new_name + ending

        for col in bpy.data.collections:
            if 'English' in col:
                ta2id_name = col.get('English', '')
                if ta2id_name.endswith("'"):
                    ta2id_name = ta2id_name[:-1]
                    if ta2id_name in trans_dict and self.lang in trans_dict[ta2id_name]:
                        col.name = trans_dict[ta2id_name][self.lang] + "'"
                elif ta2id_name in trans_dict and self.lang in trans_dict[ta2id_name]:
                    col.name = trans_dict[ta2id_name][self.lang]

        return {"FINISHED"}

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

class ZANATOMY_PT_translate_panel(bpy.types.Panel):
    bl_label = "Translate"
    bl_idname = "VIEW3D_PT_z_translate_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Z-Anatomy'

    def draw(self, context):
        layout = self.layout
        layout.operator("object.translate_atlas")

classes = (
    OBJECT_OT_translate_atlas,
    ZANATOMY_PT_translate_panel,
)

def register():
    for cls in classes:
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass

if __name__ == "__main__":
    register()
