bl_info = {
    "name": "Z-Translate (Final)",
    "authors": "Marcin Zielinski, Gauthier Kervyn",
    "description": "Translate objects (based on mesh names) and collections (based on 'NAVID' custom property).",
    "blender": (4, 5, 0),
    "version": (1, 5, 0),
    "location": "View3D > Sidebar > Z-Anatomy",
    "warning": "",
    "category": "Interface"
}

import bpy
import re

# Cache global pour les traductions
_translations_cache = None
_last_modified_hash = None

def clean_name(name):
    """
    Sépare le nom de base et le suffixe :
    - .l / .r
    - .i, .j, .s, .t, .o, .e
    - .ol / .or / .el / .er
    - variantes avec chiffres : .o12r, .e3l, .i4, .j5, .s2, .t3, etc.
    """
    # Pattern pour capturer tous les suffixes possibles
    # Groupes: 1 = suffixe complet
    pattern = r'(\.(?:[lLrR]|[oOeEiIjJsStT](?:[0-9]*[lLrR])?|[oOeEiIjJsStT][0-9]*|[sS][0-9]*))$'

    match = re.search(pattern, name)
    if match:
        suffix = match.group(1)
        base = name[:match.start(1)]
        return base, suffix

    return name, ''

def is_rl_suffix(suffix):
    """Vérifie si le suffixe contient .r ou .l"""
    return bool(re.search(r'[lLrR]', suffix))

def first_n_bytes(string, n=63):
    """Tronque une chaîne à n bytes UTF-8"""
    encoded = string.encode('utf-8', errors='replace')
    if len(encoded) <= n:
        return string
    return encoded[:n].decode('utf-8', errors='replace')

def decode_text_safely(text_block):
    """Décode un bloc de texte en essayant plusieurs encodages"""
    encodings = ['utf-8', 'latin1', 'windows-1252', 'iso-8859-1']
    for encoding in encodings:
        try:
            return text_block.as_string().encode(encoding).decode('utf-8', errors='replace')
        except UnicodeError:
            continue
    return text_block.as_string()

def get_translations():
    """Charge et met en cache les traductions depuis '0.Translations'"""
    global _translations_cache, _last_modified_hash
    translations_text = bpy.data.texts.get('0.Translations')
    if not translations_text:
        return None, []

    current_hash = hash(translations_text.as_string())
    if _translations_cache is not None and current_hash == _last_modified_hash:
        return _translations_cache

    try:
        content = decode_text_safely(translations_text)
        lines = content.splitlines()
        if not lines:
            return None, []

        languages = [lang.strip() for lang in lines[0].split(';') if lang.strip()]
        trans_dict = {}

        for line in lines[1:]:
            if not line.strip():
                continue
            values = line.split(';')
            if len(values) == len(languages):
                key = values[0]
                trans_dict[key] = dict(zip(languages[1:], values[1:]))

        _translations_cache = trans_dict, languages
        _last_modified_hash = current_hash
        return trans_dict, languages

    except Exception as e:
        print(f"Erreur de lecture: {e}")
        return None, []

def get_available_languages(self, context):
    """Récupère dynamiquement les langues disponibles depuis '0.Translations'"""
    trans_dict, languages = get_translations() or ({}, [])
    available = [('NAVID', 'NAVID', '', 0)]

    for i, lang in enumerate(languages[1:], start=1):
        available.append((lang, lang, '', i))

    return available

class OBJECT_OT_translate_atlas(bpy.types.Operator):
    bl_idname = "object.translate_atlas"
    bl_label = "Translate All"
    bl_description = "Translate objects (based on mesh names) and collections (based on 'NAVID' custom property)"
    bl_options = {'REGISTER', 'UNDO'}

    lang: bpy.props.EnumProperty(
        items=get_available_languages,
        name="Language"
    )

    def execute(self, context):

        if self.lang == "NAVID":
            self._reset_to_navid()
            return {"FINISHED"}

        trans_dict, _ = get_translations() or ({}, [])
        if not trans_dict:
            self.report({"ERROR"}, "Translation file not found or invalid.")
            return {"CANCELLED"}

        bpy.context.preferences.edit.use_global_undo = False
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=0)

        objects_translated = self._translate_objects(trans_dict)
        collections_translated = self._translate_collections(trans_dict)

        bpy.context.preferences.edit.use_global_undo = True
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)

        self.report(
            {"INFO"},
            f"Translated {objects_translated} objects and {collections_translated} collections to {self.lang}"
        )
        return {"FINISHED"}

    def _reset_to_navid(self):
        objects_processed = 0
        collections_processed = 0

        bpy.context.preferences.edit.use_global_undo = False
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=0)

        for ob in bpy.data.objects:
            if ob.type in {"MESH", "CURVE", "FONT"}:
                ob.name = ob.data.name
                if ob.type == "FONT":
                    ob.data.body = ob.data.name.upper()
                objects_processed += 1

        for col in bpy.data.collections:
            if "NAVID" in col:
                col.name = col["NAVID"]
                collections_processed += 1

        bpy.context.preferences.edit.use_global_undo = True
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)

        self.report(
            {"INFO"},
            f"Reset {objects_processed} objects and {collections_processed} collections to NAVID"
        )

    def _translate_objects(self, trans_dict):
        objects_translated = 0

        for ob in bpy.data.objects:
            if ob.type not in {"MESH", "FONT", "CURVE"}:
                continue

            data_name = ob.data.name
            base_data_name, data_suffix = clean_name(data_name)

            object_base, object_suffix = clean_name(ob.name)

            if base_data_name in trans_dict and self.lang in trans_dict[base_data_name]:

                new_name = trans_dict[base_data_name][self.lang]
                new_name = first_n_bytes(new_name)

                # Déterminer quel suffixe utiliser
                suffix_to_use = ''

                if object_suffix:
                    suffix_to_use = object_suffix
                elif data_suffix:
                    suffix_to_use = data_suffix

                # Appliquer le suffixe au nouveau nom
                if suffix_to_use:
                    ob.name = new_name + suffix_to_use
                else:
                    ob.name = new_name

                if ob.type == "FONT":
                    ob.data.body = new_name.upper()

                objects_translated += 1

        return objects_translated

    def _translate_collections(self, trans_dict):
        collections_translated = 0

        for col in bpy.data.collections:
            if not col.name.startswith('Collection') and "NAVID" in col:

                navid_name = col["NAVID"]
                has_apostrophe = navid_name.endswith("'")
                clean_navid = navid_name.rstrip("'") if has_apostrophe else navid_name

                if clean_navid in trans_dict and self.lang in trans_dict[clean_navid]:

                    new_name = trans_dict[clean_navid][self.lang]
                    new_name = first_n_bytes(new_name)

                    col.name = new_name + "'" if has_apostrophe else new_name
                    collections_translated += 1

        return collections_translated

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

class OBJECT_OT_translate_collections_only(bpy.types.Operator):
    bl_idname = "object.translate_collections_only"
    bl_label = "Translate Collections Only"
    bl_options = {'REGISTER', 'UNDO'}

    lang: bpy.props.EnumProperty(
        items=get_available_languages,
        name="Language"
    )

    def execute(self, context):

        if self.lang == "NAVID":
            count = self._reset_collections_to_navid()
            self.report({"INFO"}, f"Reset {count} collections to NAVID")
            return {"FINISHED"}

        trans_dict, _ = get_translations() or ({}, [])
        if not trans_dict:
            self.report({"ERROR"}, "Translation file not found or invalid.")
            return {"CANCELLED"}

        bpy.context.preferences.edit.use_global_undo = False
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=0)

        count = self._translate_collections_only(trans_dict)

        bpy.context.preferences.edit.use_global_undo = True
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)

        self.report({"INFO"}, f"Translated {count} collections to {self.lang}")
        return {"FINISHED"}

    def _translate_collections_only(self, trans_dict):
        collections_translated = 0

        for col in bpy.data.collections:
            if not col.name.startswith('Collection') and "NAVID" in col:

                navid_name = col["NAVID"]
                has_apostrophe = navid_name.endswith("'")
                clean_navid = navid_name.rstrip("'") if has_apostrophe else navid_name

                if clean_navid in trans_dict and self.lang in trans_dict[clean_navid]:

                    new_name = trans_dict[clean_navid][self.lang]
                    new_name = first_n_bytes(new_name)

                    col.name = new_name + "'" if has_apostrophe else new_name
                    collections_translated += 1

        return collections_translated

    def _reset_collections_to_navid(self):
        count = 0
        for col in bpy.data.collections:
            if not col.name.startswith('Collection') and "NAVID" in col:
                col.name = col["NAVID"]
                count += 1
        return count

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

class ZANATOMY_PT_translate_panel(bpy.types.Panel):
    bl_label = "Translate"
    bl_idname = "VIEW3D_PT_z_translate_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Z-Anatomy'

    def draw(self, context):
        layout = self.layout
        layout.operator("object.translate_atlas")
        layout.operator("object.translate_collections_only")

classes = (
    OBJECT_OT_translate_atlas,
    OBJECT_OT_translate_collections_only,
    ZANATOMY_PT_translate_panel,
)

def register():
    for cls in classes:
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass

if __name__ == "__main__":
    register()
