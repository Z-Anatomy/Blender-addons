bl_info = {
    "name": "Z-Translate (Final)",
    "authors": "Gauthier Kervyn",
    "description": "Translate objects (based on mesh names) and collections (based on 'NAVID' custom property).",
    "blender": (4, 5, 0),
    "version": (1, 3, 0),
    "location": "View3D > Sidebar > Z-Anatomy",
    "warning": "",
    "category": "Interface"
}

import bpy
import re

# Cache global pour les traductions
_translations_cache = None
_last_modified_hash = None

def clean_name(name):
    """Nettoie le nom en séparant le suffixe (.r, .l, etc.)"""
    match = re.search(r'(\.[rlojtei])', name)
    if match:
        suffix = match.group(1)
        parts = name.split(suffix, 1)
        return parts[0], suffix + parts[1]
    return name, ''

def first_n_bytes(string, n=63):
    """Tronque une chaîne à n bytes UTF-8"""
    encoded = string.encode('utf-8', errors='replace')
    if len(encoded) <= n:
        return string
    return encoded[:n].decode('utf-8', errors='replace')

def decode_text_safely(text_block):
    """Décode un bloc de texte en essayant plusieurs encodages"""
    encodings = ['utf-8', 'latin1', 'windows-1252', 'iso-8859-1']
    for encoding in encodings:
        try:
            return text_block.as_string().encode(encoding).decode('utf-8', errors='replace')
        except UnicodeError:
            continue
    return text_block.as_string()

def get_translations():
    """Charge et met en cache les traductions depuis '0.Translations'"""
    global _translations_cache, _last_modified_hash
    translations_text = bpy.data.texts.get('0.Translations')
    if not translations_text:
        return None, []

    current_hash = hash(translations_text.as_string())
    if _translations_cache is not None and current_hash == _last_modified_hash:
        return _translations_cache

    try:
        content = decode_text_safely(translations_text)
        lines = content.splitlines()
        if not lines:
            return None, []

        # La première ligne contient les langues
        languages = [lang.strip() for lang in lines[0].split(';') if lang.strip()]
        trans_dict = {}

        for line in lines[1:]:
            if not line.strip():
                continue
            values = line.split(';')
            if len(values) == len(languages):
                key = values[0]
                trans_dict[key] = dict(zip(languages[1:], values[1:]))

        _translations_cache = trans_dict, languages
        _last_modified_hash = current_hash
        return trans_dict, languages
    except Exception as e:
        print(f"Erreur de lecture: {e}")
        return None, []

def get_available_languages(self, context):
    """Récupère dynamiquement les langues disponibles depuis '0.Translations'"""
    trans_dict, languages = get_translations() or ({}, [])
    # Ajoute toujours 'NAVID' comme option pour réinitialiser
    available = [('NAVID', 'NAVID', '', 0)]
    for i, lang in enumerate(languages, start=1):
        available.append((lang, lang, '', i))
    return available

class OBJECT_OT_translate_atlas(bpy.types.Operator):
    bl_idname = "object.translate_atlas"
    bl_label = "Translate All"
    bl_description = "Translate objects (based on mesh names) and collections (based on 'NAVID' custom property)"
    bl_options = {'REGISTER', 'UNDO'}

    lang: bpy.props.EnumProperty(
        items=get_available_languages,
        name="Language"
    )

    def execute(self, context):
        if self.lang == "NAVID":
            self._reset_to_navid()
            return {"FINISHED"}

        trans_dict, _ = get_translations() or ({}, [])
        if not trans_dict:
            self.report(type={"ERROR"}, message="Translation file not found or invalid.")
            return {"CANCELLED"}

        # Désactive les mises à jour UI pour accélérer
        bpy.context.preferences.edit.use_global_undo = False
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=0)

        objects_translated = self._translate_objects(trans_dict)
        collections_translated = self._translate_collections(trans_dict)

        # Réactive les mises à jour UI
        bpy.context.preferences.edit.use_global_undo = True
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)

        self.report(type={"INFO"}, message=f"Translated {objects_translated} objects and {collections_translated} collections to {self.lang}")
        return {"FINISHED"}

    def _reset_to_navid(self):
        """Réinitialise les objets vers ob.data.name et les collections vers leur 'NAVID'"""
        objects_processed = 0
        collections_processed = 0

        bpy.context.preferences.edit.use_global_undo = False
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=0)

        # Réinitialise les objets vers ob.data.name
        for ob in bpy.data.objects:
            if ob.type in {"MESH", "CURVE", "FONT"}:
                ob.name = ob.data.name
                if ob.type == "FONT":
                    ob.data.body = ob.data.name.upper()
                objects_processed += 1

        # Réinitialise les collections vers leur 'NAVID'
        for col in bpy.data.collections:
            if "NAVID" in col:
                col.name = col["NAVID"]
                collections_processed += 1

        bpy.context.preferences.edit.use_global_undo = True
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)

        self.report(type={"INFO"}, message=f"Reset {objects_processed} objects to mesh names and {collections_processed} collections to NAVID")

    def _translate_objects(self, trans_dict):
        """Traduire les objets en utilisant ob.data.name comme clé"""
        objects_translated = 0
        objects_to_translate = [ob for ob in bpy.data.objects if ob.type in {"MESH", "FONT", "CURVE"}]

        for ob in objects_to_translate:
            navid_name = ob.data.name
            base_name, ending = clean_name(ob.name)

            if navid_name in trans_dict and self.lang in trans_dict[navid_name]:
                new_name = trans_dict[navid_name][self.lang]
                new_name = first_n_bytes(new_name)
                ob.name = new_name + ending

                if ob.type == "FONT":
                    ob.data.body = new_name.upper()
                objects_translated += 1

        return objects_translated

    def _translate_collections(self, trans_dict):
        """Traduire les collections en utilisant leur 'NAVID' custom property"""
        collections_translated = 0

        for col in bpy.data.collections:
            if not col.name.startswith('Collection') and "NAVID" in col:
                navid_name = col["NAVID"]
                has_apostrophe = navid_name.endswith("'")
                clean_navid = navid_name.rstrip("'") if has_apostrophe else navid_name

                if clean_navid in trans_dict and self.lang in trans_dict[clean_navid]:
                    new_name = trans_dict[clean_navid][self.lang]
                    new_name = first_n_bytes(new_name)

                    if has_apostrophe:
                        col.name = new_name + "'"
                    else:
                        col.name = new_name
                    collections_translated += 1

        return collections_translated

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

class OBJECT_OT_translate_collections_only(bpy.types.Operator):
    bl_idname = "object.translate_collections_only"
    bl_label = "Translate Collections Only"
    bl_description = "Translate only collection names (based on 'NAVID' custom property)"
    bl_options = {'REGISTER', 'UNDO'}

    lang: bpy.props.EnumProperty(
        items=get_available_languages,
        name="Language"
    )

    def execute(self, context):
        if self.lang == "NAVID":
            collections_reset = self._reset_collections_to_navid()
            self.report(type={"INFO"}, message=f"Reset {collections_reset} collections to NAVID")
            return {"FINISHED"}

        trans_dict, _ = get_translations() or ({}, [])
        if not trans_dict:
            self.report(type={"ERROR"}, message="Translation file not found or invalid.")
            return {"CANCELLED"}

        bpy.context.preferences.edit.use_global_undo = False
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=0)

        collections_translated = self._translate_collections_only(trans_dict)

        bpy.context.preferences.edit.use_global_undo = True
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)

        self.report(type={"INFO"}, message=f"Translated {collections_translated} collections to {self.lang}")
        return {"FINISHED"}

    def _translate_collections_only(self, trans_dict):
        """Traduire uniquement les collections en utilisant leur 'NAVID'"""
        collections_translated = 0

        for col in bpy.data.collections:
            if not col.name.startswith('Collection') and "NAVID" in col:
                navid_name = col["NAVID"]
                has_apostrophe = navid_name.endswith("'")
                clean_navid = navid_name.rstrip("'") if has_apostrophe else navid_name

                if clean_navid in trans_dict and self.lang in trans_dict[clean_navid]:
                    new_name = trans_dict[clean_navid][self.lang]
                    new_name = first_n_bytes(new_name)

                    if has_apostrophe:
                        col.name = new_name + "'"
                    else:
                        col.name = new_name
                    collections_translated += 1

        return collections_translated

    def _reset_collections_to_navid(self):
        """Réinitialise les collections vers leur 'NAVID'"""
        collections_reset = 0

        for col in bpy.data.collections:
            if not col.name.startswith('Collection') and "NAVID" in col:
                col.name = col["NAVID"]
                collections_reset += 1

        return collections_reset

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

class ZANATOMY_PT_translate_panel(bpy.types.Panel):
    bl_label = "Translate"
    bl_idname = "VIEW3D_PT_z_translate_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Z-Anatomy'

    def draw(self, context):
        layout = self.layout
        layout.operator("object.translate_atlas")
        layout.operator("object.translate_collections_only")

classes = (
    OBJECT_OT_translate_atlas,
    OBJECT_OT_translate_collections_only,
    ZANATOMY_PT_translate_panel,
)

def register():
    for cls in classes:
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass

if __name__ == "__main__":
    register()
