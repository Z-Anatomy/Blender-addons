# This program is free software: you can redistribute it and/or modify
# it under the terms of the Creative Commons Attribution-ShareAlike 4.0 International License (CC-BY-SA 4.0).
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# For more information, visit the official license page: https://creativecommons.org/licenses/by-sa/4.0/
bl_info = {
    "name": "Z-Translate",
    "authors": "Marcin Zieliński, Gauthier Kervyn",
    "description": "Tools to translate objects using a list of translations. Stores NAVID as a custom property for Z-Def compatibility.",
    "blender": (4, 5, 0),
    "version": (1, 0, 0),
    "location": "View3D > Sidebar > Z-Anatomy",
    "warning": "",
    "category": "Interface"
}
import bpy
import re
from collections import defaultdict

# Police par défaut pour toutes les langues
fonts = {
    'NAVID': 'Bfont',
    'English': 'Bfont',
    'Latin': 'Bfont',
    'Français': 'Bfont',
    'Español': 'Bfont',
    'Portugues': 'Bfont',
    'Polski': 'Bfont',
    'Parsi': 'Bfont',
}

def clean_name(name):
    suffixes = ['.r', '.l', '.t', '.j', '.o', '.e', '.i']
    for suffix in suffixes:
        if suffix in name:
            parts = name.split(suffix, 1)
            base_name = parts[0]
            ending = suffix + parts[1]
            return base_name, ending
    return name, ''

def first_n_bytes(string, n=63):
    byte_length = 0
    out = ''
    for char in string:
        byte_length += len(char.encode('utf-8', errors='replace'))
        if byte_length <= n:
            out += char
        else:
            return out
    return out

def decode_text_safely(text_block):
    encodings = ['utf-8', 'latin1', 'windows-1252', 'iso-8859-1']
    for encoding in encodings:
        try:
            return text_block.as_string().encode(encoding).decode('utf-8', errors='replace')
        except UnicodeError:
            continue
    return text_block.as_string()

def get_available_languages(self, context):
    translations_text = bpy.data.texts.get('0.Translations')
    if not translations_text:
        return [
            ('NAVID', 'NAVID', '', 0),
            ('English', 'English', '', 1),
            ('Latin', 'Latin', '', 2),
            ('Français', 'Français', '', 3),
            ('Español', 'Español', '', 4),
            ('Portugues', 'Portugues', '', 5),
            ('Polski', 'Polski', '', 6),
            ('Parsi', 'Parsi', '', 7),
        ]
    try:
        first_line = decode_text_safely(translations_text).splitlines()[0]
        first_line = first_line.strip()
        languages = [lang.strip() for lang in first_line.split(';') if lang.strip()]
    except Exception as e:
        print(f"Erreur de lecture des langues : {e}")
        return [
            ('NAVID', 'NAVID', '', 0),
            ('English', 'English', '', 1),
            ('Latin', 'Latin', '', 2),
            ('Français', 'Français', '', 3),
            ('Español', 'Español', '', 4),
            ('Portugues', 'Portugues', '', 5),
            ('Polski', 'Polski', '', 6),
            ('Parsi', 'Parsi', '', 7),
        ]
    
    available_languages = []
    all_languages = [
        ('NAVID', 'NAVID', '', 0),
        ('English', 'English', '', 1),
        ('Latin', 'Latin', '', 2),
        ('Français', 'Français', '', 3),
        ('Español', 'Español', '', 4),
        ('Portugues', 'Portugues', '', 5),
        ('Polski', 'Polski', '', 6),
        ('Parsi', 'Parsi', '', 7),
    ]
    
    for lang in all_languages:
        if lang[0] in languages:
            available_languages.append(lang)
    
    return available_languages

class OBJECT_OT_translate_atlas(bpy.types.Operator):
    bl_idname = "object.translate_atlas"
    bl_label = "Translate All"
    bl_description = "Translate both objects and collections to selected language using NAVID"
    bl_options = {'REGISTER', 'UNDO'}
    
    lang: bpy.props.EnumProperty(
        items=get_available_languages,
        name="Language"
    )
    
    def execute(self, context):
        translations_text = bpy.data.texts.get('0.Translations')
        if not translations_text:
            self.report(type={"ERROR"}, message="Le fichier '0.Translations' est introuvable.")
            return {"CANCELLED"}
                    
        if self.lang == "NAVID":
            self._translate_to_navid()
            return {"FINISHED"}
            
        try:
            translations = decode_text_safely(translations_text).splitlines()
        except Exception as e:
            self.report(type={"ERROR"}, message=f"Erreur de lecture du fichier : {str(e)}")
            return {"CANCELLED"}
            
        languages = translations[0].split(';')
        trans_dict = {}
        for line in translations[1:]:
            if not line.strip():
                continue
            values = line.split(';')
            if len(values) != len(languages):
                continue
            key = values[0]
            trans_dict[key] = dict(zip(languages[1:], values[1:]))
            
        # Traduire les objets
        objects_translated = self._translate_objects(trans_dict)
        
        # Traduire les collections
        collections_translated = self._translate_collections(trans_dict)
        
        self.report(type={"INFO"}, message=f"Translated {objects_translated} objects and {collections_translated} collections to {self.lang}")
        return {"FINISHED"}
    
    def _translate_to_navid(self):
        """Reset vers NAVID"""
        objects_processed = 0
        
        # Traiter tous les objets
        for ob in bpy.data.objects:
            if ob.type in {"MESH", "CURVE"}:
                base_name, ending = clean_name(ob.name)
                navid_name, _ = clean_name(ob.data.name)
                ob.name = navid_name + ending
                ob["NAVID"] = navid_name
                objects_processed += 1
            elif ob.type == "FONT":
                ob.name = ob.data.name
                ob["NAVID"] = ob.data.name
                ob.data.body = clean_name(ob.data.name)[0].upper()
                ob.data.font = bpy.data.fonts.get('Bfont')
                ob.data.size = 0.003
                objects_processed += 1
        
        # Reset des collections vers leurs NAVID
        collections_reset = 0
        for col in bpy.data.collections:
            if col.name.startswith('Collection'):
                continue
            if "NAVID" in col:
                col.name = col["NAVID"]
                collections_reset += 1
        
        self.report(type={"INFO"}, message=f"Reset {objects_processed} objects and {collections_reset} collections to NAVID")
    
    def _translate_objects(self, trans_dict):
        """Traduire tous les objets"""
        objects_translated = 0
        
        for ob in bpy.data.objects:
            if ob.type not in {"MESH", "FONT", "CURVE"}:
                continue
                
            base_name, ending = clean_name(ob.name)
            
            # Déterminer le NAVID selon le type d'objet
            if ob.type in {"MESH", "CURVE"}:
                navid_name, _ = clean_name(ob.data.name)
            else:  # FONT
                navid_name, _ = clean_name(ob.data.name)
            
            if navid_name in trans_dict and self.lang in trans_dict[navid_name]:
                new_name = trans_dict[navid_name][self.lang]
                new_name = first_n_bytes(new_name)
                ob.name = new_name + ending
                ob["NAVID"] = navid_name  # Toujours stocker le NAVID
                
                # Traitement spécifique aux textes
                if ob.type == "FONT":
                    ob.data.body = new_name.upper()
                    try:
                        ob.data.font = bpy.data.fonts[fonts[self.lang]]
                    except:
                        pass
                    ob.data.size = 0.003
                
                objects_translated += 1
        
        return objects_translated
    
    def _translate_collections(self, trans_dict):
        """Traduire les collections en utilisant leurs métadonnées NAVID"""
        collections_translated = 0
        
        for col in bpy.data.collections:
            if col.name.startswith('Collection'):
                continue
                
            # Utiliser la métadonnée NAVID
            navid_name = col.get("NAVID")
            
            if not navid_name:
                continue
                
            # Gérer l'apostrophe
            has_apostrophe = navid_name.endswith("'")
            clean_navid = navid_name.rstrip("'") if has_apostrophe else navid_name
            
            if clean_navid in trans_dict and self.lang in trans_dict[clean_navid]:
                new_name = trans_dict[clean_navid][self.lang]
                new_name = first_n_bytes(new_name)
                
                # Réappliquer l'apostrophe si elle était présente
                if has_apostrophe:
                    col.name = new_name + "'"
                else:
                    col.name = new_name
                collections_translated += 1
        
        return collections_translated
    
    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

class OBJECT_OT_translate_collections_only(bpy.types.Operator):
    bl_idname = "object.translate_collections_only"
    bl_label = "Translate Collections Only"
    bl_description = "Translate only collection names to selected language using NAVID"
    bl_options = {'REGISTER', 'UNDO'}
    
    lang: bpy.props.EnumProperty(
        items=get_available_languages,
        name="Language"
    )
    
    def execute(self, context):
        translations_text = bpy.data.texts.get('0.Translations')
        if not translations_text:
            self.report(type={"ERROR"}, message="Le fichier '0.Translations' est introuvable.")
            return {"CANCELLED"}
            
        if self.lang == "NAVID":
            collections_reset = self._reset_collections_to_navid()
            self.report(type={"INFO"}, message=f"{collections_reset} collections reset to NAVID")
            return {"FINISHED"}
            
        try:
            translations = decode_text_safely(translations_text).splitlines()
        except Exception as e:
            self.report(type={"ERROR"}, message=f"Erreur de lecture du fichier : {str(e)}")
            return {"CANCELLED"}
            
        languages = translations[0].split(';')
        trans_dict = {}
        for line in translations[1:]:
            if not line.strip():
                continue
            values = line.split(';')
            if len(values) != len(languages):
                continue
            key = values[0]
            trans_dict[key] = dict(zip(languages[1:], values[1:]))
        
        # Traduire seulement les collections
        collections_translated = self._translate_collections_only(trans_dict)
        
        self.report(type={"INFO"}, message=f"{collections_translated} collections translated to {self.lang}")
        return {"FINISHED"}
    
    def _translate_collections_only(self, trans_dict):
        """Traduire seulement les collections"""
        collections_translated = 0
        
        for col in bpy.data.collections:
            if col.name.startswith('Collection'):
                continue
                
            # Utiliser la métadonnée NAVID
            navid_name = col.get("NAVID")
            
            if not navid_name:
                continue
                
            # Gérer l'apostrophe
            has_apostrophe = navid_name.endswith("'")
            clean_navid = navid_name.rstrip("'") if has_apostrophe else navid_name
            
            if clean_navid in trans_dict and self.lang in trans_dict[clean_navid]:
                new_name = trans_dict[clean_navid][self.lang]
                new_name = first_n_bytes(new_name)
                
                # Réappliquer l'apostrophe si elle était présente
                if has_apostrophe:
                    col.name = new_name + "'"
                else:
                    col.name = new_name
                collections_translated += 1
        
        return collections_translated
    
    def _reset_collections_to_navid(self):
        """Reset des collections vers NAVID"""
        collections_reset = 0
        
        for col in bpy.data.collections:
            if col.name.startswith('Collection'):
                continue
            if "NAVID" in col:
                col.name = col["NAVID"]
                collections_reset += 1
        
        return collections_reset
    
    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

class ZANATOMY_PT_translate_panel(bpy.types.Panel):
    bl_label = "Translate"
    bl_idname = "VIEW3D_PT_z_translate_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Z-Anatomy'
    
    def draw(self, context):
        layout = self.layout
        layout.operator("object.translate_atlas")
        layout.operator("object.translate_collections_only")

classes = (
    OBJECT_OT_translate_atlas,
    OBJECT_OT_translate_collections_only,
    ZANATOMY_PT_translate_panel,
)

def register():
    for cls in classes:
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass

if __name__ == "__main__":
    register()