bl_info = {
    "name": "Z-Export",
    "author": "Marcin Zielinski, Morgan Le Chénéchal, Gauthier Kervyn",
    "description": "Preparatory operations for FBX export",
    "blender": (5, 0, 0),
    "version": (1, 16, 0),
    "location": "View3D > Sidebar > Z-Anatomy",
    "category": "Interface"
}

import bpy
import bmesh
import os
import re
from pathlib import Path
from math import radians

# ============================================================================
# Z-TRANSLATE PART (integrated)
# ============================================================================

_translations_cache = None
_last_modified_hash = None

def clean_name(name):
    """Clean name by separating suffix (.r, .l, etc.)"""
    match = re.search(r'(\.[rlojstei])', name)
    if match:
        suffix = match.group(1)
        parts = name.split(suffix, 1)
        return parts[0], suffix + parts[1]
    return name, ''

def first_n_bytes(string, n=63):
    """Truncate string to n UTF-8 bytes"""
    encoded = string.encode('utf-8', errors='replace')
    if len(encoded) <= n:
        return string
    return encoded[:n].decode('utf-8', errors='replace')

def decode_text_safely(text_block):
    """Decode a text block trying multiple encodings"""
    encodings = ['utf-8', 'latin1', 'windows-1252', 'iso-8859-1']
    for encoding in encodings:
        try:
            return text_block.as_string().encode(encoding).decode('utf-8', errors='replace')
        except UnicodeError:
            continue
    return text_block.as_string()

def get_translations():
    """Load and cache translations from '0.Translations'"""
    global _translations_cache, _last_modified_hash
    translations_text = bpy.data.texts.get('0.Translations')
    if not translations_text:
        return None, []

    current_hash = hash(translations_text.as_string())
    if _translations_cache is not None and current_hash == _last_modified_hash:
        return _translations_cache

    try:
        content = decode_text_safely(translations_text)
        lines = content.splitlines()
        if not lines:
            return None, []

        languages = [lang.strip() for lang in lines[0].split(';') if lang.strip()]
        trans_dict = {}

        for line in lines[1:]:
            if not line.strip():
                continue
            values = line.split(';')
            if len(values) == len(languages):
                key = values[0]
                trans_dict[key] = dict(zip(languages[1:], values[1:]))

        _translations_cache = trans_dict, languages
        _last_modified_hash = current_hash
        return trans_dict, languages
    except Exception as e:
        print(f"Error reading: {e}")
        return None, []

def get_available_languages(self, context):
    """Dynamically get available languages from '0.Translations'"""
    trans_dict, languages = get_translations() or ({}, [])
    available = [('NAVID', 'NAVID', '', 0)]
    for i, lang in enumerate(languages, start=1):
        available.append((lang, lang, '', i))
    return available

class OBJECT_OT_translate_atlas(bpy.types.Operator):
    bl_idname = "object.translate_atlas"
    bl_label = "Translate all"
    bl_description = "Translate objects and collections based on 'NAVID'"
    bl_options = {'REGISTER', 'UNDO'}

    lang: bpy.props.EnumProperty(
        items=get_available_languages,
        name="Language"
    )

    def execute(self, context):
        if self.lang == "NAVID":
            self._reset_to_navid()
            return {"FINISHED"}

        trans_dict, _ = get_translations() or ({}, [])
        if not trans_dict:
            self.report({"ERROR"}, message="Translation file not found or invalid.")
            return {"CANCELLED"}

        bpy.context.preferences.edit.use_global_undo = False
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=0)

        objects_translated = self._translate_objects(trans_dict)
        collections_translated = self._translate_collections(trans_dict)

        bpy.context.preferences.edit.use_global_undo = True
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)

        self.report({"INFO"}, message=f"Translated {objects_translated} objects and {collections_translated} collections to {self.lang}")
        return {"FINISHED"}

    def _reset_to_navid(self):
        objects_processed = 0
        collections_processed = 0

        bpy.context.preferences.edit.use_global_undo = False
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=0)

        for ob in bpy.data.objects:
            if ob.type in {"MESH", "CURVE", "FONT"}:
                navid, _ = clean_name(ob.data.name)
                base_name, ending = clean_name(ob.name)
                ob.name = navid + ending
                if ob.type == "FONT":
                    ob.data.body = ob.data.name.upper()
                objects_processed += 1

        for col in bpy.data.collections:
            if "NAVID" in col:
                col.name = col["NAVID"]
                collections_processed += 1

        bpy.context.preferences.edit.use_global_undo = True
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)

        self.report({"INFO"}, message=f"Reset {objects_processed} objects and {collections_processed} collections to NAVID")

    def _translate_objects(self, trans_dict):
        objects_translated = 0
        for ob in bpy.data.objects:
            if ob.type in {"MESH", "FONT", "CURVE"}:
                navid, _ = clean_name(ob.data.name)
                base_name, ending = clean_name(ob.name)
                if navid in trans_dict and self.lang in trans_dict[navid]:
                    new_name = trans_dict[navid][self.lang]
                    new_name = first_n_bytes(new_name)
                    ob.name = new_name + ending
                    if ob.type == "FONT":
                        ob.data.body = new_name.upper()
                    objects_translated += 1
        return objects_translated

    def _translate_collections(self, trans_dict):
        collections_translated = 0
        for col in bpy.data.collections:
            if not col.name.startswith('Collection') and "NAVID" in col:
                navid_name = col["NAVID"]
                has_apostrophe = navid_name.endswith("'")
                clean_navid = navid_name.rstrip("'") if has_apostrophe else navid_name
                if clean_navid in trans_dict and self.lang in trans_dict[clean_navid]:
                    new_name = trans_dict[clean_navid][self.lang]
                    new_name = first_n_bytes(new_name)
                    col.name = new_name + ("'" if has_apostrophe else "")
                    collections_translated += 1
        return collections_translated

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)


# ============================================================================
# MIRROR IT FUNCTION
# ============================================================================

def is_parent_parent_mirrored(obj, mirrored_objs):
    if obj.parent is None or obj.parent.parent is None:
        return False
    if obj.parent.parent in mirrored_objs:
        return True
    for modifier in obj.parent.parent.modifiers:
        if modifier.type == 'MIRROR':
            return True
    return False


class ZEXPORT_OT_mirror_it(bpy.types.Operator):
    """Mirror selected objects and rename them"""
    bl_idname = "zexport.mirror_it"
    bl_label = "Mirror it"
    bl_description = "Mirror selected objects and rename (.l → .r, .i → .j, .s → .t). Tip: Run on parents first, then on children"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected_objects = context.selected_objects

        if not selected_objects:
            self.report({'WARNING'}, "No objects selected")
            return {'CANCELLED'}
        
        has_parent_child_relation = False
        for obj in selected_objects:
            if obj.parent and obj.parent in selected_objects:
                has_parent_child_relation = True
                break
        
        if has_parent_child_relation:
            self.report({'WARNING'}, "Parents and children selected together. For best results, run MirrorIt on parents first, then on children.")
        
        all_objs = []
        mirrored_objs = []
        
        for obj in selected_objects:
            for modifier in obj.modifiers:
                if modifier.type == 'MIRROR':
                    obj.modifiers.remove(modifier)
                    mirrored_objs.append(obj)

            obj.delta_location += obj.location
            obj.location = (0, 0, 0)
            
            if obj.parent is not None:
                ob_matrix_orig = obj.matrix_world.copy()
                obj.matrix_parent_inverse.identity()
                obj.matrix_basis = obj.parent.matrix_world.inverted() @ ob_matrix_orig

            duplicate = obj.copy()
            
            if ".i" in duplicate.name:        
                duplicate.data = obj.data.copy()
            else:
                duplicate.data = obj.data
            
            for collection in obj.users_collection:
                collection.objects.link(duplicate)
            
            is_label = (".s" in obj.name or ".t" in obj.name)
            is_line = (".i" in obj.name or ".j" in obj.name)
            parent_will_be_mirrored = obj.parent and obj.parent in selected_objects
            
            if not (is_label or is_line) and not parent_will_be_mirrored:
                duplicate.delta_location.x *= -1
                if duplicate.parent is not None:
                    duplicate.scale.x *= -1

            all_objs.append(obj)
            all_objs.append(duplicate)

        reparent_map = {}

        for obj in all_objs:
            if ".001" in obj.name:
                orig_name = obj.name.replace(".001", "")
                reparented = False
                for ob in all_objs:
                    if ob.name == orig_name and ob.parent is not None:
                        duplicate_parent_name = ob.parent.name + ".001"
                        for o in all_objs:
                            if o.name == duplicate_parent_name:
                                obj.parent = o
                                reparented = True
                                break
                        break
                reparent_map[obj] = reparented
                
        for obj, reparent in reparent_map.items():
            if ".s" in obj.name:
                obj.delta_location.x *= -1
                if obj.parent.parent is not None and is_parent_parent_mirrored(obj, mirrored_objs):
                    obj.scale.y *= -1
                if obj.parent.parent is not None and obj.parent.parent in all_objs:     
                    obj.location.x *= -1
                else:
                    obj.scale.y *= -1
                    if not obj.parent.parent in reparent_map.keys() and is_parent_parent_mirrored(obj, mirrored_objs):
                        obj.delta_location.x *= -1
            else:
                if ".i" in obj.name and not reparent:
                    obj.delta_location.x *= -1
        
        for obj in all_objs:
            if ".001" in obj.name:
                for modifier in obj.modifiers:
                    if modifier.type == 'HOOK':
                        obj.modifiers.remove(modifier)
                        orig_name = obj.name.replace('.001', '')
                        for ob in all_objs:
                            if ob.name == orig_name:
                                for mod in ob.modifiers:
                                    if mod.type == 'HOOK':
                                        dg = context.evaluated_depsgraph_get()
                                        evaled = ob.evaluated_get(dg)
                                        orig_mesh = evaled.to_mesh()
                                        for i in range(len(orig_mesh.vertices)):
                                            vertex = orig_mesh.vertices[i].co.copy()
                                            vertex.x *= -1
                                            obj.data.vertices[i].co = vertex
        
        for obj in all_objs:
            if "l.001" in obj.name:
                obj.name = obj.name.replace("l.001", "r")
            if "i.001" in obj.name:
                obj.name = obj.name.replace("i.001", "j")
            if "s.001" in obj.name:
                obj.name = obj.name.replace("s.001", "t")

        context.view_layer.update()
        
        self.report({'INFO'}, f"Mirrored {len(selected_objects)} objects")
        return {'FINISHED'}


# ============================================================================
# THICKEN LINES FUNCTION (ORIGINAL Line2Mesh)
# ============================================================================

class ZEXPORT_OT_thicken_lines(bpy.types.Operator):
    """Convert .i/.j lines to thick mesh with skin modifier"""
    bl_idname = "zexport.thicken_lines"
    bl_label = "Thicken lines"
    bl_description = "Convert .i/.j lines to thick mesh. Clears text from .s/.t labels (does NOT delete them)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected = context.selected_objects

        if not selected:
            self.report({'WARNING'}, "No objects selected")
            return {'CANCELLED'}

        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')

        context.view_layer.objects.active = None
        
        line_objs = []

        dg = context.evaluated_depsgraph_get()
        
        for obj in selected:
            if '.i' in obj.name or '.j' in obj.name:
                print(obj.name)
                
                context.view_layer.objects.active = obj
                obj.select_set(True)
                
                for modifier in obj.modifiers:
                    # if has hook
                    if modifier.type == 'HOOK':
                        # save current modified mesh                    
                        evaled = obj.evaluated_get(dg)
                        orig_mesh = evaled.to_mesh()
                        # remove the hook
                        obj.modifiers.remove(modifier)
                        # recreate the modified mesh
                        for i in range(len(orig_mesh.vertices)):
                            vertex = orig_mesh.vertices[i].co.copy()
                            obj.data.vertices[i].co = vertex
                
                skin = obj.modifiers.new('SkinMod', 'SKIN')
                for v in obj.data.skin_vertices[0].data:
                    v.radius = (0.005, 0.005)
                
                line_objs.append(obj)
                obj.select_set(False)
                
            elif '.s' in obj.name or '.t' in obj.name:
                print(f"Clearing text from: {obj.name}")
                # Vérifier que c'est bien un objet texte (FONT)
                if obj.type == 'FONT':
                    obj.data.body = ''
                else:
                    print(f"Warning: {obj.name} has .s/.t suffix but is not a FONT object (type: {obj.type})")
        
        # reduce vertices number generated by the skin modifier    
        dg = context.evaluated_depsgraph_get()
        bm = bmesh.new()
        for obj in line_objs:
            # save current modified mesh                    
            evaled = obj.evaluated_get(dg)
            orig_mesh = evaled.to_mesh()
            
            # remove the skin
            for modifier in obj.modifiers:
                if modifier.type == 'SKIN':
                    obj.modifiers.remove(modifier)

            bm.from_mesh(orig_mesh)
            bmesh.ops.dissolve_limit(bm, angle_limit=radians(1.7), verts=bm.verts, edges=bm.edges)
            bm.to_mesh(obj.data)
            obj.data.update()
            bm.clear()

        bm.free()
        
        self.report({'INFO'}, f"Processed {len(line_objs)} lines")
        return {'FINISHED'}

# ============================================================================
# TENDONS TO MESH FUNCTION
# ============================================================================

class ZEXPORT_OT_tendons_to_mesh(bpy.types.Operator):
    """Convert selected curves to mesh and join with parent"""
    bl_idname = "zexport.tendons_to_mesh"
    bl_label = "Tendons to Mesh"
    bl_description = "Convert selected curves to mesh and join with parent"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected = context.selected_objects

        if not selected:
            self.report({'WARNING'}, "No objects selected")
            return {'CANCELLED'}

        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        context.view_layer.objects.active = None
        
        converted_count = 0
        
        for obj in selected:
            if obj.type == "CURVE":
                obj.select_set(True)
                bpy.ops.object.convert(target='MESH')
                
                if obj.parent:
                    parent = obj.parent
                    parent.select_set(True)
                    context.view_layer.objects.active = obj.parent
                    bpy.ops.object.join()
                    converted_count += 1
                    
                    parent.select_set(False)
                    context.view_layer.objects.active = None
        
        self.report({'INFO'}, f"Converted {converted_count} curve objects to mesh")
        return {'FINISHED'}


# ============================================================================
# DIRECT ACTION BUTTONS
# ============================================================================

class ZEXPORT_OT_create_copy(bpy.types.Operator):
    """Save current file, then rename it with _Export suffix"""
    bl_idname = "zexport.create_copy"
    bl_label = "Create copy_export"
    bl_description = "Save the file, then rename it with _Export suffix"
    bl_options = {'REGISTER'}

    def execute(self, context):
        if not bpy.data.is_saved:
            self.report({'ERROR'}, "Please save the .blend file first")
            return {'CANCELLED'}

        src = Path(bpy.data.filepath)
        target = src.with_name(f"{src.stem}_Export{src.suffix}")

        if src == target:
            self.report({'WARNING'}, "File already has _Export suffix")
            return {'CANCELLED'}

        try:
            bpy.ops.wm.save_mainfile()
            bpy.ops.wm.save_as_mainfile(filepath=str(target), check_existing=False)
            self.report({'INFO'}, f"File saved and renamed: {target.name}")
        except Exception as e:
            self.report({'ERROR'}, f"Error: {str(e)[:100]}")
            return {'CANCELLED'}

        return {'FINISHED'}


class ZEXPORT_OT_export_lists(bpy.types.Operator):
    """Generate .txt files for bonus collections and sliders"""
    bl_idname = "zexport.export_lists"
    bl_label = "Export Sliders and Bonus lists"
    bl_description = "Generate text files for bonus collections and sliders"
    bl_options = {'REGISTER'}

    def execute(self, context):
        if not bpy.data.is_saved:
            self.report({'ERROR'}, "Please save the .blend file first")
            return {'CANCELLED'}

        try:
            self._export_bonus_collections()
        except Exception as e:
            self.report({'ERROR'}, f"Bonus collections error: {str(e)[:100]}")
            return {'CANCELLED'}

        try:
            self._export_sliders()
        except Exception as e:
            self.report({'ERROR'}, f"Sliders error: {str(e)[:100]}")
            return {'CANCELLED'}

        self.report({'INFO'}, "Lists exported successfully")
        return {'FINISHED'}

    def _export_bonus_collections(self):
        ROOT_COLLECTION_NAME = "Collections bonus"
        MIRROR_COLLECTION_NAME = "MirrorIt"

        base_dir = Path(bpy.path.abspath("//")).resolve()
        output_dir = base_dir / ROOT_COLLECTION_NAME
        output_dir.mkdir(exist_ok=True)

        root_col = bpy.data.collections.get(ROOT_COLLECTION_NAME)
        if root_col is None:
            raise RuntimeError(f"Collection not found: {ROOT_COLLECTION_NAME}")

        mirror_col = bpy.data.collections.get(MIRROR_COLLECTION_NAME)
        mirror_objs = set(mirror_col.objects) if mirror_col else set()

        def collect_objects_recursive(collection, seen_cols=None, ordered=None):
            if seen_cols is None:
                seen_cols = set()
            if ordered is None:
                ordered = []

            if collection in seen_cols:
                return ordered

            seen_cols.add(collection)

            for obj in collection.objects:
                if obj not in ordered:
                    ordered.append(obj)

            for child in collection.children:
                collect_objects_recursive(child, seen_cols, ordered)

            return ordered

        def mirror_name(obj_name):
            if obj_name.endswith(".l"):
                return obj_name[:-2] + ".r"
            if obj_name.endswith(".r"):
                return obj_name[:-2] + ".l"
            return None

        def generate_file_for_collection(col, output_dir):
            objs = collect_objects_recursive(col)
            lines = []

            for obj in objs:
                lines.append(obj.name)
                if obj in mirror_objs:
                    alt = mirror_name(obj.name)
                    if alt:
                        lines.append(alt)

            unique_lines = list(dict.fromkeys(lines))
            txt_path = output_dir / f"{col.name}.txt"
            txt_path.write_text("\n".join(unique_lines) + ("\n" if unique_lines else ""), encoding="utf-8")

        def process_all_subcollections(col, output_dir):
            for child in col.children:
                generate_file_for_collection(child, output_dir)
                process_all_subcollections(child, output_dir)

        process_all_subcollections(root_col, output_dir)

    def _export_sliders(self):
        blend_file_path = bpy.data.filepath
        output_dir = os.path.join(os.path.dirname(blend_file_path), "Sliders")
        os.makedirs(output_dir, exist_ok=True)

        sliders_file = os.path.join(output_dir, "Sliders.txt")

        with open(sliders_file, 'w', encoding='utf-8') as f_sliders:
            for collection in bpy.data.collections:
                if 'Slider' in collection.name:
                    f_sliders.write(f"\n\n{collection.name.upper()}\n\n")

                    for child_collection in collection.children:
                        output_file = os.path.join(output_dir, f"{child_collection.name}.txt")
                        objects_in_child = list(child_collection.objects)
                        names_to_write = set()

                        for obj in objects_in_child:
                            names_to_write.add(obj.name)

                        for obj in objects_in_child:
                            if any('MirrorIt' in c.name for c in obj.users_collection):
                                if obj.name.endswith('.l'):
                                    names_to_write.add(obj.name[:-2] + '.r')
                                elif obj.name.endswith('.r'):
                                    names_to_write.add(obj.name[:-2] + '.l')

                        with open(output_file, 'w', encoding='utf-8') as f:
                            for name in sorted(names_to_write):
                                f.write(f"{name}\n")

                        f_sliders.write(f"{child_collection.name}:\n")
                        for name in sorted(names_to_write):
                            f_sliders.write(f"{name}\n")
                        f_sliders.write("\n")


class ZEXPORT_OT_list_objects_and_defs(bpy.types.Operator):
    """Generate object and definition lists (0.Obj_list and 0.DefList)"""
    bl_idname = "zexport.list_objects_and_defs"
    bl_label = "List Objects and Defs"
    bl_description = "Generate 0.Obj_list (vertices/points) and 0.DefList (definition lines -5)"
    bl_options = {'REGISTER'}

    TRANSLATIONS_NAME = "0.Translations"
    OBJ_LIST_NAME = "0.Obj_list"
    DEF_LIST_NAME = "0.DefList"

    def count_curve_points(self, curve_data):
        total_points = 0
        for spline in curve_data.splines:
            total_points += len(spline.bezier_points) if spline.type == 'BEZIER' else len(spline.points)
        return total_points

    def data_name_matches(self, data_name, navid):
        return data_name in {navid, f"{navid}.j", f"{navid}.l", f"{navid}.i"}

    def get_or_create_cleared_text(self, name):
        if name in bpy.data.texts:
            txt = bpy.data.texts[name]
            txt.clear()
        else:
            txt = bpy.data.texts.new(name)
        return txt

    def update_obj_list(self, translations_text):
        obj_list = self.get_or_create_cleared_text(self.OBJ_LIST_NAME)
        content = []
        
        for line in translations_text.lines:
            navid = line.body.split(';')[0].strip()
            if not navid:
                content.append(" ")
                continue
                
            mesh_obj = next((o for o in bpy.data.objects 
                            if o.type == 'MESH' and o.data and self.data_name_matches(o.data.name, navid)), None)
            if mesh_obj:
                content.append(str(len(mesh_obj.data.vertices)))
                continue
                
            curve_obj = next((o for o in bpy.data.objects 
                             if o.type == 'CURVE' and o.data and self.data_name_matches(o.data.name, navid)), None)
            if curve_obj:
                content.append(f"${self.count_curve_points(curve_obj.data)}")
                continue
                
            content.append(" ")
        
        obj_list.write("\n".join(content))

    def update_def_list(self, translations_text):
        def_list = self.get_or_create_cleared_text(self.DEF_LIST_NAME)
        content = []
        
        for line in translations_text.lines:
            navid = line.body.split(';')[0].strip()
            if not navid:
                content.append(" ")
                continue
                
            def_text = bpy.data.texts.get(navid)
            if def_text:
                line_count = len(def_text.lines) - 5
                content.append(str(max(0, line_count)))
            else:
                content.append(" ")
        
        def_list.write("\n".join(content))

    def execute(self, context):
        translations_text = bpy.data.texts.get(self.TRANSLATIONS_NAME)
        if not translations_text:
            self.report({'ERROR'}, f"'{self.TRANSLATIONS_NAME}' not found.")
            return {'CANCELLED'}
        
        try:
            self.update_obj_list(translations_text)
            self.update_def_list(translations_text)
            self.report({'INFO'}, f"✓ {self.OBJ_LIST_NAME} → vertices/points | {self.DEF_LIST_NAME} → definition lines - 5")
        except Exception as e:
            self.report({'ERROR'}, f"Error: {str(e)[:100]}")
            return {'CANCELLED'}
        
        return {'FINISHED'}


# ============================================================================
# PANEL
# ============================================================================

class VIEW3D_PT_ZExport(bpy.types.Panel):
    bl_label = "Z-Export"
    bl_idname = "VIEW3D_PT_ZExport"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Z-Anatomy'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout

        box = layout.box()
        box.label(text="Actions", icon='FILE_SCRIPT')
        
        row = box.row()
        row.operator("zexport.create_copy", text="Create copy_export", icon='FILE_BLEND')
        
        row = box.row()
        row.operator("zexport.export_lists", text="Export Sliders and Bonus lists", icon='TEXT')
        
        row = box.row()
        row.operator("zexport.list_objects_and_defs", text="List Objects and Defs", icon='LINENUMBERS_ON')
        
        row = box.row()
        row.operator("zexport.mirror_it", text="Mirror it", icon='MOD_MIRROR')
        
        row = box.row()
        row.operator("zexport.thicken_lines", text="Thicken lines", icon='MOD_SKIN')
        
        row = box.row()
        row.operator("zexport.tendons_to_mesh", text="Tendons to Mesh", icon='OUTLINER_OB_CURVE')
        
        row = box.row()
        row.operator("object.translate_atlas", text="Translate all", icon='FORWARD')


# ============================================================================
# REGISTRATION
# ============================================================================

classes = [
    OBJECT_OT_translate_atlas,
    ZEXPORT_OT_mirror_it,
    ZEXPORT_OT_thicken_lines,
    ZEXPORT_OT_tendons_to_mesh,
    ZEXPORT_OT_create_copy,
    ZEXPORT_OT_export_lists,
    ZEXPORT_OT_list_objects_and_defs,
    VIEW3D_PT_ZExport,
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()