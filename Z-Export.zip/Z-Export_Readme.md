# Z-Export Add-on for Blender

## Description

Z-Export is a Blender add-on that provides tools to prepare and export Z-Anatomy models to FBX format. It includes preparatory operations such as mirroring, line thickening, curve-to-mesh conversion, and list generation before final export.

## Features

- **Create copy_export** - Saves the current .blend file and renames it with `_Export` suffix
- **Export Sliders and Bonus lists** - Generates `.txt` files listing objects from Sliders and Bonus collections
- **List Objects and Defs** - Generates `0.Obj_list` (vertex/point counts) and `0.DefList` (definition lines -5) from translations
- **Mirror it** - Mirrors selected objects on X-axis and renames suffixes (`.l` → `.r`, `.i` → `.j`, `.s` → `.t`)
- **Thicken lines** - Converts `.i`/`.j` line objects to thick meshes using Skin modifier and clears `.s`/`.t` text objects
- **Tendons to Mesh** - Converts selected curve objects to mesh and joins them with their parent
- **Translate all** - Translates objects and collections based on the `0.Translations` text file
- **Export FBX** - Exports selected objects to FBX with customizable folder and filename

## Installation

1. Download the `.zip` file of the add-on.
2. Open Blender and go to `Edit` > `Preferences`.
3. Select the `Add-ons` tab and click the downward-facing arrow in the top-right corner.
4. Choose `Install from Disk` and select the downloaded `.zip` file.
5. Enable the add-on by checking the box next to "Z-Export".

## Usage

### Panel Location

1. Open the **N** panel in the 3D Viewport.
2. Go to the **Z-Anatomy** tab.
3. Locate the **Z-Export** panel.

### Export Settings

Before exporting, configure:

- **Export folder** - Choose a directory where the FBX file will be saved
- **Filename** - Enter a name for the exported FBX file (without `.fbx` extension)

### Preparatory Operations

Apply these operations to selected objects before export:

- **Mirror it** - Run on parents first, then on children for best results
- **Thicken lines** - Select `.i`/`.j` line objects and click to convert
- **Tendons to Mesh** - Select curve objects and click to convert

### Export Process

1. Select the objects you want to export.
2. Click **Export FBX** button.
3. The add-on will export only the selected objects to the specified location.

### Translation File Setup

For translation features to work, a text block named `0.Translations` must exist in the `.blend` file with the following structure:
- First line: semicolon-separated language codes (e.g., `NAVID;English;French;Spanish`)
- Following lines: `NAVID;Translation1;Translation2;Translation3` for each entry

## Important Warnings

Before exporting, ensure:
- ✅ **Uncheck 'Only labels of active objects' (Z-Display)**
- ✅ **Show all objects of collection**
- ✅ **Mirror Bones first, then Insertions**

## Compatibility

- Blender 5.0.0 and later versions.

## Authors

- **Marcin Zielinski**
- **Morgan Le Chénéchal**
- **Gauthier Kervyn**
- **Z-Anatomy**

## License

This add-on is distributed under the [CC-BY-SA 4.0](LICENSE) license, which allows sharing and adaptation with attribution and under the same terms.