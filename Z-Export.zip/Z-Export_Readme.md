# Z-Export Add-on for Blender

## Description

Z-Export is a Blender add-on that provides preparatory operations for Z-Anatomy models before FBX export. It includes tools such as mirroring, line thickening, curve-to-mesh conversion, and list generation.

## Features

- **Create copy_export** - Saves the current `.blend` file and renames it with `_Export` suffix
- **Export Sliders and Bonus lists** - Generates `.txt` files listing objects from Sliders and Bonus collections
- **List Objects and Defs** - Generates `0.Obj_list` (vertex/point counts) and `0.DefList` (definition lines -5) from translations
- **Mirror it** - Mirrors selected objects on X-axis and renames suffixes (`.l` → `.r`, `.i` → `.j`, `.s` → `.t`)
- **Thicken lines** - Converts `.i`/`.j` line objects to thick meshes using Skin modifier and clears text from `.s`/`.t` labels
- **Tendons to Mesh** - Converts selected curve objects to mesh and joins them with their parent
- **Translate all** - Translates objects and collections based on the `0.Translations` text file

## Installation

1. Download the `.zip` file of the add-on.
2. Open Blender and go to `Edit` > `Preferences`.
3. Select the `Add-ons` tab and click the downward-facing arrow in the top-right corner.
4. Choose `Install from Disk` and select the downloaded `.zip` file.
5. Enable the add-on by checking the box next to "Z-Export".

## Usage

### Panel Location

1. Open the **N** panel in the 3D Viewport.
2. Go to the **Z-Anatomy** tab.
3. Locate the **Z-Export** panel.

### Preparatory Operations

Apply these operations to selected objects before FBX export:

- **Mirror it** - Run on parents first, then on children for best results. Mirrors objects and renames suffixes.
- **Thicken lines** - Select `.i`/`.j` line objects and click to convert them to thick meshes. Also clears text from `.s`/`.t` labels.
- **Tendons to Mesh** - Select curve objects and click to convert them to mesh and join with their parent.

### List Generation

- **Export Sliders and Bonus lists** - Generates `.txt` files in `Sliders` and `Collections bonus` folders next to the `.blend` file
- **List Objects and Defs** - Generates `0.Obj_list` (vertex/point counts) and `0.DefList` (definition lines -5) from the `0.Translations` text block

### File Management

- **Create copy_export** - Saves the current file and creates a renamed copy with `_Export` suffix

### Translation File Setup

For translation features to work, a text block named `0.Translations` must exist in the `.blend` file with the following structure:

- First line: semicolon-separated language codes (e.g., `NAVID;English;French;Spanish`)
- Following lines: `NAVID;Translation1;Translation2;Translation3` for each entry

## Workflow

1. Prepare your scene and select the objects you want to process
2. Run preparatory operations as needed (Mirror it, Thicken lines, Tendons to Mesh)
3. Use the native Blender FBX exporter (`File > Export > FBX`) to export your model

## Important Notes

Before exporting to FBX, ensure:
- ✅ **Uncheck 'Only labels of active objects' (Z-Display)**
- ✅ **Show all objects of collection**
- ✅ **Mirror Bones first, then Insertions**

## Compatibility

- Blender 5.0.0 and later versions.

## Authors

- **Marcin Zielinski**
- **Morgan Le Chénéchal**
- **Gauthier Kervyn**
- **Z-Anatomy**

## License

This add-on is distributed under the [CC-BY-SA 4.0](LICENSE) license, which allows sharing and adaptation with attribution and under the same terms.